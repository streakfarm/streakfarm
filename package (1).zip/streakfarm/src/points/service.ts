import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';
import { redisCache } from '../cache/redis';

interface PointsSource {
  source: string;
  sourceId?: string;
  metadata?: Record<string, any>;
}

class PointsService {
  async awardPoints(userId: string, points: number, source: PointsSource): Promise<{
    success: boolean;
    newBalance: number;
    error?: string;
  }> {
    try {
      const { data: user, error: userError } = await getSupabaseClient()
        .from('users')
        .select('raw_points')
        .eq('id', userId)
        .single();

      if (userError) throw userError;

      const newBalance = (user.raw_points || 0) + points;

      const { error: updateError } = await getSupabaseClient()
        .from('users')
        .update({ raw_points: newBalance })
        .eq('id', userId);

      if (updateError) throw updateError;

      await this.recordPointsHistory(userId, points, source.source, source.sourceId, newBalance);

      await this.invalidateUserCache(userId);

      await logEvent('points_awarded', {
        userId,
        points,
        source: source.source,
        sourceId: source.sourceId,
        newBalance
      });

      return { success: true, newBalance };
    } catch (error) {
      logEvent('points_award_error', { userId, points, source, error });
      return { success: false, newBalance: 0, error: 'Failed to award points' };
    }
  }

  async deductPoints(userId: string, points: number, source: PointsSource): Promise<{
    success: boolean;
    newBalance: number;
    error?: string;
  }> {
    try {
      const { data: user, error: userError } = await getSupabaseClient()
        .from('users')
        .select('raw_points')
        .eq('id', userId)
        .single();

      if (userError) throw userError;

      if ((user.raw_points || 0) < points) {
        return { success: false, newBalance: user.raw_points || 0, error: 'Insufficient points' };
      }

      const newBalance = (user.raw_points || 0) - points;

      const { error: updateError } = await getSupabaseClient()
        .from('users')
        .update({ raw_points: newBalance })
        .eq('id', userId);

      if (updateError) throw updateError;

      await this.recordPointsHistory(userId, -points, source.source, source.sourceId, newBalance);

      await this.invalidateUserCache(userId);

      await logEvent('points_deducted', {
        userId,
        points,
        source: source.source,
        sourceId: source.sourceId,
        newBalance
      });

      return { success: true, newBalance };
    } catch (error) {
      logEvent('points_deduct_error', { userId, points, source, error });
      return { success: false, newBalance: 0, error: 'Failed to deduct points' };
    }
  }

  async setPoints(userId: string, points: number, source: PointsSource): Promise<{
    success: boolean;
    newBalance: number;
    error?: string;
  }> {
    try {
      const { error: updateError } = await getSupabaseClient()
        .from('users')
        .update({ raw_points: points })
        .eq('id', userId);

      if (updateError) throw updateError;

      await this.recordPointsHistory(userId, points, source.source, source.sourceId, points);

      await this.invalidateUserCache(userId);

      await logEvent('points_set', {
        userId,
        points,
        source: source.source,
        sourceId: source.sourceId
      });

      return { success: true, newBalance: points };
    } catch (error) {
      logEvent('points_set_error', { userId, points, source, error });
      return { success: false, newBalance: 0, error: 'Failed to set points' };
    }
  }

  async getPointsHistory(
    userId: string,
    limit: number = 50,
    offset: number = 0
  ): Promise<Array<{
    id: string;
    points: number;
    source: string;
    sourceId?: string;
    balanceAfter: number;
    createdAt: string;
  }>> {
    const { data, error } = await getSupabaseClient()
      .from('points_history')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    return data?.map(h => ({
      id: h.id,
      points: h.points,
      source: h.source,
      sourceId: h.source_id,
      balanceAfter: h.balance_after,
      createdAt: h.created_at
    })) || [];
  }

  async getPointsStats(userId: string): Promise<{
    totalEarned: number;
    totalSpent: number;
    avgPerDay: number;
    bestDay: { date: string; points: number };
    sourcesBreakdown: Record<string, number>;
  }> {
    const history = await this.getPointsHistory(userId, 1000);

    let totalEarned = 0;
    let totalSpent = 0;
    const sourcesBreakdown: Record<string, number> = {};

    const dayTotals: Record<string, number> = {};

    for (const entry of history) {
      if (entry.points > 0) {
        totalEarned += entry.points;
        sourcesBreakdown[entry.source] = (sourcesBreakdown[entry.source] || 0) + entry.points;
      } else {
        totalSpent += Math.abs(entry.points);
      }

      const date = entry.createdAt.split('T')[0];
      dayTotals[date] = (dayTotals[date] || 0) + entry.points;
    }

    let bestDay = { date: '', points: 0 };
    for (const [date, points] of Object.entries(dayTotals)) {
      if (points > bestDay.points) {
        bestDay = { date, points };
      }
    }

    const user = await getSupabaseClient()
      .from('users')
      .select('created_at, raw_points')
      .eq('id', userId)
      .single();

    const createdAt = new Date(user?.created_at || Date.now());
    const now = new Date();
    const daysActive = Math.max(1, Math.ceil((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24)));
    const avgPerDay = totalEarned / daysActive;

    return {
      totalEarned,
      totalSpent,
      avgPerDay,
      bestDay,
      sourcesBreakdown
    };
  }

  private async recordPointsHistory(
    userId: string,
    points: number,
    source: string,
    sourceId: string | undefined,
    balanceAfter: number
  ): Promise<void> {
    try {
      await getSupabaseClient()
        .from('points_history')
        .insert({
          user_id: userId,
          points,
          source,
          source_id: sourceId,
          balance_after: balanceAfter
        });
    } catch (error) {
      logEvent('points_history_error', { userId, source, error });
    }
  }

  private async invalidateUserCache(userId: string): Promise<void> {
    await redisCache.del([
      `user:${userId}`,
      `user_rank:${userId}`,
      `user_multiplier:${userId}`,
      `user_badges:${userId}`,
      `user_badges_check:${userId}`
    ]);
  }

  async getLeaderboardPosition(userId: string): Promise<number> {
    const { data: user, error } = await getSupabaseClient()
      .from('users')
      .select('raw_points')
      .eq('id', userId)
      .single();

    if (error || !user) return 0;

    const { count, error: countError } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', false)
      .eq('is_bot', false)
      .gt('raw_points', user.raw_points);

    if (countError) throw countError;

    return (count || 0) + 1;
  }

  async getPointsAroundUser(userId: string, range: number = 5): Promise<Array<{
    userId: string;
    username?: string;
    firstName?: string;
    points: number;
    rank: number;
    isCurrentUser: boolean;
  }>> {
    const user = await this.getLeaderboardPosition(userId);
    const startRank = Math.max(1, user - range);
    const endRank = user + range;

    const { data: users, error } = await getSupabaseClient()
      .from('users')
      .select('id, username, first_name, raw_points')
      .eq('is_banned', false)
      .eq('is_bot', false)
      .order('raw_points', { ascending: false })
      .range(startRank - 1, endRank - 1);

    if (error) throw error;

    return users?.map((u, index) => ({
      userId: u.id,
      username: u.username,
      firstName: u.first_name,
      points: u.raw_points,
      rank: startRank + index,
      isCurrentUser: u.id === userId
    })) || [];
  }
}

export const pointsService = new PointsService();
export type { PointsSource };
