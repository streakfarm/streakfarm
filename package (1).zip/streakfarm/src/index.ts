import 'dotenv/config';
import { createApp } from './api/app';
import { redisCache } from './cache/redis';
import { logEvent, logInfo, logError } from './utils/logger';
import { runMigrations } from './db/migrate';
import { startCronJobs } from './cron/jobs';
import Sentry from '@sentry/node';

const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';

async function main(): Promise<void> {
  try {
    logEvent('startup_begin');

    logInfo('Initializing Sentry');
    Sentry.init({
      dsn: process.env.SENTRY_DSN,
      environment: NODE_ENV,
      tracesSampleRate: 0.1
    });

    logInfo('Connecting to Redis');
    await redisCache.connect();

    logInfo('Running database migrations');
    await runMigrations();

    logInfo('Starting cron jobs');
    await startCronJobs();

    logInfo('Creating Express app');
    const app = createApp();

    logInfo(`Starting server on port ${PORT}`);
    app.listen(PORT, () => {
      logEvent('server_started', { port: PORT, environment: NODE_ENV });
      logInfo(`Server running on http://localhost:${PORT}`);
    });

    const gracefulShutdown = async (signal: string) => {
      logEvent('shutdown_begin', { signal });

      try {
        await redisCache.disconnect();
        logInfo('Redis disconnected');
      } catch (error) {
        logError(error as Error, { operation: 'redis_disconnect' });
      }

      process.exit(0);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    process.on('uncaughtException', (error) => {
      logError(error, { uncaughtException: true });
      process.exit(1);
    });

    process.on('unhandledRejection', (reason) => {
      logError(new Error(String(reason)), { unhandledRejection: true });
      process.exit(1);
    });

  } catch (error) {
    logError(error as Error, { startup: true });
    process.exit(1);
  }
}

main();
