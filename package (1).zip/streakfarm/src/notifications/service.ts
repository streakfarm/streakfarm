import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';

interface NotificationPayload {
  title: string;
  body: string;
  data?: Record<string, any>;
  inlineKeyboards?: Array<Array<{
    text: string;
    callback_data?: string;
    url?: string;
  }>>;
}

class NotificationService {
  private botToken: string;
  private readonly MAX_MESSAGE_LENGTH = 4096;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || '';
  }

  async sendTelegramNotification(
    telegramId: number,
    notification: NotificationPayload
  ): Promise<{
    success: boolean;
    messageId?: string;
    error?: string;
  }> {
    try {
      const keyboardMarkup = notification.inlineKeyboards
        ? {
            inline_keyboard: notification.inlineKeyboards.map(row =>
              row.map(btn => ({
                text: btn.text,
                ...(btn.callback_data && { callback_data: btn.callback_data }),
                ...(btn.url && { url: btn.url })
              }))
            )
          }
        : undefined;

      const message = this.formatMessage(notification.title, notification.body);

      const response = await fetch(
        `https://api.telegram.org/bot${this.botToken}/sendMessage`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: telegramId,
            text: message,
            parse_mode: 'HTML',
            ...(keyboardMarkup && { reply_markup: keyboardMarkup }),
            disable_web_page_preview: true
          })
        }
      );

      if (!response.ok) {
        const error = await response.text();
        logEvent('telegram_notification_failed', { telegramId, error });
        return { success: false, error };
      }

      const data = await response.json();
      return { success: true, messageId: data.result?.message_id?.toString() };
    } catch (error) {
      logEvent('telegram_notification_error', { telegramId, error });
      return { success: false, error: 'Failed to send notification' };
    }
  }

  async sendBulkNotification(
    telegramIds: number[],
    notification: NotificationPayload,
    batchSize: number = 30
  ): Promise<{
    sent: number;
    failed: number;
    errors: string[];
  }> {
    let sent = 0;
    let failed = 0;
    const errors: string[] = [];

    for (let i = 0; i < telegramIds.length; i += batchSize) {
      const batch = telegramIds.slice(i, i + batchSize);

      const results = await Promise.all(
        batch.map(id => this.sendTelegramNotification(id, notification))
      );

      for (const result of results) {
        if (result.success) {
          sent++;
        } else {
          failed++;
          if (result.error) {
            errors.push(result.error);
          }
        }
      }

      if (i + batchSize < telegramIds.length) {
        await this.delay(1000);
      }
    }

    logEvent('bulk_notification_complete', { total: telegramIds.length, sent, failed });
    return { sent, failed, errors };
  }

  async notifyBadgeEarned(
    telegramId: number,
    badge: {
      name: string;
      icon_emoji: string;
      multiplier: number;
      description: string;
    }
  ): Promise<void> {
    await this.sendTelegramNotification(telegramId, {
      title: '🎉 New Badge Earned!',
      body: `${badge.icon_emoji} **${badge.name}**\n\nMultiplier: **${badge.multiplier}×**\n${badge.description}`,
      inlineKeyboards: [
        [{ text: 'View Badges', callback_data: 'view_badges' }]
      ]
    });
  }

  async notifyStreakMilestone(
    telegramId: number,
    streak: number,
    bonusPoints: number
  ): Promise<void> {
    const streakEmojis: Record<number, string> = {
      7: '🔥',
      14: '🔥🔥',
      30: '⭐⭐⭐',
      60: '💎💎💎',
      90: '👑👑👑',
      180: '🌟🌟🌟',
      365: '🏆🏆🏆'
    };

    const emoji = streakEmojis[streak] || '🔥';

    await this.sendTelegramNotification(telegramId, {
      title: `${emoji} Streak Milestone!`,
      body: `You've maintained a **${streak}-day streak**!\n\nReward: **${bonusPoints} points**\n\nKeep it up!`,
      inlineKeyboards: [
        [{ text: 'View Stats', callback_data: 'view_stats' }]
      ]
    });
  }

  async notifyReferralBonus(
    telegramId: number,
    referrerName: string,
    bonusPoints: number
  ): Promise<void> {
    await this.sendTelegramNotification(telegramId, {
      title: '👥 New Referral Bonus!',
      body: `**${referrerName}** signed up using your referral link!\n\nYou earned **${bonusPoints} points**!`,
      inlineKeyboards: [
        [{ text: 'Share Referral Link', callback_data: 'share_referral' }]
      ]
    });
  }

  async notifyWalletConnected(
    telegramId: number,
    walletType: string,
    bonusPoints: number
  ): Promise<void> {
    await this.sendTelegramNotification(telegramId, {
      title: '👛 Wallet Connected!',
      body: `Your **${walletType}** wallet is now connected!\n\nBonus: **${bonusPoints} points**\n\nExclusive features unlocked!`,
      inlineKeyboards: [
        [{ text: 'View Wallet Tasks', callback_data: 'wallet_tasks' }]
      ]
    });
  }

  async notifyLeaderboardPosition(
    telegramId: number,
    position: number,
    points: number
  ): Promise<void> {
    const positionEmoji = position <= 3 ? ['🥇', '🥈', '🥉'][position - 1] : `#${position}`;

    await this.sendTelegramNotification(telegramId, {
      title: `${positionEmoji} Leaderboard Update`,
      body: `You're now **rank ${position}**!\n\nPoints: **${points.toLocaleString()}**\n\nKeep climbing!`,
      inlineKeyboards: [
        [{ text: 'View Leaderboard', callback_data: 'view_leaderboard' }]
      ]
    });
  }

  async notifyMaintenance(
    telegramIds: number[],
    startTime: Date,
    duration: string,
    reason: string
  ): Promise<void> {
    await this.sendBulkNotification(telegramIds, {
      title: '⚠️ Scheduled Maintenance',
      body: `We'll be performing scheduled maintenance.\n\nStart: **${startTime.toUTCString()}**\nDuration: **${duration}**\n\n${reason}`,
      inlineKeyboards: [
        [{ text: 'Status Page', url: 'https://streakfarm.app/status' }]
      ]
    });
  }

  async notifyAirdropAnnouncement(
    telegramIds: number[],
    airdropDetails: {
      totalPool: string;
      snapshotDate: string;
      distributionDate: string;
      requirements: string[];
    }
  ): Promise<void> {
    const body = `🚀 **Airdrop Announcement!**\n\n` +
      `📦 **Total Pool:** ${airdropDetails.totalPool}\n` +
      `📸 **Snapshot Date:** ${airdropDetails.snapshotDate}\n` +
      `🎁 **Distribution:** ${airdropDetails.distributionDate}\n\n` +
      `**How to qualify:**\n${airdropDetails.requirements.map(r => `• ${r}`).join('\n')}`;

    await this.sendBulkNotification(telegramIds, {
      title: '🚀 Airdrop Coming!',
      body,
      inlineKeyboards: [
        [{ text: 'Learn More', url: 'https://streakfarm.app/airdrop' }]
      ]
    });
  }

  async sendDailyDigest(
    telegramId: number,
    stats: {
      pointsEarned: number;
      boxesOpened: number;
      streakMaintained: boolean;
      tasksCompleted: number;
      rank: number;
      pointsToNextRank: number;
    }
  ): Promise<void> {
    const streakStatus = stats.streakMaintained ? '✅' : '❌';

    const body = `📊 **Daily Digest**\n\n` +
      `💰 Points Earned: **${stats.pointsEarned}**\n` +
      `📦 Boxes Opened: **${stats.boxesOpened}**\n` +
      `🔥 Streak: ${streakStatus}\n` +
      `✅ Tasks Completed: **${stats.tasksCompleted}**\n` +
      `🏆 Current Rank: **#${stats.rank}**\n` +
      `📈 Points to Next Rank: **${stats.pointsToNextRank}**`;

    await this.sendTelegramNotification(telegramId, {
      title: '📅 Your Daily Summary',
      body,
      inlineKeyboards: [
        [{ text: 'Open App', callback_data: 'open_app' }]
      ]
    });
  }

  private formatMessage(title: string, body: string): string {
    const fullMessage = `<b>${title}</b>\n\n${body}`;
    return fullMessage.length > this.MAX_MESSAGE_LENGTH
      ? fullMessage.substring(0, this.MAX_MESSAGE_LENGTH - 3) + '...'
      : fullMessage;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const notificationService = new NotificationService();
export type { NotificationPayload };
