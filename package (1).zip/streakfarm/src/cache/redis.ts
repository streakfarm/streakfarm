import Redis from 'ioredis';
import { logEvent } from '../utils/logger';

let redisClient: Redis | null = null;
let redisSubscriber: Redis | null = null;

const DEFAULT_TTL = {
  userStats: 300,
  userBadges: 3600,
  userMultiplier: 300,
  leaderboard: 60,
  boxStatus: 60,
  tonBalance: 3600,
  taskList: 1800,
  config: 600
};

class RedisCache {
  private client: Redis;
  private isConnected: boolean = false;

  constructor() {
    this.client = this.createClient();
    this.setupEventHandlers();
  }

  private createClient(): Redis {
    const host = process.env.REDIS_HOST || 'localhost';
    const port = parseInt(process.env.REDIS_PORT || '6379');
    const password = process.env.REDIS_PASSWORD || undefined;
    const db = parseInt(process.env.REDIS_DB || '0');

    const client = new Redis({
      host,
      port,
      password,
      db,
      maxRetriesPerRequest: 3,
      retryDelayOnFailover: 100,
      enableReadyCheck: true,
      lazyConnect: true,
      commandTimeout: 5000
    });

    return client;
  }

  private setupEventHandlers(): void {
    this.client.on('connect', () => {
      this.isConnected = true;
      logEvent('redis_connected');
    });

    this.client.on('ready', () => {
      logEvent('redis_ready');
    });

    this.client.on('error', (error) => {
      logEvent('redis_error', { error: error.message });
    });

    this.client.on('close', () => {
      this.isConnected = false;
      logEvent('redis_closed');
    });

    this.client.on('reconnecting', () => {
      logEvent('redis_reconnecting');
    });
  }

  async connect(): Promise<void> {
    if (!this.isConnected) {
      await this.client.connect();
    }
  }

  async disconnect(): Promise<void> {
    await this.client.quit();
    this.isConnected = false;
  }

  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await this.client.get(key);
      if (value === null) return null;
      return JSON.parse(value) as T;
    } catch (error) {
      logEvent('redis_get_error', { key, error });
      return null;
    }
  }

  async set(key: string, value: any, ttlSeconds?: number): Promise<void> {
    try {
      const serialized = JSON.stringify(value);
      if (ttlSeconds) {
        await this.client.setex(key, ttlSeconds, serialized);
      } else {
        await this.client.set(key, serialized);
      }
    } catch (error) {
      logEvent('redis_set_error', { key, error });
    }
  }

  async del(key: string | string[]): Promise<void> {
    try {
      if (Array.isArray(key)) {
        await this.client.del(...key);
      } else {
        await this.client.del(key);
      }
    } catch (error) {
      logEvent('redis_del_error', { key, error });
    }
  }

  async exists(key: string): Promise<boolean> {
    try {
      const result = await this.client.exists(key);
      return result === 1;
    } catch (error) {
      logEvent('redis_exists_error', { key, error });
      return false;
    }
  }

  async incr(key: string): Promise<number> {
    try {
      return await this.client.incr(key);
    } catch (error) {
      logEvent('redis_incr_error', { key, error });
      return 0;
    }
  }

  async expire(key: string, seconds: number): Promise<boolean> {
    try {
      const result = await this.client.expire(key, seconds);
      return result === 1;
    } catch (error) {
      logEvent('redis_expire_error', { key, error });
      return false;
    }
  }

  async ttl(key: string): Promise<number> {
    try {
      return await this.client.ttl(key);
    } catch (error) {
      logEvent('redis_ttl_error', { key, error });
      return -2;
    }
  }

  async getOrSet<T>(key: string, fetcher: () => Promise<T>, ttlSeconds?: number): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== null) return cached;

    const value = await fetcher();
    await this.set(key, value, ttlSeconds);
    return value;
  }

  async deletePattern(pattern: string): Promise<void> {
    try {
      const keys = await this.client.keys(pattern);
      if (keys.length > 0) {
        await this.client.del(...keys);
      }
    } catch (error) {
      logEvent('redis_delete_pattern_error', { pattern, error });
    }
  }

  async hget<T>(hashKey: string, field: string): Promise<T | null> {
    try {
      const value = await this.client.hget(hashKey, field);
      if (value === null) return null;
      return JSON.parse(value) as T;
    } catch (error) {
      logEvent('redis_hget_error', { hashKey, field, error });
      return null;
    }
  }

  async hset(hashKey: string, field: string, value: any): Promise<void> {
    try {
      await this.client.hset(hashKey, field, JSON.stringify(value));
    } catch (error) {
      logEvent('redis_hset_error', { hashKey, field, error });
    }
  }

  async hgetall<T>(hashKey: string): Promise<Record<string, T>> {
    try {
      const result = await this.client.hgetall(hashKey);
      const parsed: Record<string, T> = {};
      for (const [key, value] of Object.entries(result)) {
        parsed[key] = JSON.parse(value) as T;
      }
      return parsed;
    } catch (error) {
      logEvent('redis_hgetall_error', { hashKey, error });
      return {};
    }
  }

  async zadd(key: string, score: number, member: string): Promise<void> {
    try {
      await this.client.zadd(key, score, member);
    } catch (error) {
      logEvent('redis_zadd_error', { key, error });
    }
  }

  async zrevrange<T>(key: string, start: number, stop: number): Promise<T[]> {
    try {
      const result = await this.client.zrevrange(key, start, stop, 'WITHSCORES');
      const items: T[] = [];
      for (let i = 0; i < result.length; i += 2) {
        items.push({ member: result[i], score: parseFloat(result[i + 1]) } as unknown as T);
      }
      return items;
    } catch (error) {
      logEvent('redis_zrevrange_error', { key, error });
      return [];
    }
  }

  async zcard(key: string): Promise<number> {
    try {
      return await this.client.zcard(key);
    } catch (error) {
      logEvent('redis_zcard_error', { key, error });
      return 0;
    }
  }

  async zincrby(key: string, increment: number, member: string): Promise<number> {
    try {
      return await this.client.zincrby(key, increment, member);
    } catch (error) {
      logEvent('redis_zincrby_error', { key, error });
      return 0;
    }
  }

  getClient(): Redis {
    return this.client;
  }

  getDefaultTTL(key: keyof typeof DEFAULT_TTL): number {
    return DEFAULT_TTL[key];
  }
}

export const redisCache = new RedisCache();

export function getRedisClient(): Redis {
  return redisCache.getClient();
}

export type { RedisCache };
