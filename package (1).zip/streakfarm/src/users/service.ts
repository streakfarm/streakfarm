import { v4 as uuidv4 } from 'uuid';
import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';
import { redisCache } from '../cache/redis';
import Sentry from '@sentry/node';

interface User {
  id: string;
  telegram_id: number;
  username?: string;
  first_name?: string;
  language_code: string;
  raw_points: number;
  streak_current: number;
  streak_best: number;
  last_checkin?: string;
  total_boxes_opened: number;
  total_tasks_completed: number;
  total_referrals: number;
  bots_reported: number;
  wallet_address?: string;
  wallet_type?: string;
  wallet_connected_at?: string;
  multiplier_permanent: number;
  joined_at: string;
  ref_code: string;
  referred_by?: string;
  fingerprint?: string;
  ip_address?: string;
  user_agent?: string;
  is_flagged: boolean;
  flag_reason?: string;
  is_banned: boolean;
  ban_reason?: string;
  is_bot: boolean;
  report_count: number;
  created_at: string;
  updated_at: string;
  last_active_at: string;
}

interface UserCreateData {
  telegramId: number;
  username?: string;
  firstName?: string;
  languageCode?: string;
  fingerprint?: string;
  ipAddress?: string;
  userAgent?: string;
  referredBy?: string;
}

interface UserStats {
  totalPoints: number;
  streak: number;
  streakBest: number;
  boxesOpened: number;
  tasksCompleted: number;
  referrals: number;
  badgesCount: number;
  rank: number;
  multiplier: number;
}

class UserService {
  async getOrCreateUser(data: UserCreateData): Promise<User> {
    const { data: existingUser, error: findError } = await getSupabaseClient()
      .from('users')
      .select('*')
      .eq('telegram_id', data.telegramId)
      .single();

    if (findError && findError.code !== 'PGRST116') {
      throw findError;
    }

    if (existingUser) {
      await this.updateLastActive(existingUser.id);
      return existingUser;
    }

    let refCode: string;
    let referredById: string | undefined;

    if (data.referredBy) {
      const { data: referrer } = await getSupabaseClient()
        .from('users')
        .select('id')
        .eq('ref_code', data.referredBy)
        .single();

      if (referrer) {
        referredById = referrer.id;
      }
      refCode = data.referredBy;
    } else {
      refCode = this.generateRefCode();
    }

    const { data: newUser, error: createError } = await getSupabaseClient()
      .from('users')
      .insert({
        telegram_id: data.telegramId,
        username: data.username,
        first_name: data.firstName,
        language_code: data.languageCode || 'en',
        ref_code: refCode,
        referred_by: referredById,
        fingerprint: data.fingerprint,
        ip_address: data.ipAddress,
        user_agent: data.userAgent,
        raw_points: 0,
        streak_current: 0,
        streak_best: 0,
        total_boxes_opened: 0,
        total_tasks_completed: 0,
        total_referrals: 0,
        multiplier_permanent: 1.0,
        is_flagged: false,
        is_banned: false,
        is_bot: false,
        report_count: 0
      })
      .select('*')
      .single();

    if (createError) {
      Sentry.captureException(createError);
      throw createError;
    }

    if (referredById) {
      await this.recordReferral(referredById, newUser.id);
    }

    await logEvent('user_created', {
      userId: newUser.id,
      telegramId: data.telegramId,
      referredBy: referredById
    });

    return newUser;
  }

  async getUser(userId: string): Promise<User | null> {
    const cacheKey = `user:${userId}`;
    const cached = await redisCache.get<User>(cacheKey);
    if (cached) return cached;

    const { data, error } = await getSupabaseClient()
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw error;
    }

    await redisCache.set(cacheKey, data, 300);

    return data;
  }

  async getUserByTelegramId(telegramId: number): Promise<User | null> {
    const { data, error } = await getSupabaseClient()
      .from('users')
      .select('*')
      .eq('telegram_id', telegramId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw error;
    }

    return data;
  }

  async getUserByRefCode(refCode: string): Promise<User | null> {
    const { data, error } = await getSupabaseClient()
      .from('users')
      .select('*')
      .eq('ref_code', refCode)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw error;
    }

    return data;
  }

  async updateLastActive(userId: string): Promise<void> {
    try {
      await getSupabaseClient()
        .from('users')
        .update({ last_active_at: new Date().toISOString() })
        .eq('id', userId);

      await redisCache.del(`user:${userId}`);
    } catch (error) {
      logEvent('update_last_active_error', { userId, error });
    }
  }

  async updateUserProfile(userId: string, updates: Partial<User>): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('users')
      .update(updates)
      .eq('id', userId);

    if (error) throw error;

    await redisCache.del(`user:${userId}`);
  }

  async incrementField(userId: string, field: keyof User, amount: number = 1): Promise<void> {
    try {
      await getSupabaseClient()
        .from('users')
        .update({ [field]: getSupabaseClient().raw(`${field} + ${amount}`) })
        .eq('id', userId);

      await redisCache.del(`user:${userId}`);
    } catch (error) {
      logEvent('increment_field_error', { userId, field, error });
    }
  }

  async recordReferral(referrerId: string, referredId: string): Promise<void> {
    try {
      const { error: referralError } = await getSupabaseClient()
        .from('referrals')
        .insert({
          referrer_id: referrerId,
          referred_id: referredId
        });

      if (referralError) {
        if (referralError.code !== '23505') {
          throw referralError;
        }
        return;
      }

      await this.incrementField(referrerId, 'total_referrals');

      await logEvent('referral_recorded', { referrerId, referredId });
    } catch (error) {
      logEvent('record_referral_error', { referrerId, referredId, error });
    }
  }

  async getUserStats(userId: string): Promise<UserStats> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const rank = await this.getUserRank(userId);

    return {
      totalPoints: user.raw_points,
      streak: user.streak_current,
      streakBest: user.streak_best,
      boxesOpened: user.total_boxes_opened,
      tasksCompleted: user.total_tasks_completed,
      referrals: user.total_referrals,
      badgesCount: 0,
      rank,
      multiplier: user.multiplier_permanent
    };
  }

  async getUserRank(userId: string): Promise<number> {
    const cacheKey = `user_rank:${userId}`;
    const cached = await redisCache.get<number>(cacheKey);
    if (cached !== null) return cached;

    const { count, error } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', false)
      .eq('is_bot', false)
      .gt('raw_points', (await this.getUser(userId))?.raw_points || 0);

    if (error) throw error;

    const rank = (count || 0) + 1;
    await redisCache.set(cacheKey, rank, 60);

    return rank;
  }

  async checkAndUpdateStreak(userId: string): Promise<{
    streakContinued: boolean;
    streakReset: boolean;
    newStreak: number;
    bonusPoints: number;
  }> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const now = new Date();
    const lastCheckin = user.last_checkin ? new Date(user.last_checkin) : null;
    const streakDecayHours = parseInt(process.env.STREAK_DECAY_HOURS || '25');
    const decayThreshold = new Date(now.getTime() - streakDecayHours * 60 * 60 * 1000);

    if (!lastCheckin || lastCheckin < decayThreshold) {
      const newStreak = user.streak_current === 0 ? 1 : 1;
      const bonusPoints = 100;

      const { error } = await getSupabaseClient()
        .from('users')
        .update({
          streak_current: newStreak,
          last_checkin: now.toISOString()
        })
        .eq('id', userId);

      if (error) throw error;

      await redisCache.del(`user:${userId}`);

      return {
        streakContinued: false,
        streakReset: user.streak_current > 0,
        newStreak,
        bonusPoints
      };
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const lastCheckinDay = new Date(lastCheckin);
    lastCheckinDay.setHours(0, 0, 0, 0);

    if (lastCheckinDay >= today) {
      return {
        streakContinued: true,
        streakReset: false,
        newStreak: user.streak_current,
        bonusPoints: 0
      };
    }

    const newStreak = user.streak_current + 1;
    const streakBonus = this.calculateStreakBonus(newStreak);

    const { error } = await getSupabaseClient()
      .from('users')
      .update({
        streak_current: newStreak,
        streak_best: Math.max(user.streak_best, newStreak),
        last_checkin: now.toISOString()
      })
      .eq('id', userId);

    if (error) throw error;

    await redisCache.del(`user:${userId}`);

    return {
      streakContinued: true,
      streakReset: false,
      newStreak,
      bonusPoints: streakBonus
    };
  }

  private calculateStreakBonus(streak: number): number {
    if (streak % 7 === 0) return 500;
    if (streak % 30 === 0) return 2000;
    if (streak % 100 === 0) return 5000;
    return 100;
  }

  private generateRefCode(): string {
    return uuidv4().substring(0, 8).toUpperCase();
  }

  async getTopReferrers(limit: number = 10): Promise<Array<{
    userId: string;
    username?: string;
    firstName?: string;
    referrals: number;
  }>> {
    const { data, error } = await getSupabaseClient()
      .from('users')
      .select('id, username, first_name, total_referrals')
      .eq('is_banned', false)
      .eq('is_bot', false)
      .order('total_referrals', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return data?.map(u => ({
      userId: u.id,
      username: u.username,
      firstName: u.first_name,
      referrals: u.total_referrals
    })) || [];
  }

  async getNewUsersCount(hours: number = 24): Promise<number> {
    const since = new Date();
    since.setHours(since.getHours() - hours);

    const { count, error } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .gte('created_at', since.toISOString());

    if (error) throw error;
    return count || 0;
  }

  async getActiveUsersCount(days: number = 1): Promise<number> {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const { count, error } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .gte('last_active_at', since.toISOString())
      .eq('is_banned', false)
      .eq('is_bot', false);

    if (error) throw error;
    return count || 0;
  }

  async flagUser(userId: string, reason: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('users')
      .update({ is_flagged: true, flag_reason: reason })
      .eq('id', userId);

    if (error) throw error;

    await redisCache.del(`user:${userId}`);
    await logEvent('user_flagged', { userId, reason });
  }

  async banUser(userId: string, reason: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('users')
      .update({ is_banned: true, ban_reason: reason })
      .eq('id', userId);

    if (error) throw error;

    await redisCache.del(`user:${userId}`);
    await logEvent('user_banned', { userId, reason });
  }

  async unbanUser(userId: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('users')
      .update({ is_banned: false, ban_reason: null })
      .eq('id', userId);

    if (error) throw error;

    await redisCache.del(`user:${userId}`);
    await logEvent('user_unbanned', { userId });
  }
}

export const userService = new UserService();
export type { User, UserCreateData, UserStats };
