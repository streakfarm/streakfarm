import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';
import { pointsService } from '../points/service';

interface ReferralStats {
  totalReferrals: number;
  activeReferrals: number;
  pendingReferrals: number;
  totalBonusEarned: number;
  topReferrers: Array<{
    userId: string;
    username?: string;
    firstName?: string;
    referrals: number;
  }>;
}

class ReferralService {
  async createReferralLink(userId: string): Promise<string> {
    const user = await getSupabaseClient()
      .from('users')
      .select('ref_code')
      .eq('id', userId)
      .single();

    if (user.error || !user.data) {
      throw new Error('User not found');
    }

    const baseUrl = process.env.FRONTEND_URL || 'https://streakfarm.app';
    return `${baseUrl}?startapp=${user.data.ref_code}`;
  }

  async processReferral(
    referrerId: string,
    referredTelegramId: number
  ): Promise<{
    success: boolean;
    bonusAwarded: boolean;
    referrerBonus: number;
    referredBonus: number;
    error?: string;
  }> {
    try {
      const referrer = await getSupabaseClient()
        .from('users')
        .select('id, ref_code')
        .eq('id', referrerId)
        .single();

      if (referrer.error || !referrer.data) {
        return { success: false, bonusAwarded: false, referrerBonus: 0, referredBonus: 0, error: 'Referrer not found' };
      }

      const referredUser = await getSupabaseClient()
        .from('users')
        .select('id, referred_by')
        .eq('telegram_id', referredTelegramId)
        .single();

      if (referredUser.error && referredUser.error.code !== 'PGRST116') {
        throw referredUser.error;
      }

      if (referredUser.data?.referred_by) {
        return { success: false, bonusAwarded: false, referrerBonus: 0, referredBonus: 0, error: 'User already referred' };
      }

      if (referredUser.data?.id === referrerId) {
        return { success: false, bonusAwarded: false, referrerBonus: 0, referredBonus: 0, error: 'Cannot refer yourself' };
      }

      const referralBonusConfig = {
        referrer: 1000,
        referred: 500
      };

      await getSupabaseClient()
        .from('users')
        .update({
          referred_by: referrerId,
          ref_code: referrer.data.ref_code
        })
        .eq('telegram_id', referredTelegramId);

      await getSupabaseClient()
        .from('referrals')
        .insert({
          referrer_id: referrerId,
          referred_id: referredUser.data?.id,
          bonus_awarded: true,
          bonus_points: referralBonusConfig.referrer
        });

      const { pointsService: points } = await import('./pointsService');
      await points.awardPoints(referrerId, referralBonusConfig.referrer, {
        source: 'referral_bonus',
        metadata: { referred_telegram_id: referredTelegramId }
      });

      if (referredUser.data?.id) {
        await points.awardPoints(referredUser.data.id, referralBonusConfig.referred, {
          source: 'referral_signup',
          metadata: { referrer_id: referrerId }
        });
      }

      await logEvent('referral_processed', {
        referrerId,
        referredId: referredUser.data?.id,
        referrerBonus: referralBonusConfig.referrer,
        referredBonus: referralBonusConfig.referred
      });

      return {
        success: true,
        bonusAwarded: true,
        referrerBonus: referralBonusConfig.referrer,
        referredBonus: referralBonusConfig.referred
      };
    } catch (error) {
      logEvent('referral_process_error', { error });
      return { success: false, bonusAwarded: false, referrerBonus: 0, referredBonus: 0, error: 'Failed to process referral' };
    }
  }

  async getReferralStats(userId: string): Promise<ReferralStats> {
    const { data: user, error: userError } = await getSupabaseClient()
      .from('users')
      .select('total_referrals')
      .eq('id', userId)
      .single();

    if (userError) throw userError;

    const { data: referrals, error: referralsError } = await getSupabaseClient()
      .from('referrals')
      .select('*')
      .eq('referrer_id', userId);

    if (referralsError) throw referralsError;

    const activeReferrals = referrals?.filter(r => r.bonus_awarded).length || 0;
    const pendingReferrals = referrals?.filter(r => !r.bonus_awarded).length || 0;

    const totalBonusEarned = referrals?.reduce((sum, r) => sum + (r.bonus_points || 0), 0) || 0;

    const { data: topReferrers } = await getSupabaseClient()
      .from('users')
      .select('id, username, first_name, total_referrals')
      .eq('is_banned', false)
      .eq('is_bot', false)
      .order('total_referrals', { ascending: false })
      .limit(10);

    return {
      totalReferrals: user?.total_referrals || 0,
      activeReferrals,
      pendingReferrals,
      totalBonusEarned,
      topReferrers: topReferrers?.map(u => ({
        userId: u.id,
        username: u.username || undefined,
        firstName: u.first_name || undefined,
        referrals: u.total_referrals
      })) || []
    };
  }

  async getUserReferrals(userId: string): Promise<Array<{
    id: string;
    referredId: string;
    username?: string;
    firstName?: string;
    points: number;
    joinedAt: string;
    bonusAwarded: boolean;
  }>> {
    const { data: referrals, error } = await getSupabaseClient()
      .from('referrals')
      .select('*, referred:users!referrals_referred_id_fkey(*)')
      .eq('referrer_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return referrals?.map(r => ({
      id: r.id,
      referredId: r.referred_id,
      username: r.referred?.username || undefined,
      firstName: r.referred?.first_name || undefined,
      points: r.bonus_points || 0,
      joinedAt: r.created_at,
      bonusAwarded: r.bonus_awarded
    })) || [];
  }

  async getReferralCode(userId: string): Promise<string> {
    const { data: user, error } = await getSupabaseClient()
      .from('users')
      .select('ref_code')
      .eq('id', userId)
      .single();

    if (error || !user) {
      throw new Error('User not found');
    }

    return user.ref_code;
  }

  async getReferrerByCode(refCode: string): Promise<string | null> {
    const { data: user, error } = await getSupabaseClient()
      .from('users')
      .select('id')
      .eq('ref_code', refCode)
      .single();

    if (error || !user) {
      return null;
    }

    return user.id;
  }

  async validateReferralCode(refCode: string, userId: string): Promise<{
    valid: boolean;
    referrerId?: string;
    error?: string;
  }> {
    if (!refCode || refCode.length < 4) {
      return { valid: false, error: 'Invalid referral code' };
    }

    const { data: referrer, error } = await getSupabaseClient()
      .from('users')
      .select('id, is_banned')
      .eq('ref_code', refCode)
      .single();

    if (error || !referrer) {
      return { valid: false, error: 'Referrer not found' };
    }

    if (referrer.is_banned) {
      return { valid: false, error: 'Referrer is banned' };
    }

    if (referrer.id === userId) {
      return { valid: false, error: 'Cannot refer yourself' };
    }

    const { data: existingReferral, error: existingError } = await getSupabaseClient()
      .from('referrals')
      .select('id')
      .eq('referred_id', userId)
      .single();

    if (existingError && existingError.code !== 'PGRST116') {
      throw existingError;
    }

    if (existingReferral) {
      return { valid: false, error: 'Already referred' };
    }

    return { valid: true, referrerId: referrer.id };
  }
}

export const referralService = new ReferralService();
export type { ReferralStats };
