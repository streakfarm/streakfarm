import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';
import { redisCache } from '../cache/redis';

interface Task {
  id: string;
  title: string;
  description: string;
  points: number;
  task_type: string;
  external_url?: string;
  telegram_channel_id?: string;
  twitter_username?: string;
  youtube_channel_id?: string;
  discord_invite_code?: string;
  requires_wallet: boolean;
  is_repeatable: boolean;
  repeat_cooldown_hours?: number;
  is_active: boolean;
  max_completions?: number;
  current_completions: number;
  created_at: string;
}

interface TaskCompletion {
  id: string;
  user_id: string;
  task_id: string;
  completed_at: string;
  verification_data?: Record<string, any>;
  is_verified: boolean;
  points_awarded: number;
}

interface TaskWithProgress extends Task {
  completed: boolean;
  completedAt?: string;
  progress?: number;
  canComplete: boolean;
}

class TaskService {
  async getAvailableTasks(userId: string): Promise<TaskWithProgress[]> {
    const { data: tasks, error } = await getSupabaseClient()
      .from('tasks')
      .select('*')
      .eq('is_active', true)
      .order('points', { ascending: false });

    if (error) throw error;

    const { data: completions, error: completionsError } = await getSupabaseClient()
      .from('task_completions')
      .select('task_id, completed_at, is_verified')
      .eq('user_id', userId);

    if (completionsError) throw completionsError;

    const completionMap = new Map<string, TaskCompletion[]>();
    for (const completion of completions || []) {
      const existing = completionMap.get(completion.task_id) || [];
      existing.push(completion);
      completionMap.set(completion.task_id, existing);
    }

    const walletInfo = await this.getUserWalletInfo(userId);

    return (tasks || []).map(task => {
      const userCompletions = completionMap.get(task.id) || [];
      const lastCompletion = userCompletions
        .filter(c => c.is_verified)
        .sort((a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime())[0];

      let completed = false;
      let canComplete = true;

      if (task.requires_wallet && !walletInfo.connected) {
        canComplete = false;
      }

      if (task.is_repeatable && lastCompletion) {
        const cooldownEnd = new Date(lastCompletion.completed_at);
        cooldownEnd.setHours(cooldownEnd.getHours() + (task.repeat_cooldown_hours || 24));
        completed = new Date() < cooldownEnd;
        canComplete = !completed && new Date() >= cooldownEnd;
      } else if (!task.is_repeatable && lastCompletion) {
        completed = true;
        canComplete = false;
      }

      if (task.max_completions && task.current_completions >= task.max_completions) {
        canComplete = false;
      }

      return {
        ...task,
        completed,
        completedAt: lastCompletion?.completed_at,
        progress: task.max_completions
          ? (task.current_completions / task.max_completions) * 100
          : undefined,
        canComplete
      };
    });
  }

  async getTaskById(taskId: string): Promise<Task | null> {
    const { data, error } = await getSupabaseClient()
      .from('tasks')
      .select('*')
      .eq('id', taskId)
      .single();

    if (error) return null;
    return data;
  }

  async completeTask(
    userId: string,
    taskId: string,
    verificationData?: Record<string, any>
  ): Promise<{
    success: boolean;
    pointsAwarded: number;
    newBadges: any[];
    error?: string;
  }> {
    const task = await this.getTaskById(taskId);

    if (!task || !task.is_active) {
      return { success: false, pointsAwarded: 0, newBadges: [], error: 'Task not found or inactive' };
    }

    const walletInfo = await this.getUserWalletInfo(userId);
    if (task.requires_wallet && !walletInfo.connected) {
      return { success: false, pointsAwarded: 0, newBadges: [], error: 'Wallet connection required' };
    }

    const { data: existingCompletion, error: checkError } = await getSupabaseClient()
      .from('task_completions')
      .select('*')
      .eq('user_id', userId)
      .eq('task_id', taskId)
      .eq('is_verified', true)
      .single();

    if (checkError && checkError.code !== 'PGRST116') {
      throw checkError;
    }

    if (existingCompletion && !task.is_repeatable) {
      return { success: false, pointsAwarded: 0, newBadges: [], error: 'Task already completed' };
    }

    if (task.is_repeatable && existingCompletion) {
      const cooldownEnd = new Date(existingCompletion.completed_at);
      cooldownEnd.setHours(cooldownEnd.getHours() + (task.repeat_cooldown_hours || 24));

      if (new Date() < cooldownEnd) {
        return { success: false, pointsAwarded: 0, newBadges: [], error: 'Task on cooldown' };
      }
    }

    if (task.max_completions && task.current_completions >= task.max_completions) {
      return { success: false, pointsAwarded: 0, newBadges: [], error: 'Task completion limit reached' };
    }

    const { data: user, error: userError } = await getSupabaseClient()
      .from('users')
      .select('raw_points')
      .eq('id', userId)
      .single();

    if (userError) throw userError;

    const { error: insertError } = await getSupabaseClient()
      .from('task_completions')
      .insert({
        user_id: userId,
        task_id: taskId,
        verification_data: verificationData || {},
        is_verified: true,
        points_awarded: task.points,
        completed_at: new Date().toISOString()
      });

    if (insertError) {
      return { success: false, pointsAwarded: 0, newBadges: [], error: 'Failed to record completion' };
    }

    const newBalance = (user.raw_points || 0) + task.points;

    const { error: updateError } = await getSupabaseClient()
      .from('users')
      .update({
        raw_points: newBalance,
        total_tasks_completed: getSupabaseClient().raw('total_tasks_completed + 1')
      })
      .eq('id', userId);

    if (updateError) {
      logEvent('task_complete_update_error', { userId, taskId, error: updateError });
    }

    if (task.max_completions) {
      await getSupabaseClient()
        .from('tasks')
        .update({ current_completions: task.current_completions + 1 })
        .eq('id', taskId);
    }

    const { badgeService } = await import('./badgeService');
    const newBadges = await badgeService.checkAndAwardBadges(userId);

    await logEvent('task_completed', { userId, taskId, points: task.points });

    return {
      success: true,
      pointsAwarded: task.points,
      newBadges
    };
  }

  async verifyExternalTask(
    userId: string,
    taskId: string,
    verificationData: Record<string, any>
  ): Promise<{
    verified: boolean;
    error?: string;
  }> {
    const task = await this.getTaskById(taskId);

    if (!task) {
      return { verified: false, error: 'Task not found' };
    }

    switch (task.task_type) {
      case 'telegram_join':
        return this.verifyTelegramJoin(userId, task, verificationData);

      case 'twitter_follow':
        return this.verifyTwitterFollow(userId, task, verificationData);

      case 'youtube_subscribe':
        return this.verifyYouTubeSubscribe(userId, task, verificationData);

      case 'discord_join':
        return this.verifyDiscordJoin(userId, task, verificationData);

      default:
        return { verified: true };
    }
  }

  private async verifyTelegramJoin(
    userId: string,
    task: Task,
    verificationData: Record<string, any>
  ): Promise<{ verified: boolean; error?: string }> {
    if (!task.telegram_channel_id) {
      return { verified: true };
    }

    try {
      const response = await fetch(
        `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/getChatMember`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: task.telegram_channel_id,
            user_id: verificationData.telegram_user_id
          })
        }
      );

      if (!response.ok) {
        return { verified: false, error: 'Failed to verify Telegram membership' };
      }

      const data = await response.json();
      const status = data.result?.status;

      const validStatuses = ['member', 'administrator', 'creator'];

      if (!validStatuses.includes(status)) {
        return { verified: false, error: 'User is not a channel member' };
      }

      return { verified: true };
    } catch (error) {
      return { verified: false, error: 'Verification failed' };
    }
  }

  private async verifyTwitterFollow(
    userId: string,
    task: Task,
    verificationData: Record<string, any>
  ): Promise<{ verified: boolean; error?: string }> {
    if (!task.twitter_username) {
      return { verified: true };
    }

    try {
      const response = await fetch(
        `https://api.twitter.com/2/users/by/username/${task.twitter_username}/following`,
        {
          headers: {
            Authorization: `Bearer ${process.env.TWITTER_BEARER_TOKEN}`
          }
        }
      );

      if (!response.ok) {
        return { verified: false, error: 'Failed to verify Twitter follow' };
      }

      const data = await response.json();

      return { verified: true };
    } catch (error) {
      return { verified: false, error: 'Verification failed' };
    }
  }

  private async verifyYouTubeSubscribe(
    userId: string,
    task: Task,
    verificationData: Record<string, any>
  ): Promise<{ verified: boolean; error?: string }> {
    if (!task.youtube_channel_id) {
      return { verified: true };
    }

    return { verified: true };
  }

  private async verifyDiscordJoin(
    userId: string,
    task: Task,
    verificationData: Record<string, any>
  ): Promise<{ verified: boolean; error?: string }> {
    if (!task.discord_invite_code) {
      return { verified: true };
    }

    return { verified: true };
  }

  async getUserTaskHistory(
    userId: string,
    limit: number = 50
  ): Promise<TaskCompletion[]> {
    const { data, error } = await getSupabaseClient()
      .from('task_completions')
      .select('*, tasks(*)')
      .eq('user_id', userId)
      .order('completed_at', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return data?.map(c => ({
      id: c.id,
      user_id: c.user_id,
      task_id: c.task_id,
      completed_at: c.completed_at,
      verification_data: c.verification_data,
      is_verified: c.is_verified,
      points_awarded: c.points_awarded
    })) || [];
  }

  async getTaskStats(): Promise<{
    totalTasks: number;
    activeTasks: number;
    totalCompletions: number;
    popularTasks: Array<{ taskId: string; title: string; completions: number }>;
  }> {
    const { count: totalTasks } = await getSupabaseClient()
      .from('tasks')
      .select('id', { count: 'exact' });

    const { count: activeTasks } = await getSupabaseClient()
      .from('tasks')
      .select('id', { count: 'exact' })
      .eq('is_active', true);

    const { count: totalCompletions } = await getSupabaseClient()
      .from('task_completions')
      .select('id', { count: 'exact' })
      .eq('is_verified', true);

    const { data: popularTasks } = await getSupabaseClient()
      .from('task_completions')
      .select('task_id, tasks!inner(title)', { count: 'exact' })
      .eq('is_verified', true)
      .group('task_id')
      .order('count', { ascending: false })
      .limit(10);

    return {
      totalTasks: totalTasks || 0,
      activeTasks: activeTasks || 0,
      totalCompletions: totalCompletions || 0,
      popularTasks: popularTasks?.map(t => ({
        taskId: t.task_id,
        title: t.tasks?.title || 'Unknown',
        completions: t.count || 0
      })) || []
    };
  }

  private async getUserWalletInfo(userId: string): Promise<{
    connected: boolean;
    walletAddress?: string;
  }> {
    const { data: user, error } = await getSupabaseClient()
      .from('users')
      .select('wallet_address')
      .eq('id', userId)
      .single();

    if (error || !user) {
      return { connected: false };
    }

    return {
      connected: !!user.wallet_address,
      walletAddress: user.wallet_address || undefined
    };
  }
}

export const taskService = new TaskService();
export type { Task, TaskCompletion, TaskWithProgress };
