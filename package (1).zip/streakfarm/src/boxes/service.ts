import { randomInt } from 'crypto';
import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';
import { awardPoints } from '../points/service';
import { badgeService } from '../badges/service';
import { getUser } from '../users/service';
import { calculateTotalMultiplier } from '../multipliers/service';
import { redisCache } from '../cache/redis';

interface Box {
  id: string;
  user_id: string;
  generated_at: string;
  expires_at: string;
  opened_at: string | null;
  base_points: number;
  multiplier_applied: number;
  final_points: number;
  rarity: 'common' | 'rare' | 'legendary';
  is_expired: boolean;
}

interface BoxGenerationResult {
  userId: string;
  boxId: string;
  rarity: 'common' | 'rare' | 'legendary';
  basePoints: number;
}

const BOX_RARITY_CHANCES = {
  legendary: 0.001,
  rare: 0.05,
  common: 0.949
};

const BOX_POINT_RANGES = {
  common: { min: 50, max: 1000 },
  rare: { min: 5000, max: 10000 },
  legendary: { min: 10000, max: 50000 }
};

function generateBoxRarity(): 'common' | 'rare' | 'legendary' {
  const rand = Math.random();
  if (rand < BOX_RARITY_CHANCES.legendary) return 'legendary';
  if (rand < BOX_RARITY_CHANCES.legendary + BOX_RARITY_CHANCES.rare) return 'rare';
  return 'common';
}

function generateBasePoints(rarity: 'common' | 'rare' | 'legendary'): number {
  const range = BOX_POINT_RANGES[rarity];
  return randomInt(range.min, range.max + 1);
}

class BoxService {
  async generateBoxes(batchSize: number = 100000): Promise<{ generated: number; errors: number }> {
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    let offset = 0;
    let generated = 0;
    let errors = 0;

    try {
      while (true) {
        const { data: activeUsers, error } = await getSupabaseClient()
          .from('users')
          .select('id')
          .gte('last_active_at', new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString())
          .eq('is_banned', false)
          .eq('is_bot', false)
          .range(offset, offset + batchSize - 1);

        if (error) {
          logEvent('box_generation_error', { error: error.message, offset });
          errors++;
          offset += batchSize;
          continue;
        }

        if (!activeUsers || activeUsers.length === 0) break;

        const boxes = activeUsers.map(user => {
          const rarity = generateBoxRarity();
          const basePoints = generateBasePoints(rarity);

          return {
            user_id: user.id,
            generated_at: now.toISOString(),
            expires_at: new Date(now.getTime() + 3 * 60 * 60 * 1000).toISOString(),
            base_points: basePoints,
            rarity,
            is_expired: false,
            opened_at: null,
            multiplier_applied: 1.0,
            final_points: null
          };
        });

        const { error: insertError } = await getSupabaseClient()
          .from('boxes')
          .insert(boxes);

        if (insertError) {
          logEvent('box_insert_error', { error: insertError.message, count: boxes.length });
          errors++;
        } else {
          generated += boxes.length;
        }

        offset += batchSize;

        if (activeUsers.length < batchSize) break;
      }

      await logEvent('boxes_generated', { count: generated, errors, timestamp: now.toISOString() });
      return { generated, errors };
    } catch (error) {
      logEvent('box_generation_critical_error', { error });
      throw error;
    }
  }

  async getUserAvailableBoxes(userId: string): Promise<Box[]> {
    const cacheKey = `user_boxes:${userId}`;
    const cached = await redisCache.get<Box[]>(cacheKey);
    if (cached) return cached;

    const { data, error } = await getSupabaseClient()
      .from('boxes')
      .select('*')
      .eq('user_id', userId)
      .eq('is_expired', false)
      .is('opened_at', null)
      .gte('expires_at', new Date().toISOString())
      .order('generated_at', { ascending: false });

    if (error) throw error;

    await redisCache.set(cacheKey, data || [], 30);
    return data || [];
  }

  async getUserBoxStats(userId: string): Promise<{
    available: number;
    openedToday: number;
    missed: number;
    totalOpened: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data: availableBoxes } = await getSupabaseClient()
      .from('boxes')
      .select('id', { count: 'exact' })
      .eq('user_id', userId)
      .eq('is_expired', false)
      .is('opened_at', null)
      .gte('expires_at', new Date().toISOString());

    const { data: openedToday } = await getSupabaseClient()
      .from('boxes')
      .select('id', { count: 'exact' })
      .eq('user_id', userId)
      .gte('opened_at', today.toISOString());

    const { data: missedBoxes } = await getSupabaseClient()
      .from('boxes')
      .select('id', { count: 'exact' })
      .eq('user_id', userId)
      .eq('is_expired', true);

    const { data: user } = await getSupabaseClient()
      .from('users')
      .select('total_boxes_opened')
      .eq('id', userId)
      .single();

    return {
      available: availableBoxes?.count || 0,
      openedToday: openedToday?.count || 0,
      missed: missedBoxes?.count || 0,
      totalOpened: user?.total_boxes_opened || 0
    };
  }

  async openBox(userId: string, boxId: string): Promise<{
    success: boolean;
    box?: Box;
    finalPoints: number;
    rarity: string;
    multiplier: number;
    basePoints: number;
    newBadges: any[];
    error?: string;
  }> {
    try {
      const { data: box, error: boxError } = await getSupabaseClient()
        .from('boxes')
        .select('*')
        .eq('id', boxId)
        .eq('user_id', userId)
        .is('opened_at', null)
        .single();

      if (boxError || !box) {
        return { success: false, finalPoints: 0, rarity: '', multiplier: 0, basePoints: 0, newBadges: [], error: 'Box not found or already opened' };
      }

      const now = new Date();
      const expiresAt = new Date(box.expires_at);

      if (box.is_expired || now > expiresAt) {
        await getSupabaseClient()
          .from('boxes')
          .update({ is_expired: true })
          .eq('id', boxId);

        return { success: false, finalPoints: 0, rarity: '', multiplier: 0, basePoints: 0, newBadges: [], error: 'Box has expired' };
      }

      const user = await getUser(userId);
      const multiplier = await calculateTotalMultiplier(user);
      const finalPoints = Math.floor(box.base_points * multiplier);

      const { error: updateBoxError } = await getSupabaseClient()
        .from('boxes')
        .update({
          opened_at: now.toISOString(),
          multiplier_applied: multiplier,
          final_points: finalPoints,
          is_expired: false
        })
        .eq('id', boxId);

      if (updateBoxError) {
        return { success: false, finalPoints: 0, rarity: '', multiplier: 0, basePoints: 0, newBadges: [], error: 'Failed to update box' };
      }

      await awardPoints(userId, finalPoints, { source: 'box', boxId, rarity: box.rarity });

      const { error: updateUserError } = await getSupabaseClient()
        .from('users')
        .update({
          total_boxes_opened: getSupabaseClient().raw('total_boxes_opened + 1'),
          last_active_at: now.toISOString()
        })
        .eq('id', userId);

      if (updateUserError) {
        logEvent('box_open_user_update_error', { userId, error: updateUserError.message });
      }

      const newBadges = await badgeService.checkAndAwardBadges(userId);

      await redisCache.del(`user_boxes:${userId}`);

      return {
        success: true,
        box: { ...box, opened_at: now.toISOString(), multiplier_applied: multiplier, final_points: finalPoints },
        finalPoints,
        rarity: box.rarity,
        multiplier,
        basePoints: box.base_points,
        newBadges
      };
    } catch (error) {
      logEvent('box_open_error', { userId, boxId, error });
      return { success: false, finalPoints: 0, rarity: '', multiplier: 0, basePoints: 0, newBadges: [], error: 'Internal error' };
    }
  }

  async getBoxHistory(userId: string, limit: number = 20): Promise<Box[]> {
    const { data, error } = await getSupabaseClient()
      .from('boxes')
      .select('*')
      .eq('user_id', userId)
      .not('opened_at', 'is', null)
      .order('opened_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data || [];
  }

  async expireOldBoxes(): Promise<{ expired: number; errors: number }> {
    const now = new Date().toISOString();
    let expired = 0;
    let errors = 0;

    try {
      const { data: oldBoxes, error } = await getSupabaseClient()
        .from('boxes')
        .select('id, user_id')
        .eq('is_expired', false)
        .is('opened_at', null)
        .lt('expires_at', now)
        .limit(50000);

      if (error) throw error;

      if (!oldBoxes || oldBoxes.length === 0) {
        return { expired: 0, errors: 0 };
      }

      const boxIds = oldBoxes.map(b => b.id);
      const { error: updateError } = await getSupabaseClient()
        .from('boxes')
        .update({ is_expired: true })
        .in('id', boxIds);

      if (updateError) {
        errors += boxIds.length;
      } else {
        expired = boxIds.length;

        const uniqueUserIds = [...new Set(oldBoxes.map(b => b.user_id))];
        for (const uid of uniqueUserIds) {
          await redisCache.del(`user_boxes:${uid}`);
        }
      }

      logEvent('boxes_expired', { count: expired, errors });
      return { expired, errors };
    } catch (error) {
      logEvent('box_expiration_error', { error });
      throw error;
    }
  }

  async cleanupOldBoxes(retentionDays: number = 30): Promise<{ deleted: number }> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

    const { data, error } = await getSupabaseClient()
      .from('boxes')
      .select('id')
      .lt('generated_at', cutoffDate.toISOString())
      .limit(100000);

    if (error) throw error;

    if (!data || data.length === 0) {
      return { deleted: 0 };
    }

    const { error: deleteError } = await getSupabaseClient()
      .from('boxes')
      .delete()
      .in('id', data.map(d => d.id));

    if (deleteError) throw deleteError;

    logEvent('boxes_cleaned_up', { count: data.length, retentionDays });
    return { deleted: data.length };
  }
}

export const boxService = new BoxService();
export type { Box, BoxGenerationResult };
