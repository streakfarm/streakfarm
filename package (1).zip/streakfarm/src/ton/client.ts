import { Address, Cell } from '@ton/core';
import { logEvent } from '../utils/logger';

const TON_API_ENDPOINT = process.env.TON_API_ENDPOINT || 'https://toncenter.com/api/v2/jsonRPC';
const TON_API_KEY = process.env.TON_API_KEY;
const TON_NFT_INDEXER = process.env.TON_NFT_INDEXER || 'https://tonapi.io/v2';

interface TonApiConfig {
  endpoint: string;
  apiKey?: string;
}

function getTonApiConfig(): TonApiConfig {
  return {
    endpoint: TON_API_ENDPOINT,
    apiKey: TON_API_KEY
  };
}

export async function getTONBalance(walletAddress: string): Promise<number> {
  try {
    const config = getTonApiConfig();
    let address = walletAddress;

    try {
      address = Address.parse(walletAddress).toString();
    } catch {
      address = walletAddress;
    }

    const url = new URL('/getAddressBalance', config.endpoint);
    url.searchParams.set('address', address);

    const headers: HeadersInit = {
      'Content-Type': 'application/json'
    };

    if (config.apiKey) {
      headers['X-API-Key'] = config.apiKey;
    }

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    if (!response.ok) {
      logEvent('ton_api_error', { endpoint: url.toString(), status: response.status });
      return 0;
    }

    const data = await response.json();
    const nanoTon = BigInt(data.result || '0');
    const tonBalance = Number(nanoTon) / 1e9;

    return tonBalance;
  } catch (error) {
    logEvent('ton_balance_error', { walletAddress, error });
    return 0;
  }
}

export async function getUserNFTs(walletAddress: string): Promise<Array<{
  collectionAddress: string;
  itemAddress: string;
  name: string;
  imageUrl?: string;
  metadata?: Record<string, any>;
}>> {
  try {
    const config = getTonApiConfig();
    let address = walletAddress;

    try {
      address = Address.parse(walletAddress).toString();
    } catch {
      address = walletAddress;
    }

    const response = await fetch(`${TON_NFT_INDEXER}/nft/searchItems`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(config.apiKey && { 'Authorization': `Bearer ${config.apiKey}` })
      },
      body: JSON.stringify({
        owner: address,
        limit: 100,
        include_children: false
      })
    });

    if (!response.ok) {
      logEvent('ton_nft_api_error', { status: response.status });
      return [];
    }

    const data = await response.json();
    const nftItems = data.nft_items || [];

    return nftItems.map((item: any) => ({
      collectionAddress: item.collection?.address || '',
      itemAddress: item.address,
      name: item.name || 'Unknown NFT',
      imageUrl: item.previews?.[0] || item.image || item.metadata?.image,
      metadata: item.metadata || {}
    }));
  } catch (error) {
    logEvent('ton_nft_fetch_error', { walletAddress, error });
    return [];
  }
}

export async function getJettonBalance(walletAddress: string, jettonMasterAddress: string): Promise<{
  balance: number;
  decimals: number;
  symbol: string;
}> {
  try {
    const config = getTonApiConfig();
    let address = walletAddress;

    try {
      address = Address.parse(walletAddress).toString();
    } catch {
      address = walletAddress;
    }

    const response = await fetch(`${TON_NFT_INDEXER}/jettons/getJettonBalance`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(config.apiKey && { 'Authorization': `Bearer ${config.apiKey}` })
      },
      body: JSON.stringify({
        address,
        jetton_master: jettonMasterAddress
      })
    });

    if (!response.ok) {
      return { balance: 0, decimals: 9, symbol: 'UNKNOWN' };
    }

    const data = await response.json();
    const balance = Number(data.balance || '0') / Math.pow(10, data.decimals || 9);

    return {
      balance,
      decimals: data.decimals || 9,
      symbol: data.symbol || 'UNKNOWN'
    };
  } catch (error) {
    logEvent('ton_jetton_error', { walletAddress, jettonMasterAddress, error });
    return { balance: 0, decimals: 9, symbol: 'UNKNOWN' };
  }
}

export async function sendTonTransaction(
  fromAddress: string,
  privateKey: string,
  toAddress: string,
  amount: number
): Promise<{
  success: boolean;
  transactionHash?: string;
  error?: string;
}> {
  try {
    const config = getTonApiConfig();
    let from = fromAddress;
    let to = toAddress;

    try {
      from = Address.parse(fromAddress).toString();
      to = Address.parse(toAddress).toString();
    } catch {
      return { success: false, error: 'Invalid address format' };
    }

    const nanoAmount = BigInt(Math.floor(amount * 1e9));

    const body = {
      from,
      to,
      amount: nanoAmount.toString(),
      bounce: false
    };

    const headers: HeadersInit = {
      'Content-Type': 'application/json'
    };

    if (config.apiKey) {
      headers['X-API-Key'] = config.apiKey;
    }

    const response = await fetch(`${config.endpoint}/sendBoc`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const error = await response.text();
      return { success: false, error };
    }

    const data = await response.json();
    const transactionHash = data.result || data.hash;

    return { success: true, transactionHash };
  } catch (error) {
    logEvent('ton_send_error', { fromAddress, toAddress, amount, error });
    return { success: false, error: 'Transaction failed' };
  }
}

export async function getTransactionHistory(
  walletAddress: string,
  limit: number = 20
): Promise<Array<{
  hash: string;
  timestamp: string;
  direction: 'in' | 'out';
  amount: number;
  otherParty: string;
  status: 'pending' | 'confirmed' | 'failed';
}>> {
  try {
    const config = getTonApiConfig();
    let address = walletAddress;

    try {
      address = Address.parse(walletAddress).toString();
    } catch {
      address = walletAddress;
    }

    const response = await fetch(`${TON_NFT_INDEXER}/accounts/${address}/transactions`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(config.apiKey && { 'Authorization': `Bearer ${config.apiKey}` })
      }
    });

    if (!response.ok) {
      return [];
    }

    const data = await response.json();
    const transactions = (data.transactions || []).slice(0, limit);

    return transactions.map((tx: any) => ({
      hash: tx.hash || tx.in_msg?.hash || '',
      timestamp: new Date((tx.utime || Date.now() / 1000) * 1000).toISOString(),
      direction: tx.in_msg ? 'in' : 'out',
      amount: Number(tx.in_msg?.value || tx.out_msgs?.[0]?.value || 0) / 1e9,
      otherParty: tx.in_msg?.source || tx.out_msgs?.[0]?.destination || '',
      status: tx.ignored ? 'failed' : 'confirmed'
    }));
  } catch (error) {
    logEvent('ton_history_error', { walletAddress, error });
    return [];
  }
}

export async function validateAddress(address: string): Promise<boolean> {
  try {
    Address.parse(address);
    return true;
  } catch {
    return false;
  }
}

export function formatTonAddress(address: string, bounceable: boolean = true): string {
  try {
    return Address.parse(address).toString({ bounceable });
  } catch {
    return address;
  }
}

export function formatTonAmount(nanoTon: string | bigint, decimals: number = 9): string {
  const amount = typeof nanoTon === 'string' ? BigInt(nanoTon) : nanoTon;
  const divisor = BigInt(10 ** decimals);
  const whole = amount / divisor;
  const fractional = amount % divisor;

  if (fractional === 0n) {
    return whole.toString();
  }

  const fractionalStr = fractional.toString().padStart(decimals, '0');
  const trimmedFractional = fractionalStr.replace(/0+$/, '');

  return `${whole}.${trimmedFractional}`;
}

export function parseTonAmount(ton: string): bigint {
  const parts = ton.split('.');
  const whole = parts[0] || '0';
  const fractional = parts[1] || '';
  const paddedFractional = fractional.padEnd(9, '0').slice(0, 9);

  return (BigInt(whole) * BigInt(10) ** BigInt(9)) + BigInt(paddedFractional);
}
