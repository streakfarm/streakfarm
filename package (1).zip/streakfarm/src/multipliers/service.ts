import { getSupabaseClient } from '../db/client';
import { redisCache } from '../cache/redis';
import { logEvent } from '../utils/logger';

interface StreakMultiplier {
  days: number;
  multiplier: number;
}

const STREAK_MULTIPLIERS: StreakMultiplier[] = [
  { days: 1, multiplier: 1.0 },
  { days: 3, multiplier: 1.2 },
  { days: 7, multiplier: 1.5 },
  { days: 14, multiplier: 2.0 },
  { days: 30, multiplier: 2.5 },
  { days: 60, multiplier: 3.0 },
  { days: 90, multiplier: 4.0 },
  { days: 180, multiplier: 5.0 },
  { days: 365, multiplier: 10.0 },
  { days: 730, multiplier: 15.0 }
];

function calculateStreakMultiplier(streakDays: number): number {
  const tier = STREAK_MULTIPLIERS
    .slice()
    .reverse()
    .find(t => streakDays >= t.days);

  return tier?.multiplier || 1.0;
}

export async function calculateTotalMultiplier(user: {
  id: string;
  multiplier_permanent: number;
  streak_current: number;
}): Promise<number> {
  const cacheKey = `user_multiplier:${user.id}`;
  const cached = await redisCache.get<number>(cacheKey);

  if (cached !== null) {
    return cached;
  }

  const badgeMultiplier = user.multiplier_permanent || 1.0;
  const streakMultiplier = calculateStreakMultiplier(user.streak_current);

  const finalMultiplier = badgeMultiplier + (streakMultiplier - 1.0);
  const result = Math.max(1.0, finalMultiplier);

  await redisCache.set(cacheKey, result, 300);

  return result;
}

export function getStreakMultiplierTable(): StreakMultiplier[] {
  return STREAK_MULTIPLIERS;
}

export function getCurrentStreakMultiplier(streakDays: number): number {
  return calculateStreakMultiplier(streakDays);
}

export async function getMultiplierBreakdown(userId: string): Promise<{
  baseMultiplier: number;
  badgeMultiplier: number;
  streakMultiplier: number;
  totalMultiplier: number;
  badgeDetails: Array<{ name: string; multiplier: number; icon: string }>;
  streakTier: { days: number; multiplier: number; nextTierDays: number; nextTierMultiplier: number };
}> {
  const { data: user, error } = await getSupabaseClient()
    .from('users')
    .select('multiplier_permanent, streak_current')
    .eq('id', userId)
    .single();

  if (error) throw error;

  const badgeMultiplier = user.multiplier_permanent || 1.0;
  const streakMultiplier = calculateStreakMultiplier(user.streak_current);

  const { data: userBadges } = await getSupabaseClient()
    .from('user_badges')
    .select('badges!inner(name, multiplier, icon_emoji)')
    .eq('user_id', userId)
    .eq('is_active', true);

  const badgeDetails = userBadges?.map(ub => ({
    name: ub.badges.name,
    multiplier: ub.badges.multiplier,
    icon: ub.badges.icon_emoji
  })) || [];

  const currentTierIndex = STREAK_MULTIPLIERS.findIndex(
    t => t.days > user.streak_current
  );
  const currentTier = currentTierIndex > 0 ? STREAK_MULTIPLIERS[currentTierIndex - 1] : STREAK_MULTIPLIERS[STREAK_MULTIPLIERS.length - 1];
  const nextTier = currentTierIndex >= 0 ? STREAK_MULTIPLIERS[currentTierIndex] : null;

  return {
    baseMultiplier: 1.0,
    badgeMultiplier,
    streakMultiplier,
    totalMultiplier: badgeMultiplier + (streakMultiplier - 1.0),
    badgeDetails,
    streakTier: {
      days: user.streak_current,
      multiplier: currentTier.multiplier,
      nextTierDays: nextTier?.days || 0,
      nextTierMultiplier: nextTier?.multiplier || 0
    }
  };
}

export function formatMultiplier(multiplier: number): string {
  return `${multiplier.toFixed(2)}×`;
}
