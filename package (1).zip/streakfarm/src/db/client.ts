import { createClient, SupabaseClient, RealtimeChannel } from '@supabase/supabase-js';
import { logEvent } from '../utils/logger';
import Sentry from '@sentry/node';

let supabaseClient: SupabaseClient | null = null;
let supabaseAdmin: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient {
  if (supabaseClient) return supabaseClient;

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error('SUPABASE_URL and SUPABASE_ANON_KEY must be defined');
  }

  supabaseClient = createClient(url, anonKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false
    },
    realtime: {
      params: {
        eventsPerSecond: 10
      }
    }
  });

  return supabaseClient;
}

export function getSupabaseAdmin(): SupabaseClient {
  if (supabaseAdmin) return supabaseAdmin;

  const url = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error('SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be defined');
  }

  supabaseAdmin = createClient(url, serviceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false
    }
  });

  return supabaseAdmin;
}

export async function initializeRealtimeSubscriptions(userId: string): Promise<RealtimeChannel> {
  const client = getSupabaseClient();

  const channel = client.channel(`user:${userId}`, {
    config: {
      presence: {
        key: userId
      }
    }
  });

  channel
    .on('presence', { event: 'sync' }, () => {
      const state = channel.presenceState();
      logEvent('realtime_sync', { userId, state: Object.keys(state).length });
    })
    .subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await channel.track({
          userId,
          onlineAt: new Date().toISOString()
        });
      }
    });

  return channel;
}

export const supabase = {
  client: getSupabaseClient,
  admin: getSupabaseAdmin,
  realtime: initializeRealtimeSubscriptions
};

export type { SupabaseClient, RealtimeChannel };
