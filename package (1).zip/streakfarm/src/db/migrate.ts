import { getSupabaseAdmin } from './client';
import { logEvent } from '../utils/logger';
import * as fs from 'fs';
import * as path from 'path';

const MIGRATIONS_TABLE = 'schema_migrations';

async function ensureMigrationsTable(): Promise<void> {
  const supabase = getSupabaseAdmin();

  const createTableSQL = `
    CREATE TABLE IF NOT EXISTS ${MIGRATIONS_TABLE} (
      id TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ DEFAULT NOW()
    );
  `;

  const { error } = await supabase.rpc('exec_sql', { sql: createTableSQL });

  if (error) {
    const createTableErrorFix = `
      CREATE TABLE IF NOT EXISTS ${MIGRATIONS_TABLE} (
        id TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      );
    `;
    const { error: directError } = await supabase.from(MIGRATIONS_TABLE).select('id').limit(1);

    if (directError) {
      await supabase.from(MIGRATIONS_TABLE).insert({ id: 'init' }).catch(() => {});
    }
  }
}

async function getAppliedMigrations(): Promise<Set<string>> {
  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from(MIGRATIONS_TABLE)
    .select('id')
    .order('id');

  if (error) {
    return new Set();
  }

  return new Set(data?.map(m => m.id) || []);
}

async function applyMigration(migrationName: string, sql: string): Promise<void> {
  const supabase = getSupabaseAdmin();

  try {
    const statements = sql
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--'))
      .map(s => s + ';');

    for (const statement of statements) {
      const { error } = await supabase.rpc('exec_sql', { sql: statement });

      if (error) {
        throw new Error(`Failed to execute statement: ${error.message}`);
      }
    }

    await supabase.from(MIGRATIONS_TABLE).insert({ id: migrationName });

    logEvent('migration_applied', { migration: migrationName });
  } catch (error) {
    logEvent('migration_failed', { migration: migrationName, error });
    throw error;
  }
}

export async function runMigrations(): Promise<void> {
  logEvent('migration_start');

  await ensureMigrationsTable();

  const migrationsDir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(migrationsDir)
    .filter(f => f.endsWith('.sql'))
    .sort();

  const appliedMigrations = await getAppliedMigrations();

  for (const file of files) {
    const migrationName = file.replace('.sql', '');

    if (appliedMigrations.has(migrationName)) {
      logEvent('migration_skip', { migration: migrationName });
      continue;
    }

    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf-8');
    logEvent('migration_executing', { migration: migrationName });

    await applyMigration(migrationName, sql);
  }

  logEvent('migration_complete', { total: files.length });
}

if (require.main === module) {
  runMigrations()
    .then(() => {
      console.log('Migrations completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Migration failed:', error);
      process.exit(1);
    });
}
