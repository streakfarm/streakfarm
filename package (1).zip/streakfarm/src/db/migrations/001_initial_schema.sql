-- Migration: 001_initial_schema
-- Creates core tables for StreakFarm Telegram Mini App

-- USERS table with enhanced fields for badges and anti-fraud
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id BIGINT UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT,
  language_code TEXT DEFAULT 'en',
  
  raw_points BIGINT DEFAULT 0,
  
  streak_current INT DEFAULT 0,
  streak_best INT DEFAULT 0,
  last_checkin TIMESTAMPTZ,
  
  total_boxes_opened INT DEFAULT 0,
  total_tasks_completed INT DEFAULT 0,
  total_referrals INT DEFAULT 0,
  bots_reported INT DEFAULT 0,
  
  wallet_address TEXT,
  wallet_type TEXT,
  wallet_connected_at TIMESTAMPTZ,
  
  multiplier_permanent DECIMAL DEFAULT 1.0,
  
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  ref_code TEXT UNIQUE DEFAULT substr(md5(random()::text), 1, 8),
  referred_by UUID REFERENCES users(id),
  
  fingerprint TEXT,
  ip_address INET,
  user_agent TEXT,
  is_flagged BOOLEAN DEFAULT FALSE,
  flag_reason TEXT,
  is_banned BOOLEAN DEFAULT FALSE,
  ban_reason TEXT,
  is_bot BOOLEAN DEFAULT FALSE,
  report_count INT DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  last_active_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_users_points ON users(raw_points DESC) WHERE is_banned = FALSE AND is_bot = FALSE;
CREATE INDEX IF NOT EXISTS idx_users_ref_code ON users(ref_code);
CREATE INDEX IF NOT EXISTS idx_users_wallet ON users(wallet_address) WHERE wallet_address IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_joined_at ON users(joined_at ASC);
CREATE INDEX IF NOT EXISTS idx_users_last_active ON users(last_active_at DESC);
CREATE INDEX IF NOT EXISTS idx_users_streak ON users(streak_current DESC) WHERE is_banned = FALSE AND is_bot = FALSE;

-- BOXES table for hourly box system
CREATE TABLE IF NOT EXISTS boxes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  generated_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  opened_at TIMESTAMPTZ,
  base_points INT NOT NULL,
  multiplier_applied DECIMAL DEFAULT 1.0,
  final_points INT,
  rarity TEXT NOT NULL CHECK (rarity IN ('common', 'rare', 'legendary')),
  is_expired BOOLEAN DEFAULT FALSE,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for boxes table
CREATE INDEX IF NOT EXISTS idx_boxes_user ON boxes(user_id);
CREATE INDEX IF NOT EXISTS idx_boxes_user_open ON boxes(user_id, opened_at) WHERE opened_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_boxes_expires ON boxes(expires_at) WHERE opened_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_boxes_generated ON boxes(generated_at DESC);

-- BADGES table for badge system
CREATE TABLE IF NOT EXISTS badges (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon_emoji TEXT NOT NULL,
  image_url TEXT,
  
  badge_category TEXT NOT NULL CHECK (badge_category IN ('streak', 'achievement', 'wallet', 'special')),
  multiplier DECIMAL NOT NULL DEFAULT 1.0,
  rarity TEXT NOT NULL CHECK (rarity IN ('common', 'rare', 'epic', 'legendary', 'mythic')),
  
  requirements JSONB DEFAULT '{}',
  
  max_supply INT,
  current_supply INT DEFAULT 0,
  
  is_active BOOLEAN DEFAULT TRUE,
  available_from TIMESTAMPTZ,
  available_until TIMESTAMPTZ,
  
  can_convert_to_nft BOOLEAN DEFAULT TRUE,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for badges table
CREATE INDEX IF NOT EXISTS idx_badges_category ON badges(badge_category);
CREATE INDEX IF NOT EXISTS idx_badges_active ON badges(is_active);
CREATE INDEX IF NOT EXISTS idx_badges_supply ON badges(current_supply) WHERE max_supply IS NOT NULL;

-- USER_BADGES table for owned badges
CREATE TABLE IF NOT EXISTS user_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id TEXT NOT NULL REFERENCES badges(id),
  
  earned_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT TRUE,
  
  converted_to_nft BOOLEAN DEFAULT FALSE,
  nft_address TEXT,
  converted_at TIMESTAMPTZ,
  
  UNIQUE(user_id, badge_id)
);

-- Indexes for user_badges table
CREATE INDEX IF NOT EXISTS idx_user_badges_user ON user_badges(user_id);
CREATE INDEX IF NOT EXISTS idx_user_badges_badge ON user_badges(badge_id);
CREATE INDEX IF NOT EXISTS idx_user_badges_earned ON user_badges(earned_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_badges_active ON user_badges(is_active) WHERE is_active = TRUE;

-- TASKS table for social tasks
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  points INT NOT NULL DEFAULT 0,
  task_type TEXT NOT NULL CHECK (task_type IN ('telegram_join', 'twitter_follow', 'youtube_subscribe', 'discord_join', 'external_link', 'wallet_task', 'daily_login', 'invite')),
  
  external_url TEXT,
  telegram_channel_id TEXT,
  twitter_username TEXT,
  youtube_channel_id TEXT,
  discord_invite_code TEXT,
  
  requires_wallet BOOLEAN DEFAULT FALSE,
  is_repeatable BOOLEAN DEFAULT FALSE,
  repeat_cooldown_hours INT,
  
  is_active BOOLEAN DEFAULT TRUE,
  max_completions INT,
  current_completions INT DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for tasks table
CREATE INDEX IF NOT EXISTS idx_tasks_active ON tasks(is_active);
CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(task_type);

-- TASK_COMPLETIONS table
CREATE TABLE IF NOT EXISTS task_completions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_id TEXT NOT NULL REFERENCES tasks(id),
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  verification_data JSONB,
  is_verified BOOLEAN DEFAULT FALSE,
  points_awarded INT DEFAULT 0,
  
  UNIQUE(user_id, task_id, completed_at)
);

-- Indexes for task_completions
CREATE INDEX IF NOT EXISTS idx_task_completions_user ON task_completions(user_id);
CREATE INDEX IF NOT EXISTS idx_task_completions_task ON task_completions(task_id);
CREATE INDEX IF NOT EXISTS idx_task_completions_completed ON task_completions(completed_at DESC);

-- REFERRALS table
CREATE TABLE IF NOT EXISTS referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  bonus_awarded BOOLEAN DEFAULT FALSE,
  bonus_points INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(referrer_id, referred_id)
);

-- Indexes for referrals
CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred ON referrals(referred_id);

-- USER_FLAGS table for anti-fraud
CREATE TABLE IF NOT EXISTS user_flags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  flag_type TEXT NOT NULL CHECK (flag_type IN ('suspicious_activity', 'bot_detected', 'multiple_accounts', 'cheating', 'report_received')),
  severity TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  description TEXT,
  metadata JSONB,
  resolved BOOLEAN DEFAULT FALSE,
  resolved_by TEXT,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for user_flags
CREATE INDEX IF NOT EXISTS idx_user_flags_user ON user_flags(user_id);
CREATE INDEX IF NOT EXISTS idx_user_flags_type ON user_flags(flag_type);
CREATE INDEX IF NOT EXISTS idx_user_flags_unresolved ON user_flags(resolved) WHERE resolved = FALSE;

-- EVENTS table for analytics
CREATE TABLE IF NOT EXISTS events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type TEXT NOT NULL,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for events
CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_user ON events(user_id);
CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at DESC);

-- ADMIN_CONFIG table for dynamic configuration
CREATE TABLE IF NOT EXISTS admin_config (
  id TEXT PRIMARY KEY,
  config_key TEXT NOT NULL UNIQUE,
  config_value JSONB NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by TEXT
);

-- Indexes for admin_config
CREATE INDEX IF NOT EXISTS idx_admin_config_active ON admin_config(is_active);

-- LEADERBOARDS table
CREATE TABLE IF NOT EXISTS leaderboards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_type TEXT NOT NULL CHECK (period_type IN ('daily', 'weekly', 'monthly', 'all_time')),
  period_start TIMESTAMPTZ NOT NULL,
  period_end TIMESTAMPTZ NOT NULL,
  points INT DEFAULT 0,
  rank INT,
  boxes_opened INT DEFAULT 0,
  streak_days INT DEFAULT 0,
  badges_count INT DEFAULT 0,
  
  UNIQUE(user_id, period_type, period_start)
);

-- Indexes for leaderboards
CREATE INDEX IF NOT EXISTS idx_leaderboards_period ON leaderboards(period_type, period_start, points DESC);
CREATE INDEX IF NOT EXISTS idx_leaderboards_user ON leaderboards(user_id);

-- Points history table
CREATE TABLE IF NOT EXISTS points_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  points INT NOT NULL,
  source TEXT NOT NULL,
  source_id TEXT,
  balance_after BIGINT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for points_history
CREATE INDEX IF NOT EXISTS idx_points_history_user ON points_history(user_id);
CREATE INDEX IF NOT EXISTS idx_points_history_source ON points_history(source);
CREATE INDEX IF NOT EXISTS idx_points_history_created ON points_history(created_at DESC);

-- Functions and Triggers
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at
BEFORE UPDATE ON users
FOR EACH ROW
WHEN (OLD.* IS DISTINCT FROM NEW.*)
EXECUTE FUNCTION update_updated_at();

-- Function to update badge supply
CREATE OR REPLACE FUNCTION update_badge_supply()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE badges 
    SET current_supply = current_supply + 1 
    WHERE id = NEW.badge_id;
  ELSIF TG_OP = 'DELETE' OR (TG_OP = 'UPDATE' AND NEW.is_active = FALSE AND OLD.is_active = TRUE) THEN
    UPDATE badges 
    SET current_supply = GREATEST(0, current_supply - 1) 
    WHERE id = COALESCE(NEW.badge_id, OLD.badge_id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS badge_supply_trigger ON user_badges;

CREATE TRIGGER badge_supply_trigger
AFTER INSERT OR UPDATE OR DELETE ON user_badges
FOR EACH ROW EXECUTE FUNCTION update_badge_supply();

-- Function to prevent self-referral
CREATE OR REPLACE FUNCTION prevent_self_referral()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.referrer_id = NEW.referred_id THEN
    RAISE EXCEPTION 'Users cannot refer themselves';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER referrals_prevent_self
BEFORE INSERT ON referrals
FOR EACH ROW
EXECUTE FUNCTION prevent_self_referral();
