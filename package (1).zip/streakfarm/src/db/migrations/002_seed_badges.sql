-- Migration: 002_seed_badges
-- Seeds initial badges for StreakFarm

-- Streak Badges
INSERT INTO badges (id, name, description, icon_emoji, badge_category, multiplier, rarity, requirements) VALUES
  ('streak_7', '7-Day Streak', 'Maintained a 7-day streak', '🔥', 'streak', 1.1, 'common', '{"streak_days":7}'),
  ('streak_14', '14-Day Streak', 'Maintained a 14-day streak', '🔥', 'streak', 1.2, 'rare', '{"streak_days":14}'),
  ('streak_30', '30-Day Streak', 'Maintained a 30-day streak', '🔥', 'streak', 1.5, 'epic', '{"streak_days":30}'),
  ('streak_60', '60-Day Streak', 'Maintained a 60-day streak', '🔥', 'streak', 2.0, 'epic', '{"streak_days":60}'),
  ('streak_90', '90-Day Streak', 'Maintained a 90-day streak', '🔥', 'streak', 2.5, 'legendary', '{"streak_days":90}'),
  ('streak_180', '180-Day Streak', 'Maintained a 180-day streak', '🔥', 'streak', 3.0, 'legendary', '{"streak_days":180}'),
  ('streak_365', '365-Day Streak', 'Maintained a full year streak', '🔥', 'streak', 5.0, 'legendary', '{"streak_days":365}'),
  ('streak_730', '730-Day Streak', 'Maintained two full years streak', '🔥', 'streak', 10.0, 'mythic', '{"streak_days":730}')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  icon_emoji = EXCLUDED.icon_emoji,
  multiplier = EXCLUDED.multiplier,
  requirements = EXCLUDED.requirements;

-- Achievement Badges
INSERT INTO badges (id, name, description, icon_emoji, badge_category, multiplier, rarity, requirements, max_supply) VALUES
  ('founding_member', 'Founding Member', 'First 10,000 users', '👑', 'achievement', 2.0, 'legendary', '{"user_number_max":10000}', 10000),
  ('early_adopter', 'Early Adopter', 'Joined in Month 1', '🎁', 'achievement', 2.5, 'legendary', '{"joined_within_days":30}'),
  ('launch_week', 'Launch Week Hero', 'Joined in first week', '🎉', 'achievement', 3.0, 'legendary', '{"joined_within_days":7}'),
  ('millionaire', 'Millionaire', 'Earned 1,000,000 points', '💰', 'achievement', 1.5, 'epic', '{"total_points":1000000}'),
  ('multi_millionaire', 'Multi-Millionaire', 'Earned 10,000,000 points', '💰', 'achievement', 2.0, 'legendary', '{"total_points":10000000}'),
  ('top_100', 'Elite Farmer', 'Reached top 100 on leaderboard', '🏆', 'achievement', 2.0, 'legendary', '{"leaderboard_rank":100}'),
  ('top_10', 'Top 10 Legend', 'Reached top 10 on leaderboard', '🏆', 'achievement', 3.0, 'legendary', '{"leaderboard_rank":10}'),
  ('influencer', 'Influencer', 'Referred 100+ users', '🌟', 'achievement', 1.75, 'epic', '{"referrals":100}'),
  ('mega_influencer', 'Mega Influencer', 'Referred 1000+ users', '🌟', 'achievement', 2.5, 'legendary', '{"referrals":1000}'),
  ('box_master', 'Box Master', 'Opened 1000 boxes', '📦', 'achievement', 1.3, 'rare', '{"boxes_opened":1000}'),
  ('lightning', 'Lightning Fast', 'Opened 10 boxes in 1 hour', '⚡', 'achievement', 1.2, 'rare', '{"boxes_per_hour":10}'),
  ('anti_bot_guardian', 'Anti-Bot Guardian', 'Reported 10 bots', '🛡️', 'achievement', 1.5, 'epic', '{"bots_reported":10}')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  icon_emoji = EXCLUDED.icon_emoji,
  multiplier = EXCLUDED.multiplier,
  requirements = EXCLUDED.requirements,
  max_supply = EXCLUDED.max_supply;

-- Wallet Badges
INSERT INTO badges (id, name, description, icon_emoji, badge_category, multiplier, rarity, requirements) VALUES
  ('wallet_connected', 'Wallet Connected', 'Connected TON wallet', '👛', 'wallet', 1.1, 'common', '{"wallet_connected":true}'),
  ('whale', 'Whale', 'Hold 10+ TON in wallet', '🐋', 'wallet', 2.0, 'legendary', '{"ton_balance":10}'),
  ('mega_whale', 'Mega Whale', 'Hold 100+ TON in wallet', '🐳', 'wallet', 3.0, 'mythic', '{"ton_balance":100}'),
  ('nft_holder', 'NFT Collector', 'Own any TON NFT', '💎', 'wallet', 1.5, 'epic', '{"has_nfts":true}')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  icon_emoji = EXCLUDED.icon_emoji,
  multiplier = EXCLUDED.multiplier,
  requirements = EXCLUDED.requirements;

-- Special Badges
INSERT INTO badges (id, name, description, icon_emoji, badge_category, multiplier, rarity, requirements, available_until) VALUES
  ('holiday_special', 'Holiday Special', 'Earned during holiday season', '🎄', 'special', 2.0, 'epic', '{"seasonal":true}', '2026-12-31T23:59:59Z')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  icon_emoji = EXCLUDED.icon_emoji,
  multiplier = EXCLUDED.multiplier,
  requirements = EXCLUDED.requirements,
  available_until = EXCLUDED.available_until;

-- Seed default tasks
INSERT INTO tasks (id, title, description, points, task_type, is_repeatable, repeat_cooldown_hours) VALUES
  ('daily_login', 'Daily Check-in', 'Open the app and claim your daily bonus', 100, 'daily_login', true, 24),
  ('join_telegram', 'Join Telegram Channel', 'Join our official Telegram channel', 500, 'telegram_join', false),
  ('follow_twitter', 'Follow on Twitter', 'Follow our Twitter account', 300, 'twitter_follow', false),
  ('subscribe_youtube', 'Subscribe to YouTube', 'Subscribe to our YouTube channel', 300, 'youtube_subscribe', false),
  ('join_discord', 'Join Discord Server', 'Join our Discord community', 300, 'discord_join', false)
ON CONFLICT (id) DO UPDATE SET
  title = EXCLUDED.title,
  description = EXCLUDED.description,
  points = EXCLUDED.points;

-- Seed admin configurations
INSERT INTO admin_config (id, config_key, config_value, description) VALUES
  ('game_economy', 'box_generation_enabled', '{"enabled":true}', 'Enable/disable hourly box generation'),
  ('game_economy', 'streak_decay_hours', '{"hours":25}', 'Hours before streak resets (must be > 24)'),
  ('game_economy', 'box_point_multiplier', '{"global_multiplier":1.0}', 'Global multiplier for all box points'),
  ('game_economy', 'max_boxes_per_day', '{"max":24}', 'Maximum boxes a user can have'),
  ('game_economy', 'box_expiry_hours', '{"hours":3}', 'Hours before unopened boxes expire'),
  ('anti_fraud', 'max_accounts_per_fingerprint', '{"max":3}', 'Max accounts per device fingerprint'),
  ('anti_fraud', 'ban_suspicious_threshold', '{"reports":5}', 'Reports needed to auto-ban'),
  ('referrals', 'referral_bonus_points', '{"referrer":1000,"referred":500}', 'Points awarded for successful referral')
ON CONFLICT (id) DO UPDATE SET
  config_value = EXCLUDED.config_value,
  updated_at = NOW();
