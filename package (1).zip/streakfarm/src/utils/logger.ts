import winston from 'winston';
import path from 'path';

const LOG_DIR = process.env.LOG_DIR || 'logs';
const LOG_LEVEL = process.env.LOG_LEVEL || 'info';

const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    const metaStr = Object.keys(meta).length ? JSON.stringify(meta, null, 2) : '';
    return `${timestamp} [${level.toUpperCase()}] ${message} ${metaStr}`;
  })
);

const consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({ format: 'HH:mm:ss' }),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    const metaStr = Object.keys(meta).length ? JSON.stringify(meta) : '';
    return `${timestamp} ${level} ${message} ${metaStr}`;
  })
);

export const logger = winston.createLogger({
  level: LOG_LEVEL,
  format: logFormat,
  defaultMeta: { service: 'streakfarm' },
  transports: [
    new winston.transports.File({
      filename: path.join(LOG_DIR, 'error.log'),
      level: 'error',
      maxsize: 10 * 1024 * 1024,
      maxFiles: 10,
      tailable: true
    }),
    new winston.transports.File({
      filename: path.join(LOG_DIR, 'combined.log'),
      maxsize: 10 * 1024 * 1024,
      maxFiles: 10,
      tailable: true
    }),
    new winston.transports.File({
      filename: path.join(LOG_DIR, 'events.log'),
      level: 'http',
      maxsize: 50 * 1024 * 1024,
      maxFiles: 20,
      tailable: true
    })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: consoleFormat
  }));
}

export async function logEvent(eventType: string, metadata?: Record<string, any>): Promise<void> {
  try {
    logger.http(eventType, {
      eventType,
      ...metadata,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to log event:', error);
  }
}

export function logError(error: Error, context?: Record<string, any>): void {
  logger.error(error.message, {
    error: error.stack,
    ...context
  });
}

export function logInfo(message: string, metadata?: Record<string, any>): void {
  logger.info(message, metadata);
}

export function logWarn(message: string, metadata?: Record<string, any>): void {
  logger.warn(message, metadata);
}

export function logDebug(message: string, metadata?: Record<string, any>): void {
  logger.debug(message, metadata);
}
