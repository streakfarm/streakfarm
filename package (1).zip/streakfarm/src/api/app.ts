import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { logEvent, logError } from '../utils/logger';
import { userRouter } from './routes/user';
import { boxRouter } from './routes/box';
import { badgeRouter } from './routes/badge';
import { walletRouter } from './routes/wallet';
import { leaderboardRouter } from './routes/leaderboard';
import { taskRouter } from './routes/task';
import { referralRouter } from './routes/referral';
import { pointsRouter } from './routes/points';
import { adminRouter } from './routes/admin';
import { healthRouter } from './routes/health';
import Sentry from '@sentry/node';

export function createApp(): Express {
  const app = express();

  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
  }));

  app.use(cors({
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-User-ID'],
    credentials: true
  }));

  app.use(compression());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true }));

  app.use(Sentry.Handlers.requestHandler());

  app.use((req: Request, _res: Response, next: NextFunction) => {
    logEvent('http_request', {
      method: req.method,
      path: req.path,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });
    next();
  });

  app.use('/api/health', healthRouter);
  app.use('/api/users', userRouter);
  app.use('/api/boxes', boxRouter);
  app.use('/api/badges', badgeRouter);
  app.use('/api/wallet', walletRouter);
  app.use('/api/leaderboard', leaderboardRouter);
  app.use('/api/tasks', taskRouter);
  app.use('/api/referrals', referralRouter);
  app.use('/api/points', pointsRouter);
  app.use('/api/admin', adminRouter);

  app.get('/api', (_req: Request, res: Response) => {
    res.json({
      name: 'StreakFarm API',
      version: '1.0.0',
      status: 'running',
      endpoints: [
        'GET  /api/health',
        'GET  /api/users/:id',
        'POST /api/users/upsert',
        'GET  /api/boxes',
        'POST /api/boxes/:id/open',
        'GET  /api/badges',
        'GET  /api/badges/owned',
        'POST /api/wallet/connect',
        'POST /api/wallet/disconnect',
        'GET  /api/leaderboard',
        'GET  /api/tasks',
        'POST /api/tasks/:id/complete',
        'GET  /api/referrals',
        'POST /api/referrals/claim',
        'GET  /api/points/history',
        'POST /api/admin/*'
      ]
    });
  });

  app.use(Sentry.Handlers.errorHandler());

  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    logError(err, { stack: err.stack });
    res.status(500).json({
      error: 'Internal server error',
      message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  });

  app.use((_req: Request, res: Response) => {
    res.status(404).json({ error: 'Not found' });
  });

  return app;
}
