import { Router, Request, Response } from 'express';
import { userService } from '../services/userService';
import { pointsService } from '../services/pointsService';
import { antiFraudService } from '../services/antiFraudService';
import { logEvent } from '../utils/logger';
import { z } from 'zod';

const router = Router();

const upsertUserSchema = z.object({
  telegramId: z.number(),
  username: z.string().optional(),
  firstName: z.string().optional(),
  languageCode: z.string().optional(),
  startParam: z.string().optional(),
  fingerprint: z.string().optional()
});

router.get('/:id', async (req: Request, res: Response) => {
  try {
    const user = await userService.getUser(req.params.id);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const stats = await userService.getUserStats(req.params.id);

    res.json({
      user: {
        id: user.id,
        telegramId: user.telegram_id,
        username: user.username,
        firstName: user.first_name,
        languageCode: user.language_code,
        rawPoints: user.raw_points,
        streakCurrent: user.streak_current,
        streakBest: user.streak_best,
        totalBoxesOpened: user.total_boxes_opened,
        totalTasksCompleted: user.total_tasks_completed,
        totalReferrals: user.total_referrals,
        multiplier: user.multiplier_permanent,
        refCode: user.ref_code,
        walletConnected: !!user.wallet_address,
        createdAt: user.created_at
      },
      stats
    });
  } catch (error) {
    logEvent('user_get_error', { error, userId: req.params.id });
    res.status(500).json({ error: 'Failed to get user' });
  }
});

router.post('/upsert', async (req: Request, res: Response) => {
  try {
    const validated = upsertUserSchema.parse(req.body);

    const fingerprint = validated.fingerprint || await antiFraudService.generateFingerprint(
      req.get('user-agent') || '',
      req.ip || ''
    );

    const duplicationCheck = await antiFraudService.checkFingerprintDuplication(fingerprint);

    if (duplicationCheck.action === 'block') {
      return res.status(403).json({ error: 'Too many accounts from this device' });
    }

    const user = await userService.getOrCreateUser({
      telegramId: validated.telegramId,
      username: validated.username,
      firstName: validated.firstName,
      languageCode: validated.languageCode,
      fingerprint,
      ipAddress: req.ip,
      userAgent: req.get('user-agent'),
      referredBy: validated.startParam
    });

    if (duplicationCheck.action === 'flag') {
      await antiFraudService.flagUser(user.id, {
        type: 'multiple_accounts',
        severity: 'medium',
        description: `User has ${duplicationCheck.existingAccounts} accounts`,
        metadata: { fingerprint, existingAccounts: duplicationCheck.existingAccounts }
      });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        telegramId: user.telegram_id,
        username: user.username,
        firstName: user.first_name,
        rawPoints: user.raw_points,
        streakCurrent: user.streak_current,
        multiplier: user.multiplier_permanent,
        refCode: user.ref_code,
        walletConnected: !!user.wallet_address
      }
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid request', details: error.errors });
    }
    logEvent('user_upsert_error', { error });
    res.status(500).json({ error: 'Failed to create/update user' });
  }
});

router.post('/:id/checkin', async (req: Request, res: Response) => {
  try {
    const result = await userService.checkAndUpdateStreak(req.params.id);

    if (result.bonusPoints > 0) {
      await pointsService.awardPoints(req.params.id, result.bonusPoints, {
        source: 'daily_checkin',
        metadata: { streak: result.newStreak }
      });
    }

    res.json({
      success: true,
      streakContinued: result.streakContinued,
      streakReset: result.streakReset,
      newStreak: result.newStreak,
      bonusPoints: result.bonusPoints
    });
  } catch (error) {
    logEvent('checkin_error', { error, userId: req.params.id });
    res.status(500).json({ error: 'Failed to process check-in' });
  }
});

router.get('/:id/stats', async (req: Request, res: Response) => {
  try {
    const stats = await userService.getUserStats(req.params.id);
    res.json(stats);
  } catch (error) {
    logEvent('user_stats_error', { error, userId: req.params.id });
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

router.get('/:id/flags', async (req: Request, res: Response) => {
  try {
    const flags = await antiFraudService.getUserFlags(req.params.id);
    res.json({ flags });
  } catch (error) {
    logEvent('user_flags_error', { error, userId: req.params.id });
    res.status(500).json({ error: 'Failed to get flags' });
  }
});

router.get('/:id/referrals', async (req: Request, res: Response) => {
  try {
    const referrals = await import('../services/referralService').then(s => s.referralService.getUserReferrals(req.params.id));
    res.json({ referrals });
  } catch (error) {
    logEvent('user_referrals_error', { error, userId: req.params.id });
    res.status(500).json({ error: 'Failed to get referrals' });
  }
});

export const userRouter = router;
