import { Router, Request, Response } from 'express';
import { referralService } from '../services/referralService';
import { logEvent } from '../utils/logger';

const router = Router();

router.get('/link/:userId', async (req: Request, res: Response) => {
  try {
    const link = await referralService.createReferralLink(req.params.userId);
    const code = await referralService.getReferralCode(req.params.userId);

    res.json({ link, code });
  } catch (error) {
    logEvent('referral_link_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get referral link' });
  }
});

router.get('/stats/:userId', async (req: Request, res: Response) => {
  try {
    const stats = await referralService.getReferralStats(req.params.userId);
    res.json(stats);
  } catch (error) {
    logEvent('referral_stats_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get referral stats' });
  }
});

router.get('/:userId', async (req: Request, res: Response) => {
  try {
    const referrals = await referralService.getUserReferrals(req.params.userId);
    res.json({ referrals });
  } catch (error) {
    logEvent('user_referrals_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get referrals' });
  }
});

router.post('/validate', async (req: Request, res: Response) => {
  try {
    const { code, userId } = req.body;

    if (!code || !userId) {
      return res.status(400).json({ error: 'Code and user ID required' });
    }

    const result = await referralService.validateReferralCode(code, userId);

    if (!result.valid) {
      return res.status(400).json({ error: result.error });
    }

    res.json({ valid: true, referrerId: result.referrerId });
  } catch (error) {
    logEvent('referral_validate_error', { error });
    res.status(500).json({ error: 'Failed to validate referral code' });
  }
});

router.post('/claim', async (req: Request, res: Response) => {
  try {
    const { referrerId, referredTelegramId } = req.body;

    if (!referrerId || !referredTelegramId) {
      return res.status(400).json({ error: 'Referrer ID and referred Telegram ID required' });
    }

    const result = await referralService.processReferral(referrerId, referredTelegramId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      bonusAwarded: result.bonusAwarded,
      referrerBonus: result.referrerBonus,
      referredBonus: result.referredBonus
    });
  } catch (error) {
    logEvent('referral_claim_error', { error });
    res.status(500).json({ error: 'Failed to claim referral' });
  }
});

router.get('/code/:code', async (req: Request, res: Response) => {
  try {
    const referrerId = await referralService.getReferrerByCode(req.params.code);

    if (!referrerId) {
      return res.status(404).json({ error: 'Referral code not found' });
    }

    res.json({ referrerId });
  } catch (error) {
    logEvent('referral_code_error', { error });
    res.status(500).json({ error: 'Failed to get referrer' });
  }
});

export const referralRouter = router;
