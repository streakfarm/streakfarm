import { Router, Request, Response } from 'express';
import { walletService } from '../services/walletService';
import { logEvent } from '../utils/logger';
import { z } from 'zod';

const router = Router();

const connectWalletSchema = z.object({
  walletAddress: z.string(),
  walletType: z.string()
});

router.post('/connect', async (req: Request, res: Response) => {
  try {
    const userId = req.get('X-User-ID');

    if (!userId) {
      return res.status(401).json({ error: 'User ID required' });
    }

    const validated = connectWalletSchema.parse(req.body);
    const result = await walletService.connectUserWallet(userId, validated.walletAddress, validated.walletType);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      walletAddress: result.walletAddress,
      bonus: result.bonus,
      newBadges: result.newBadges
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid request', details: error.errors });
    }
    logEvent('wallet_connect_error', { error });
    res.status(500).json({ error: 'Failed to connect wallet' });
  }
});

router.post('/disconnect', async (req: Request, res: Response) => {
  try {
    const userId = req.get('X-User-ID');

    if (!userId) {
      return res.status(401).json({ error: 'User ID required' });
    }

    const result = await walletService.disconnectWallet(userId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({ success: true });
  } catch (error) {
    logEvent('wallet_disconnect_error', { error });
    res.status(500).json({ error: 'Failed to disconnect wallet' });
  }
});

router.get('/info/:userId', async (req: Request, res: Response) => {
  try {
    const info = await walletService.getUserWalletInfo(req.params.userId);
    res.json(info);
  } catch (error) {
    logEvent('wallet_info_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get wallet info' });
  }
});

router.get('/exclusive-tasks/:userId', async (req: Request, res: Response) => {
  try {
    const tasks = await walletService.getWalletExclusiveTasks(req.params.userId);
    res.json({ tasks });
  } catch (error) {
    logEvent('wallet_tasks_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get wallet tasks' });
  }
});

router.get('/verify/:userId', async (req: Request, res: Response) => {
  try {
    const user = await import('../services/userService').then(s => s.userService.getUser(req.params.userId));

    if (!user || !user.wallet_address) {
      return res.status(400).json({ verified: false, error: 'No wallet connected' });
    }

    const { data: pendingVerification } = await import('../db/client')
      .then(c => c.getSupabaseClient())
      .from('wallet_verifications')
      .select('*')
      .eq('user_id', req.params.userId)
      .eq('verified', false)
      .single();

    if (pendingVerification) {
      return res.json({
        verified: false,
        pending: true,
        challenge: pendingVerification.challenge
      });
    }

    const challenge = `Verify ownership of ${user.wallet_address} at ${Date.now()}`;

    await import('../db/client')
      .then(c => c.getSupabaseClient())
      .from('wallet_verifications')
      .insert({
        user_id: req.params.userId,
        wallet_address: user.wallet_address,
        challenge,
        expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString()
      });

    res.json({
      verified: false,
      pending: true,
      challenge
    });
  } catch (error) {
    logEvent('wallet_verify_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to initiate verification' });
  }
});

export const walletRouter = router;
