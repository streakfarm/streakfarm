import { Router, Request, Response } from 'express';
import { pointsService } from '../services/pointsService';
import { logEvent } from '../utils/logger';

const router = Router();

router.get('/balance/:userId', async (req: Request, res: Response) => {
  try {
    const user = await import('../services/userService').then(s => s.userService.getUser(req.params.userId));

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const rank = await pointsService.getLeaderboardPosition(req.params.userId);

    res.json({
      balance: user.raw_points,
      rank
    });
  } catch (error) {
    logEvent('points_balance_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get balance' });
  }
});

router.get('/history/:userId', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;

    const history = await pointsService.getPointsHistory(req.params.userId, limit, offset);
    res.json({ history });
  } catch (error) {
    logEvent('points_history_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get points history' });
  }
});

router.get('/stats/:userId', async (req: Request, res: Response) => {
  try {
    const stats = await pointsService.getPointsStats(req.params.userId);
    res.json(stats);
  } catch (error) {
    logEvent('points_stats_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get points stats' });
  }
});

router.get('/around/:userId', async (req: Request, res: Response) => {
  try {
    const range = parseInt(req.query.range as string) || 5;
    const nearby = await pointsService.getPointsAroundUser(req.params.userId, range);
    res.json({ nearby });
  } catch (error) {
    logEvent('points_around_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get nearby users' });
  }
});

export const pointsRouter = router;
