import { Router, Request, Response } from 'express';
import { badgeService } from '../services/badgeService';
import { logEvent } from '../utils/logger';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  try {
    const badges = await badgeService.getAllBadges();
    res.json({ badges });
  } catch (error) {
    logEvent('badges_get_error', { error });
    res.status(500).json({ error: 'Failed to get badges' });
  }
});

router.get('/owned/:userId', async (req: Request, res: Response) => {
  try {
    const badges = await badgeService.getUserBadges(req.params.userId);
    const totalMultiplier = badges.reduce((sum, ub) => sum + (ub.badges.multiplier - 1), 1);

    res.json({
      badges,
      totalMultiplier: Math.round(totalMultiplier * 100) / 100
    });
  } catch (error) {
    logEvent('user_badges_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get user badges' });
  }
});

router.get('/available/:userId', async (req: Request, res: Response) => {
  try {
    const badges = await badgeService.getAvailableBadges(req.params.userId);
    res.json({ badges });
  } catch (error) {
    logEvent('available_badges_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get available badges' });
  }
});

router.get('/progress/:userId', async (req: Request, res: Response) => {
  try {
    const owned = await badgeService.getUserBadges(req.params.userId);
    const available = await badgeService.getAvailableBadges(req.params.userId);

    res.json({
      owned: owned.length,
      available: available.length,
      total: owned.length + available.length,
      progress: available.map(b => ({
        id: b.id,
        name: b.name,
        icon: b.icon_emoji,
        multiplier: b.multiplier,
        progress: b.progress
      }))
    });
  } catch (error) {
    logEvent('badge_progress_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get badge progress' });
  }
});

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const stats = await badgeService.getBadgeStats();
    res.json(stats);
  } catch (error) {
    logEvent('badge_stats_error', { error });
    res.status(500).json({ error: 'Failed to get badge stats' });
  }
});

router.get('/:id', async (req: Request, res: Response) => {
  try {
    const badge = await badgeService.getBadgeById(req.params.id);

    if (!badge) {
      return res.status(404).json({ error: 'Badge not found' });
    }

    res.json({ badge });
  } catch (error) {
    logEvent('badge_get_error', { error, badgeId: req.params.id });
    res.status(500).json({ error: 'Failed to get badge' });
  }
});

router.post('/check/:userId', async (req: Request, res: Response) => {
  try {
    const newBadges = await badgeService.checkAndAwardBadges(req.params.userId);

    res.json({
      checked: true,
      newBadges: newBadges.map(b => ({
        id: b.id,
        name: b.name,
        icon: b.icon_emoji,
        multiplier: b.multiplier
      }))
    });
  } catch (error) {
    logEvent('badge_check_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to check badges' });
  }
});

export const badgeRouter = router;
