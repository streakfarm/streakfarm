import { Router, Request, Response } from 'express';
import { taskService } from '../services/taskService';
import { logEvent } from '../utils/logger';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  try {
    const userId = req.get('X-User-ID') || req.query.userId as string;

    if (!userId) {
      return res.status(401).json({ error: 'User ID required' });
    }

    const tasks = await taskService.getAvailableTasks(userId);
    res.json({ tasks });
  } catch (error) {
    logEvent('tasks_get_error', { error });
    res.status(500).json({ error: 'Failed to get tasks' });
  }
});

router.get('/:id', async (req: Request, res: Response) => {
  try {
    const task = await taskService.getTaskById(req.params.id);

    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    res.json({ task });
  } catch (error) {
    logEvent('task_get_error', { error, taskId: req.params.id });
    res.status(500).json({ error: 'Failed to get task' });
  }
});

router.post('/:id/complete', async (req: Request, res: Response) => {
  try {
    const userId = req.get('X-User-ID');

    if (!userId) {
      return res.status(401).json({ error: 'User ID required' });
    }

    const result = await taskService.completeTask(userId, req.params.id, req.body.verificationData);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      pointsAwarded: result.pointsAwarded,
      newBadges: result.newBadges
    });
  } catch (error) {
    logEvent('task_complete_error', { error, taskId: req.params.id });
    res.status(500).json({ error: 'Failed to complete task' });
  }
});

router.post('/:id/verify', async (req: Request, res: Response) => {
  try {
    const userId = req.get('X-User-ID');

    if (!userId) {
      return res.status(401).json({ error: 'User ID required' });
    }

    const result = await taskService.verifyExternalTask(userId, req.params.id, req.body);

    if (!result.verified) {
      return res.status(400).json({ error: result.error });
    }

    res.json({ verified: true });
  } catch (error) {
    logEvent('task_verify_error', { error, taskId: req.params.id });
    res.status(500).json({ error: 'Failed to verify task' });
  }
});

router.get('/user/:userId/history', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const history = await taskService.getUserTaskHistory(req.params.userId, limit);
    res.json({ history });
  } catch (error) {
    logEvent('task_history_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get task history' });
  }
});

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const stats = await taskService.getTaskStats();
    res.json(stats);
  } catch (error) {
    logEvent('task_stats_error', { error });
    res.status(500).json({ error: 'Failed to get task stats' });
  }
});

export const taskRouter = router;
