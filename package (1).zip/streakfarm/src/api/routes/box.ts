import { Router, Request, Response } from 'express';
import { boxService } from '../services/boxService';
import { badgeService } from '../services/badgeService';
import { logEvent } from '../utils/logger';
import { z } from 'zod';

const router = Router();

router.get('/:userId', async (req: Request, res: Response) => {
  try {
    const boxes = await boxService.getUserAvailableBoxes(req.params.userId);
    const stats = await boxService.getUserBoxStats(req.params.userId);

    res.json({
      boxes,
      stats
    });
  } catch (error) {
    logEvent('boxes_get_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get boxes' });
  }
});

router.post('/:userId/open/:boxId', async (req: Request, res: Response) => {
  try {
    const result = await boxService.openBox(req.params.userId, req.params.boxId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      finalPoints: result.finalPoints,
      rarity: result.rarity,
      multiplier: result.multiplier,
      basePoints: result.basePoints,
      newBadges: result.newBadges
    });
  } catch (error) {
    logEvent('box_open_error', { error, userId: req.params.userId, boxId: req.params.boxId });
    res.status(500).json({ error: 'Failed to open box' });
  }
});

router.get('/:userId/history', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 20;
    const history = await boxService.getUserBoxHistory(req.params.userId, limit);

    res.json({ history });
  } catch (error) {
    logEvent('box_history_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get box history' });
  }
});

router.get('/:userId/stats', async (req: Request, res: Response) => {
  try {
    const stats = await boxService.getUserBoxStats(req.params.userId);
    res.json(stats);
  } catch (error) {
    logEvent('box_stats_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get box stats' });
  }
});

export const boxRouter = router;
