import { Router, Request, Response } from 'express';
import { leaderboardService } from '../services/leaderboardService';
import { logEvent } from '../utils/logger';

const router = Router();

const VALID_PERIODS = ['daily', 'weekly', 'monthly', 'all_time'] as const;
type Period = typeof VALID_PERIODS[number];

router.get('/', async (req: Request, res: Response) => {
  try {
    const period = (req.query.period as Period) || 'all_time';

    if (!VALID_PERIODS.includes(period)) {
      return res.status(400).json({ error: 'Invalid period' });
    }

    const limit = Math.min(parseInt(req.query.limit as string) || 100, 1000);
    const offset = parseInt(req.query.offset as string) || 0;

    const entries = await leaderboardService.getLeaderboard(period, limit, offset);
    const stats = await leaderboardService.getLeaderboardStats(period);

    res.json({
      period,
      entries,
      stats
    });
  } catch (error) {
    logEvent('leaderboard_get_error', { error });
    res.status(500).json({ error: 'Failed to get leaderboard' });
  }
});

router.get('/user/:userId', async (req: Request, res: Response) => {
  try {
    const period = (req.query.period as Period) || 'all_time';

    if (!VALID_PERIODS.includes(period)) {
      return res.status(400).json({ error: 'Invalid period' });
    }

    const rank = await leaderboardService.getUserLeaderboardRank(req.params.userId, period);

    if (rank === null) {
      return res.status(404).json({ error: 'User not found' });
    }

    const aroundUser = await leaderboardService.getLeaderboardAroundUser(req.params.userId, period, 5);

    res.json({
      userRank: rank,
      userEntry: aroundUser.userEntry,
      nearbyEntries: aroundUser.nearbyEntries
    });
  } catch (error) {
    logEvent('user_leaderboard_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get user leaderboard position' });
  }
});

router.get('/around/:userId', async (req: Request, res: Response) => {
  try {
    const period = (req.query.period as Period) || 'all_time';
    const range = parseInt(req.query.range as string) || 5;

    if (!VALID_PERIODS.includes(period)) {
      return res.status(400).json({ error: 'Invalid period' });
    }

    const result = await leaderboardService.getLeaderboardAroundUser(req.params.userId, period, range);

    res.json(result);
  } catch (error) {
    logEvent('leaderboard_around_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to get leaderboard around user' });
  }
});

router.get('/stats/:period', async (req: Request, res: Response) => {
  try {
    const period = (req.params.period as Period) || 'all_time';

    if (!VALID_PERIODS.includes(period)) {
      return res.status(400).json({ error: 'Invalid period' });
    }

    const stats = await leaderboardService.getLeaderboardStats(period);
    res.json(stats);
  } catch (error) {
    logEvent('leaderboard_stats_error', { error });
    res.status(500).json({ error: 'Failed to get leaderboard stats' });
  }
});

router.get('/top-referrers', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 10;
    const topReferrers = await import('../services/userService').then(s => s.userService.getTopReferrers(limit));
    res.json({ topReferrers });
  } catch (error) {
    logEvent('top_referrers_error', { error });
    res.status(500).json({ error: 'Failed to get top referrers' });
  }
});

export const leaderboardRouter = router;
