import { Router, Request, Response } from 'express';
import { getSupabaseClient } from '../db/client';
import { redisCache } from '../cache/redis';
import { logEvent } from '../utils/logger';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    service: 'streakfarm-api'
  });
});

router.get('/ready', async (req: Request, res: Response) => {
  const checks = {
    database: false,
    cache: false
  };

  try {
    const { error } = await getSupabaseClient()
      .from('users')
      .select('id')
      .limit(1);

    checks.database = !error;
  } catch {
    checks.database = false;
  }

  try {
    await redisCache.get('health_check');
    checks.cache = true;
  } catch {
    checks.cache = false;
  }

  const allHealthy = Object.values(checks).every(v => v);

  res.status(allHealthy ? 200 : 503).json({
    ready: allHealthy,
    checks
  });
});

router.get('/live', async (_req: Request, res: Response) => {
  res.json({ alive: true });
});

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const { data: userCount } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', false);

    const { data: activeToday } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', false)
      .gte('last_active_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

    const { data: boxCount } = await getSupabaseClient()
      .from('boxes')
      .select('id', { count: 'exact' })
      .is('opened_at', null)
      .eq('is_expired', false);

    res.json({
      users: {
        total: userCount?.count || 0,
        activeToday: activeToday?.count || 0
      },
      boxes: {
        pending: boxCount?.count || 0
      },
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logEvent('stats_error', { error });
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

export const healthRouter = router;
