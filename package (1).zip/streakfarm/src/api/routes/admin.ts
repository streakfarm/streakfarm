import { Router, Request, Response } from 'express';
import { adminConfigService } from '../services/adminService';
import { antiFraudService } from '../services/antiFraudService';
import { boxService } from '../services/boxService';
import { logEvent } from '../utils/logger';
import { z } from 'zod';

const router = Router();

const authenticateAdmin = async (req: Request, res: Response, next: Function) => {
  const adminKey = req.get('X-Admin-Key');

  if (!adminKey || adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  next();
};

router.use(authenticateAdmin);

router.get('/config', async (req: Request, res: Response) => {
  try {
    const configs = await adminConfigService.getAllConfigs();
    res.json({ configs });
  } catch (error) {
    logEvent('admin_config_error', { error });
    res.status(500).json({ error: 'Failed to get configs' });
  }
});

router.get('/game-economy', async (req: Request, res: Response) => {
  try {
    const config = await adminConfigService.getGameEconomyConfig();
    res.json(config);
  } catch (error) {
    logEvent('game_economy_error', { error });
    res.status(500).json({ error: 'Failed to get game economy config' });
  }
});

router.patch('/game-economy', async (req: Request, res: Response) => {
  try {
    const updateSchema = z.object({
      boxGenerationEnabled: z.boolean().optional(),
      streakDecayHours: z.number().optional(),
      boxPointMultiplier: z.number().optional(),
      maxBoxesPerDay: z.number().optional(),
      boxExpiryHours: z.number().optional()
    });

    const updates = updateSchema.parse(req.body);
    await adminConfigService.updateGameEconomyConfig(updates, req.get('X-Admin-ID'));

    res.json({ success: true });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid request', details: error.errors });
    }
    logEvent('update_game_economy_error', { error });
    res.status(500).json({ error: 'Failed to update game economy' });
  }
});

router.get('/fraud-stats', async (req: Request, res: Response) => {
  try {
    const stats = await antiFraudService.getFraudStats();
    res.json(stats);
  } catch (error) {
    logEvent('fraud_stats_error', { error });
    res.status(500).json({ error: 'Failed to get fraud stats' });
  }
});

router.post('/ban/:userId', async (req: Request, res: Response) => {
  try {
    const { reason } = req.body;

    if (!reason) {
      return res.status(400).json({ error: 'Reason required' });
    }

    await antiFraudService.banUser(req.params.userId, reason, false);

    res.json({ success: true });
  } catch (error) {
    logEvent('ban_user_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to ban user' });
  }
});

router.post('/unban/:userId', async (req: Request, res: Response) => {
  try {
    await import('../services/userService').then(s => s.userService.unbanUser(req.params.userId));
    res.json({ success: true });
  } catch (error) {
    logEvent('unban_user_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to unban user' });
  }
});

router.post('/flag/:userId', async (req: Request, res: Response) => {
  try {
    const { type, severity, description } = req.body;

    await antiFraudService.flagUser(req.params.userId, { type, severity, description });

    res.json({ success: true });
  } catch (error) {
    logEvent('flag_user_error', { error, userId: req.params.userId });
    res.status(500).json({ error: 'Failed to flag user' });
  }
});

router.post('/flag/:flagId/resolve', async (req: Request, res: Response) => {
  try {
    const { resolution } = req.body;
    const resolvedBy = req.get('X-Admin-ID') || 'unknown';

    await antiFraudService.resolveFlag(req.params.flagId, resolvedBy, resolution);

    res.json({ success: true });
  } catch (error) {
    logEvent('resolve_flag_error', { error, flagId: req.params.flagId });
    res.status(500).json({ error: 'Failed to resolve flag' });
  }
});

router.post('/generate-boxes', async (req: Request, res: Response) => {
  try {
    const { batchSize } = req.body;
    const result = await boxService.generateBoxes(batchSize || 100000);
    res.json(result);
  } catch (error) {
    logEvent('generate_boxes_error', { error });
    res.status(500).json({ error: 'Failed to generate boxes' });
  }
});

router.post('/expire-boxes', async (req: Request, res: Response) => {
  try {
    const result = await boxService.expireOldBoxes();
    res.json(result);
  } catch (error) {
    logEvent('expire_boxes_error', { error });
    res.status(500).json({ error: 'Failed to expire boxes' });
  }
});

router.post('/award-badge', async (req: Request, res: Response) => {
  try {
    const { userId, badgeId } = req.body;

    if (!userId || !badgeId) {
      return res.status(400).json({ error: 'User ID and badge ID required' });
    }

    await import('../services/badgeService').then(s => s.badgeService.awardBadge(userId, badgeId));

    res.json({ success: true });
  } catch (error) {
    logEvent('award_badge_error', { error });
    res.status(500).json({ error: 'Failed to award badge' });
  }
});

router.get('/badge-stats', async (req: Request, res: Response) => {
  try {
    const stats = await import('../services/badgeService').then(s => s.badgeService.getBadgeStats());
    res.json(stats);
  } catch (error) {
    logEvent('badge_stats_error', { error });
    res.status(500).json({ error: 'Failed to get badge stats' });
  }
});

router.post('/notify-bulk', async (req: Request, res: Response) => {
  try {
    const { telegramIds, title, body, inlineKeyboards } = req.body;

    if (!telegramIds || !title || !body) {
      return res.status(400).json({ error: 'Telegram IDs, title, and body required' });
    }

    await import('../services/notificationService').then(s => s.notificationService.sendBulkNotification(telegramIds, {
      title,
      body,
      inlineKeyboards
    }));

    res.json({ success: true });
  } catch (error) {
    logEvent('bulk_notify_error', { error });
    res.status(500).json({ error: 'Failed to send bulk notification' });
  }
});

export const adminRouter = router;
