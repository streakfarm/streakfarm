import { getSupabaseAdmin } from '../db/client';
import { logEvent } from '../utils/logger';

interface ConfigValue {
  [key: string]: any;
}

class AdminConfigService {
  async getConfig(key: string): Promise<ConfigValue | null> {
    const { data, error } = await getSupabaseAdmin()
      .from('admin_config')
      .select('config_value')
      .eq('config_key', key)
      .eq('is_active', true)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw error;
    }

    return data.config_value;
  }

  async getConfigValue<T>(key: string, defaultValue: T): Promise<T> {
    const config = await this.getConfig(key);
    return config !== null ? (config as T) : defaultValue;
  }

  async setConfig(key: string, value: ConfigValue, description?: string, updatedBy?: string): Promise<void> {
    const { error } = await getSupabaseAdmin()
      .from('admin_config')
      .upsert({
        id: key,
        config_key: key,
        config_value: value,
        description,
        is_active: true,
        updated_at: new Date().toISOString(),
        updated_by: updatedBy
      });

    if (error) throw error;

    await logEvent('config_updated', { key, value, updatedBy });
  }

  async deactivateConfig(key: string): Promise<void> {
    const { error } = await getSupabaseAdmin()
      .from('admin_config')
      .update({ is_active: false })
      .eq('config_key', key);

    if (error) throw error;

    await logEvent('config_deactivated', { key });
  }

  async getAllConfigs(): Promise<Array<{
    key: string;
    value: ConfigValue;
    description?: string;
    isActive: boolean;
    updatedAt: string;
    updatedBy?: string;
  }>> {
    const { data, error } = await getSupabaseAdmin()
      .from('admin_config')
      .select('*')
      .order('updated_at', { ascending: false });

    if (error) throw error;

    return data?.map(c => ({
      key: c.config_key,
      value: c.config_value,
      description: c.description,
      isActive: c.is_active,
      updatedAt: c.updated_at,
      updatedBy: c.updated_by
    })) || [];
  }

  async getGameEconomyConfig(): Promise<{
    boxGenerationEnabled: boolean;
    streakDecayHours: number;
    boxPointMultiplier: number;
    maxBoxesPerDay: number;
    boxExpiryHours: number;
  }> {
    const [boxGeneration, streakDecay, pointMultiplier, maxBoxes, boxExpiry] = await Promise.all([
      this.getConfigValue('box_generation_enabled', { enabled: true }),
      this.getConfigValue('streak_decay_hours', { hours: 25 }),
      this.getConfigValue('box_point_multiplier', { global_multiplier: 1.0 }),
      this.getConfigValue('max_boxes_per_day', { max: 24 }),
      this.getConfigValue('box_expiry_hours', { hours: 3 })
    ]);

    return {
      boxGenerationEnabled: boxGeneration.enabled ?? true,
      streakDecayHours: streakDecay.hours ?? 25,
      boxPointMultiplier: pointMultiplier.global_multiplier ?? 1.0,
      maxBoxesPerDay: maxBoxes.max ?? 24,
      boxExpiryHours: boxExpiry.hours ?? 3
    };
  }

  async updateGameEconomyConfig(updates: Partial<{
    boxGenerationEnabled: boolean;
    streakDecayHours: number;
    boxPointMultiplier: number;
    maxBoxesPerDay: number;
    boxExpiryHours: number;
  }>, updatedBy?: string): Promise<void> {
    if (updates.boxGenerationEnabled !== undefined) {
      await this.setConfig('box_generation_enabled', { enabled: updates.boxGenerationEnabled }, 'Enable/disable hourly box generation', updatedBy);
    }
    if (updates.streakDecayHours !== undefined) {
      await this.setConfig('streak_decay_hours', { hours: updates.streakDecayHours }, 'Hours before streak resets', updatedBy);
    }
    if (updates.boxPointMultiplier !== undefined) {
      await this.setConfig('box_point_multiplier', { global_multiplier: updates.boxPointMultiplier }, 'Global multiplier for box points', updatedBy);
    }
    if (updates.maxBoxesPerDay !== undefined) {
      await this.setConfig('max_boxes_per_day', { max: updates.maxBoxesPerDay }, 'Maximum boxes per day', updatedBy);
    }
    if (updates.boxExpiryHours !== undefined) {
      await this.setConfig('box_expiry_hours', { hours: updates.boxExpiryHours }, 'Hours before boxes expire', updatedBy);
    }
  }

  async getAntiFraudConfig(): Promise<{
    maxAccountsPerFingerprint: number;
    banSuspiciousThreshold: number;
  }> {
    const [maxAccounts, banThreshold] = await Promise.all([
      this.getConfigValue('max_accounts_per_fingerprint', { max: 3 }),
      this.getConfigValue('ban_suspicious_threshold', { reports: 5 })
    ]);

    return {
      maxAccountsPerFingerprint: maxAccounts.max ?? 3,
      banSuspiciousThreshold: banThreshold.reports ?? 5
    };
  }

  async getReferralConfig(): Promise<{
    referralBonusPoints: { referrer: number; referred: number };
  }> {
    const config = await this.getConfigValue('referral_bonus_points', { referrer: 1000, referred: 500 });
    return {
      referralBonusPoints: {
        referrer: config.referrer ?? 1000,
        referred: config.referred ?? 500
      }
    };
  }
}

export const adminConfigService = new AdminConfigService();
export type { ConfigValue };
