import cron from 'node-cron';
import { logEvent, logError } from '../utils/logger';
import { boxService } from '../services/boxService';
import { walletService } from '../services/walletService';
import { badgeService } from '../services/badgeService';
import { leaderboardService } from '../services/leaderboardService';
import { getSupabaseClient } from '../db/client';

let isRunning = {
  boxGeneration: false,
  boxExpiration: false,
  walletChecks: false,
  badgeChecks: false,
  leaderboardUpdate: false,
  cleanup: false
};

export async function startCronJobs(): Promise<void> {
  logInfo('Initializing cron jobs');

  cron.schedule('0 * * * *', async () => {
    if (isRunning.boxGeneration) return;
    isRunning.boxGeneration = true;

    try {
      logEvent('cron_box_generation_start');
      await boxService.generateBoxes();
      logEvent('cron_box_generation_complete');
    } catch (error) {
      logError(error as Error, { cron: 'box_generation' });
    } finally {
      isRunning.boxGeneration = false;
    }
  }, {
    timezone: 'UTC'
  });

  cron.schedule('5 * * * *', async () => {
    if (isRunning.boxExpiration) return;
    isRunning.boxExpiration = true;

    try {
      logEvent('cron_box_expiration_start');
      const result = await boxService.expireOldBoxes();
      logEvent('cron_box_expiration_complete', result);
    } catch (error) {
      logError(error as Error, { cron: 'box_expiration' });
    } finally {
      isRunning.boxExpiration = false;
    }
  }, {
    timezone: 'UTC'
  });

  cron.schedule('0 0 * * *', async () => {
    if (isRunning.boxExpiration) return;
    isRunning.boxExpiration = true;

    try {
      logEvent('cron_cleanup_start');
      await boxService.cleanupOldBoxes(30);
      logEvent('cron_cleanup_complete');
    } catch (error) {
      logError(error as Error, { cron: 'cleanup' });
    } finally {
      isRunning.boxExpiration = false;
    }
  }, {
    timezone: 'UTC'
  });

  cron.schedule('0 2 * * *', async () => {
    if (isRunning.walletChecks) return;
    isRunning.walletChecks = true;

    try {
      logEvent('cron_wallet_checks_start');
      const result = await walletService.periodicWalletChecks();
      logEvent('cron_wallet_checks_complete', result);
    } catch (error) {
      logError(error as Error, { cron: 'wallet_checks' });
    } finally {
      isRunning.walletChecks = false;
    }
  }, {
    timezone: 'UTC'
  });

  cron.schedule('0 3 * * *', async () => {
    if (isRunning.badgeChecks) return;
    isRunning.badgeChecks = true;

    try {
      logEvent('cron_badge_checks_start');

      const { data: activeUsers } = await getSupabaseClient()
        .from('users')
        .select('id')
        .eq('is_banned', false)
        .eq('is_bot', false)
        .limit(100000);

      if (activeUsers) {
        const userIds = activeUsers.map(u => u.id);
        await badgeService.batchCheckAndAwardBadges(userIds);
      }

      logEvent('cron_badge_checks_complete');
    } catch (error) {
      logError(error as Error, { cron: 'badge_checks' });
    } finally {
      isRunning.badgeChecks = false;
    }
  }, {
    timezone: 'UTC'
  });

  cron.schedule('0 4 * * *', async () => {
    if (isRunning.leaderboardUpdate) return;
    isRunning.leaderboardUpdate = true;

    try {
      logEvent('cron_leaderboard_update_start');

      await Promise.all([
        leaderboardService.updateLeaderboardCache('daily'),
        leaderboardService.updateLeaderboardCache('weekly'),
        leaderboardService.updateLeaderboardCache('monthly')
      ]);

      logEvent('cron_leaderboard_update_complete');
    } catch (error) {
      logError(error as Error, { cron: 'leaderboard_update' });
    } finally {
      isRunning.leaderboardUpdate = false;
    }
  }, {
    timezone: 'UTC'
  });

  logInfo('Cron jobs initialized');
}

function logInfo(message: string): void {
  console.log(`[${new Date().toISOString()}] [CRON] INFO: ${message}`);
}
