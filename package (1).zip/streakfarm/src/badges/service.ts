import { getSupabaseClient } from '../db/client';
import { getUser } from './service';
import { getUserLeaderboardRank } from '../leaderboards/service';
import { walletService } from '../wallet/service';
import { sendTelegramNotification } from '../notifications/service';
import { logEvent } from '../utils/logger';
import { redisCache } from '../cache/redis';
import { getTONBalance } from '../ton/client';

interface Badge {
  id: string;
  name: string;
  description: string;
  icon_emoji: string;
  image_url?: string;
  badge_category: 'streak' | 'achievement' | 'wallet' | 'special';
  multiplier: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';
  requirements: Record<string, any>;
  max_supply?: number;
  current_supply: number;
  is_active: boolean;
  can_convert_to_nft: boolean;
}

interface UserBadge {
  id: string;
  user_id: string;
  badge_id: string;
  earned_at: string;
  expires_at?: string;
  is_active: boolean;
  badges: Badge;
}

interface BadgeProgress {
  current: number;
  required: number;
  percentage: number;
}

interface AvailableBadge extends Badge {
  progress?: BadgeProgress;
}

class BadgeService {
  async checkAndAwardBadges(userId: string, batchMode: boolean = false): Promise<Badge[]> {
    const cacheKey = `user_badges_check:${userId}`;
    if (!batchMode) {
      const cached = await redisCache.get<Badge[]>(cacheKey);
      if (cached) return cached;
    }

    const user = await getUser(userId);
    const newBadges: Badge[] = [];

    const { data: allBadges, error: badgesError } = await getSupabaseClient()
      .from('badges')
      .select('*')
      .eq('is_active', true)
      .or('available_from.is_null,available_from.lte.' + new Date().toISOString())
      .or('available_until.is_null,available_until.gte.' + new Date().toISOString());

    if (badgesError) throw badgesError;

    const { data: userBadges, error: userBadgesError } = await getSupabaseClient()
      .from('user_badges')
      .select('badge_id')
      .eq('user_id', userId)
      .eq('is_active', true);

    if (userBadgesError) throw userBadgesError;

    const ownedBadgeIds = new Set(userBadges?.map(b => b.badge_id) || []);

    for (const badge of allBadges || []) {
      if (ownedBadgeIds.has(badge.id)) continue;
      if (badge.max_supply && badge.current_supply >= badge.max_supply) continue;

      const isEligible = await this.checkBadgeEligibility(user, badge);

      if (isEligible) {
        await this.awardBadge(userId, badge.id);
        newBadges.push(badge);
      }
    }

    if (!batchMode && newBadges.length > 0) {
      await redisCache.set(cacheKey, newBadges, redisCache.getDefaultTTL('userBadges'));
    }

    return newBadges;
  }

  async batchCheckAndAwardBadges(userIds: string[]): Promise<void> {
    for (let i = 0; i < userIds.length; i += 100) {
      const batch = userIds.slice(i, i + 100);
      await Promise.all(batch.map(id => this.checkAndAwardBadges(id, true)));
    }
  }

  private async checkBadgeEligibility(user: any, badge: Badge): Promise<boolean> {
    const req = badge.requirements;

    if (req.streak_days && user.streak_current < req.streak_days) return false;

    if (req.total_points && user.raw_points < req.total_points) return false;

    if (req.user_number_max) {
      const { count, error } = await getSupabaseClient()
        .from('users')
        .select('id', { count: 'exact' })
        .lte('created_at', user.created_at);

      if (error) throw error;
      if (count > req.user_number_max) return false;
    }

    if (req.joined_within_days) {
      const launchDate = new Date(process.env.LAUNCH_DATE!);
      const userJoinedDate = new Date(user.created_at);
      const daysSinceLaunch = (userJoinedDate.getTime() - launchDate.getTime()) / (1000 * 60 * 60 * 24);
      if (daysSinceLaunch > req.joined_within_days) return false;
    }

    if (req.leaderboard_rank) {
      const rank = await getUserLeaderboardRank(user.id);
      if (rank === null || rank > req.leaderboard_rank) return false;
    }

    if (req.referrals && user.total_referrals < req.referrals) return false;

    if (req.boxes_opened && user.total_boxes_opened < req.boxes_opened) return false;

    if (req.boxes_per_hour) {
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const { count, error } = await getSupabaseClient()
        .from('boxes')
        .select('id', { count: 'exact' })
        .eq('user_id', user.id)
        .gte('opened_at', oneHourAgo.toISOString())
        .not('opened_at', 'is', null);

      if (error) throw error;
      if (count < req.boxes_per_hour) return false;
    }

    if (req.bots_reported && (user.bots_reported || 0) < req.bots_reported) return false;

    if (req.wallet_connected && !user.wallet_address) return false;

    if (req.ton_balance && user.wallet_address) {
      const balance = await getTONBalance(user.wallet_address);
      if (balance < req.ton_balance) return false;
    }

    if (req.has_nfts && user.wallet_address) {
      const nfts = await walletService.getUserNFTsFromBlockchain(user.wallet_address);
      if (nfts.length === 0) return false;
    }

    if (req.seasonal) {
      const now = new Date();
      if (now.getMonth() !== 11) return false;
    }

    return true;
  }

  async awardBadge(userId: string, badgeId: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('user_badges')
      .insert({
        user_id: userId,
        badge_id: badgeId,
        earned_at: new Date().toISOString()
      });

    if (error) throw error;

    await this.recalculateUserMultiplier(userId);

    const { data: badge, error: badgeError } = await getSupabaseClient()
      .from('badges')
      .select('*')
      .eq('id', badgeId)
      .single();

    if (badgeError) throw badgeError;

    const user = await getUser(userId);

    await sendTelegramNotification(user.telegram_id, {
      title: `🎉 New Badge Earned!`,
      body: `${badge.icon_emoji} ${badge.name} - ${badge.multiplier}× multiplier!`,
      data: { badge_id: badgeId }
    });

    await logEvent('badge_earned', { userId, badgeId, multiplier: badge.multiplier });
  }

  async revokeBadge(userId: string, badgeId: string, reason: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('user_badges')
      .update({
        is_active: false,
        expires_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      .eq('badge_id', badgeId);

    if (error) throw error;

    await this.recalculateUserMultiplier(userId);

    await logEvent('badge_revoked', { userId, badgeId, reason });
  }

  async recalculateUserMultiplier(userId: string): Promise<number> {
    const { data: userBadges, error } = await getSupabaseClient()
      .from('user_badges')
      .select('badges!inner(multiplier)')
      .eq('user_id', userId)
      .eq('is_active', true);

    if (error) throw error;

    const baseMultiplier = 1.0;
    const badgeBonuses = userBadges?.reduce((sum, ub) => sum + (ub.badges.multiplier - 1.0), 0) || 0;

    const totalMultiplier = baseMultiplier + badgeBonuses;

    const { error: updateError } = await getSupabaseClient()
      .from('users')
      .update({ multiplier_permanent: totalMultiplier })
      .eq('id', userId);

    if (updateError) throw updateError;

    await redisCache.del(`user_multiplier:${userId}`);
    await redisCache.del(`user_badges:${userId}`);

    return totalMultiplier;
  }

  async getUserBadges(userId: string): Promise<UserBadge[]> {
    const cacheKey = `user_badges:${userId}`;
    const cached = await redisCache.get<UserBadge[]>(cacheKey);
    if (cached) return cached;

    const { data, error } = await getSupabaseClient()
      .from('user_badges')
      .select('*, badges(*)')
      .eq('user_id', userId)
      .eq('is_active', true)
      .order('earned_at', { ascending: false });

    if (error) throw error;

    await redisCache.set(cacheKey, data || [], redisCache.getDefaultTTL('userBadges'));

    return data || [];
  }

  async getAvailableBadges(userId: string): Promise<AvailableBadge[]> {
    const user = await getUser(userId);
    const { data: allBadges, error: allError } = await getSupabaseClient()
      .from('badges')
      .select('*')
      .eq('is_active', true)
      .or('available_from.is_null,available_from.lte.' + new Date().toISOString())
      .or('available_until.is_null,available_until.gte.' + new Date().toISOString());

    if (allError) throw allError;

    const { data: ownedBadges, error: ownedError } = await getSupabaseClient()
      .from('user_badges')
      .select('badge_id')
      .eq('user_id', userId)
      .eq('is_active', true);

    if (ownedError) throw ownedError;

    const ownedIds = new Set(ownedBadges?.map(b => b.badge_id) || []);

    const available: AvailableBadge[] = [];
    for (const badge of allBadges || []) {
      if (ownedIds.has(badge.id)) continue;

      const progress = await this.getBadgeProgress(user, badge);
      available.push({ ...badge, progress });
    }

    return available;
  }

  private async getBadgeProgress(user: any, badge: Badge): Promise<BadgeProgress> {
    const req = badge.requirements;

    if (req.streak_days) {
      return {
        current: user.streak_current,
        required: req.streak_days,
        percentage: Math.min(100, (user.streak_current / req.streak_days) * 100)
      };
    }

    if (req.total_points) {
      return {
        current: user.raw_points,
        required: req.total_points,
        percentage: Math.min(100, (user.raw_points / req.total_points) * 100)
      };
    }

    if (req.referrals) {
      return {
        current: user.total_referrals,
        required: req.referrals,
        percentage: Math.min(100, (user.total_referrals / req.referrals) * 100)
      };
    }

    if (req.boxes_opened) {
      return {
        current: user.total_boxes_opened,
        required: req.boxes_opened,
        percentage: Math.min(100, (user.total_boxes_opened / req.boxes_opened) * 100)
      };
    }

    if (req.bots_reported) {
      const current = user.bots_reported || 0;
      return {
        current,
        required: req.bots_reported,
        percentage: Math.min(100, (current / req.bots_reported) * 100)
      };
    }

    if (req.ton_balance && user.wallet_address) {
      const balance = await getTONBalance(user.wallet_address);
      return {
        current: balance,
        required: req.ton_balance,
        percentage: Math.min(100, (balance / req.ton_balance) * 100)
      };
    }

    return { current: 0, required: 1, percentage: 0 };
  }

  async getBadgeById(badgeId: string): Promise<Badge | null> {
    const { data, error } = await getSupabaseClient()
      .from('badges')
      .select('*')
      .eq('id', badgeId)
      .single();

    if (error) return null;
    return data;
  }

  async getAllBadges(): Promise<Badge[]> {
    const { data, error } = await getSupabaseClient()
      .from('badges')
      .select('*')
      .eq('is_active', true)
      .order('multiplier', { ascending: false });

    if (error) throw error;
    return data || [];
  }

  async getBadgeStats(): Promise<{
    totalBadges: number;
    totalUsersWithBadges: number;
    mostPopularBadge: Badge | null;
    averageBadgesPerUser: number;
  }> {
    const { count: totalBadges } = await getSupabaseClient()
      .from('badges')
      .select('id', { count: 'exact' })
      .eq('is_active', true);

    const { count: totalUsersWithBadges } = await getSupabaseClient()
      .from('user_badges')
      .select('user_id', { count: 'exact' })
      .eq('is_active', true);

    const { data: badgeCounts } = await getSupabaseClient()
      .from('user_badges')
      .select('badge_id', { count: 'exact' })
      .eq('is_active', true)
      .group('badge_id');

    let mostPopularBadge: Badge | null = null;
    let maxCount = 0;

    if (badgeCounts) {
      for (const bc of badgeCounts) {
        if (bc.count > maxCount) {
          maxCount = bc.count;
          mostPopularBadge = await this.getBadgeById(bc.badge_id);
        }
      }
    }

    const totalBadgeAwards = badgeCounts?.reduce((sum, bc) => sum + bc.count, 0) || 0;
    const uniqueUsers = totalUsersWithBadges || 1;
    const averageBadgesPerUser = totalBadgeAwards / uniqueUsers;

    return {
      totalBadges: totalBadges || 0,
      totalUsersWithBadges: totalUsersWithBadges || 0,
      mostPopularBadge,
      averageBadgesPerUser
    };
  }
}

export const badgeService = new BadgeService();
export type { Badge, UserBadge, AvailableBadge, BadgeProgress };
