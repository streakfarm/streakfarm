import { getSupabaseClient } from '../db/client';
import { logEvent, logError } from '../utils/logger';
import { redisCache } from '../cache/redis';
import { v4 as uuidv4 } from 'uuid';
import * as FingerprintJS from '@fingerprintjs/fingerprintjs';

interface FlagReason {
  type: 'suspicious_activity' | 'bot_detected' | 'multiple_accounts' | 'cheating' | 'report_received';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  metadata?: Record<string, any>;
}

interface BehaviorAnalysisResult {
  isSuspicious: boolean;
  riskScore: number;
  reasons: string[];
  recommendedAction: 'allow' | 'flag' | 'block';
}

class AntiFraudService {
  private readonly THRESHOLDS = {
    maxAccountsPerFingerprint: parseInt(process.env.MAX_ACCOUNTS_PER_FINGERPRINT || '3'),
    maxBoxesPerMinute: 5,
    maxBoxesPerHour: 20,
    maxTasksPerHour: 10,
    reportThresholdForBan: 5,
    velocityThresholdPoints: 10000
  };

  async analyzeUserBehavior(userId: string): Promise<BehaviorAnalysisResult> {
    const reasons: string[] = [];
    let riskScore = 0;

    const user = await getSupabaseClient()
      .from('users')
      .select('*, user_flags(*)')
      .eq('id', userId)
      .single();

    if (user.error || !user.data) {
      return {
        isSuspicious: true,
        riskScore: 100,
        reasons: ['User not found'],
        recommendedAction: 'block'
      };
    }

    if (user.data.is_banned) {
      return {
        isSuspicious: true,
        riskScore: 100,
        reasons: ['User is banned'],
        recommendedAction: 'block'
      };
    }

    if (user.data.user_flags?.some(f => !f.resolved)) {
      const unresolvedFlags = user.data.user_flags.filter(f => !f.resolved);
      riskScore += unresolvedFlags.length * 20;
      reasons.push(`${unresolvedFlags.length} unresolved flags`);
    }

    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    const oneMinuteAgo = new Date(now.getTime() - 60 * 1000);

    const { count: boxesPerMinute } = await getSupabaseClient()
      .from('boxes')
      .select('id', { count: 'exact' })
      .eq('user_id', userId)
      .gte('opened_at', oneMinuteAgo.toISOString());

    if (boxesPerMinute && boxesPerMinute > this.THRESHOLDS.maxBoxesPerMinute) {
      riskScore += 25;
      reasons.push(`High box opening velocity: ${boxesPerMinute}/min`);
    }

    const { count: boxesPerHour } = await getSupabaseClient()
      .from('boxes')
      .select('id', { count: 'exact' })
      .eq('user_id', userId)
      .gte('opened_at', oneHourAgo.toISOString());

    if (boxesPerHour && boxesPerHour > this.THRESHOLDS.maxBoxesPerHour) {
      riskScore += 15;
      reasons.push(`Excessive box openings: ${boxesPerHour}/hour`);
    }

    const { count: tasksPerHour } = await getSupabaseClient()
      .from('task_completions')
      .select('id', { count: 'exact' })
      .eq('user_id', userId)
      .gte('completed_at', oneHourAgo.toISOString());

    if (tasksPerHour && tasksPerHour > this.THRESHOLDS.maxTasksPerHour) {
      riskScore += 10;
      reasons.push(`High task completion velocity: ${tasksPerHour}/hour`);
    }

    if (user.data.report_count && user.data.report_count >= this.THRESHOLDS.reportThresholdForBan) {
      riskScore += 50;
      reasons.push(`High report count: ${user.data.report_count}`);
    }

    const isSuspicious = riskScore >= 50;
    let recommendedAction: 'allow' | 'flag' | 'block' = 'allow';

    if (riskScore >= 80) {
      recommendedAction = 'block';
    } else if (riskScore >= 50) {
      recommendedAction = 'flag';
    }

    return {
      isSuspicious,
      riskScore,
      reasons,
      recommendedAction
    };
  }

  async flagUser(userId: string, reason: FlagReason): Promise<void> {
    const { error: flagError } = await getSupabaseClient()
      .from('user_flags')
      .insert({
        user_id: userId,
        flag_type: reason.type,
        severity: reason.severity,
        description: reason.description,
        metadata: reason.metadata || {}
      });

    if (flagError) throw flagError;

    const { error: updateError } = await getSupabaseClient()
      .from('users')
      .update({
        is_flagged: true,
        flag_reason: reason.description
      })
      .eq('id', userId);

    if (updateError) throw updateError;

    await redisCache.del(`user:${userId}`);

    await logEvent('user_flagged', { userId, ...reason });
  }

  async banUser(userId: string, reason: string, autoBanned: boolean = false): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('users')
      .update({
        is_banned: true,
        ban_reason: reason
      })
      .eq('id', userId);

    if (error) throw error;

    await this.revokeAllBadges(userId);

    await this.invalidateUserData(userId);

    await logEvent('user_banned', { userId, reason, autoBanned });
  }

  async reportBot(reporterId: string, reportedTelegramId: number, reason?: string): Promise<{
    success: boolean;
    reportCount: number;
    actionTaken?: string;
    error?: string;
  }> {
    try {
      const { data: reportedUser, error: findError } = await getSupabaseClient()
        .from('users')
        .select('id, report_count, is_banned')
        .eq('telegram_id', reportedTelegramId)
        .single();

      if (findError || !reportedUser) {
        return { success: false, reportCount: 0, error: 'Reported user not found' };
      }

      if (reportedUser.is_banned) {
        return { success: false, reportCount: reportedUser.report_count || 0, error: 'User already banned' };
      }

      const newReportCount = (reportedUser.report_count || 0) + 1;

      const { error: updateError } = await getSupabaseClient()
        .from('users')
        .update({ report_count: newReportCount })
        .eq('telegram_id', reportedTelegramId);

      if (updateError) throw updateError;

      await this.flagUser(reporterId, {
        type: 'report_received',
        severity: 'low',
        description: `Reported user ${reportedTelegramId}`,
        metadata: { reported_user_id: reportedUser.id, reason }
      });

      if (newReportCount >= this.THRESHOLDS.reportThresholdForBan && !reportedUser.is_banned) {
        await this.banUser(
          reportedUser.id,
          `Auto-banned after ${newReportCount} reports`,
          true
        );

        return {
          success: true,
          reportCount: newReportCount,
          actionTaken: 'banned'
        };
      }

      return {
        success: true,
        reportCount: newReportCount
      };
    } catch (error) {
      logError(error as Error, { reporterId, reportedTelegramId });
      return { success: false, reportCount: 0, error: 'Failed to process report' };
    }
  }

  async checkFingerprintDuplication(fingerprint: string): Promise<{
    duplicate: boolean;
    existingAccounts: number;
    action: 'allow' | 'flag' | 'block';
  }> {
    const { data: accounts, error } = await getSupabaseClient()
      .from('users')
      .select('id, is_banned')
      .eq('fingerprint', fingerprint);

    if (error) {
      return { duplicate: false, existingAccounts: 0, action: 'allow' };
    }

    const activeAccounts = accounts?.filter(a => !a.is_banned).length || 0;

    if (activeAccounts >= this.THRESHOLDS.maxAccountsPerFingerprint) {
      return {
        duplicate: true,
        existingAccounts: activeAccounts,
        action: 'flag'
      };
    }

    return {
      duplicate: activeAccounts > 0,
      existingAccounts: activeAccounts,
      action: 'allow'
    };
  }

  async generateFingerprint(userAgent: string, ipAddress: string): Promise<string> {
    const fp = await FingerprintJS.load();
    const result = await fp.get();

    const fingerprintComponents = [
      result.visitorId,
      userAgent.substring(0, 100),
      ipAddress,
      result.components.platform?.value,
      result.components.canvas?.hash
    ].filter(Boolean).join('|');

    return Buffer.from(fingerprintComponents).toString('base64');
  }

  async resolveFlag(flagId: string, resolvedBy: string, resolution: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('user_flags')
      .update({
        resolved: true,
        resolved_by: resolvedBy,
        resolved_at: new Date().toISOString(),
        metadata: getSupabaseClient().raw(`metadata || '{"resolution": "${resolution}"}'`)
      })
      .eq('id', flagId);

    if (error) throw error;

    await logEvent('flag_resolved', { flagId, resolvedBy, resolution });
  }

  async getUserFlags(userId: string): Promise<Array<{
    id: string;
    type: string;
    severity: string;
    description: string;
    resolved: boolean;
    createdAt: string;
  }>> {
    const { data, error } = await getSupabaseClient()
      .from('user_flags')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data?.map(f => ({
      id: f.id,
      type: f.flag_type,
      severity: f.severity,
      description: f.description,
      resolved: f.resolved,
      createdAt: f.created_at
    })) || [];
  }

  async getFraudStats(): Promise<{
    totalFlagged: number;
    totalBanned: number;
    autoBanned: number;
    topReasons: Array<{ reason: string; count: number }>;
    recentFlags: Array<{ userId: string; type: string; severity: string; createdAt: string }>;
  }> {
    const { count: totalFlagged } = await getSupabaseClient()
      .from('user_flags')
      .select('id', { count: 'exact' });

    const { count: totalBanned } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', true);

    const { count: autoBanned } = await getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', true)
      .ilike('ban_reason', '%auto-banned%');

    const { data: topReasons } = await getSupabaseClient()
      .from('user_flags')
      .select('flag_type', { count: 'exact' })
      .group('flag_type')
      .order('count', { ascending: false })
      .limit(5);

    const { data: recentFlags } = await getSupabaseClient()
      .from('user_flags')
      .select('user_id, flag_type, severity, created_at')
      .eq('resolved', false)
      .order('created_at', { ascending: false })
      .limit(10);

    return {
      totalFlagged: totalFlagged || 0,
      totalBanned: totalBanned || 0,
      autoBanned: autoBanned || 0,
      topReasons: topReasons?.map(r => ({
        reason: r.flag_type,
        count: r.count || 0
      })) || [],
      recentFlags: recentFlags?.map(f => ({
        userId: f.user_id,
        type: f.flag_type,
        severity: f.severity,
        createdAt: f.created_at
      })) || []
    };
  }

  private async revokeAllBadges(userId: string): Promise<void> {
    const { error } = await getSupabaseClient()
      .from('user_badges')
      .update({ is_active: false })
      .eq('user_id', userId);

    if (error) {
      logError(error as Error, { userId, operation: 'revoke_badges' });
    }
  }

  private async invalidateUserData(userId: string): Promise<void> {
    await redisCache.del([
      `user:${userId}`,
      `user_rank:${userId}`,
      `user_multiplier:${userId}`,
      `user_badges:${userId}`,
      `user_boxes:${userId}`
    ]);
  }
}

export const antiFraudService = new AntiFraudService();
export type { FlagReason, BehaviorAnalysisResult };
