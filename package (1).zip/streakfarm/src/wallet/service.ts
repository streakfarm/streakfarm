import { Address } from '@ton/core';
import { getSupabaseClient } from '../db/client';
import { badgeService } from '../badges/service';
import { awardPoints } from '../points/service';
import { logEvent } from '../utils/logger';
import { redisCache } from '../cache/redis';
import { getTONBalance, getUserNFTs } from '../ton/client';
import Sentry from '@sentry/node';

interface WalletConnectionResult {
  success: boolean;
  walletAddress: string;
  walletType: string;
  bonus: number;
  newBadges: any[];
  error?: string;
}

class WalletService {
  private tonApiEndpoint: string;
  private tonApiKey: string | undefined;
  private tonNftIndexer: string;

  constructor() {
    this.tonApiEndpoint = process.env.TON_API_ENDPOINT || 'https://toncenter.com/api/v2/jsonRPC';
    this.tonApiKey = process.env.TON_API_KEY;
    this.tonNftIndexer = process.env.TON_NFT_INDEXER || 'https://tonapi.io/v2';
  }

  async connectUserWallet(
    userId: string,
    walletAddress: string,
    walletType: string
  ): Promise<WalletConnectionResult> {
    try {
      let normalizedAddress: string;

      try {
        normalizedAddress = Address.parse(walletAddress).toString({ bounceable: true });
      } catch {
        return {
          success: false,
          walletAddress: '',
          walletType: '',
          bonus: 0,
          newBadges: [],
          error: 'Invalid TON address format'
        };
      }

      const { data: existing, error: existingError } = await getSupabaseClient()
        .from('users')
        .select('id')
        .eq('wallet_address', normalizedAddress)
        .neq('id', userId)
        .single();

      if (existingError && existingError.code !== 'PGRST116') {
        throw existingError;
      }

      if (existing) {
        return {
          success: false,
          walletAddress: '',
          walletType: '',
          bonus: 0,
          newBadges: [],
          error: 'Wallet already connected to another account'
        };
      }

      const { error: updateError } = await getSupabaseClient()
        .from('users')
        .update({
          wallet_address: normalizedAddress,
          wallet_type: walletType,
          wallet_connected_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (updateError) {
        throw updateError;
      }

      const newBadges = await badgeService.checkAndAwardBadges(userId);

      const bonus = 5000;
      await awardPoints(userId, bonus, { source: 'wallet_connect' });

      await this.checkWhaleBadges(userId, normalizedAddress);

      await logEvent('wallet_connected', { userId, walletType });

      return {
        success: true,
        walletAddress: normalizedAddress,
        walletType,
        bonus,
        newBadges
      };
    } catch (error) {
      Sentry.captureException(error);
      logEvent('wallet_connect_error', { userId, error });
      return {
        success: false,
        walletAddress: '',
        walletType: '',
        bonus: 0,
        newBadges: [],
        error: 'Failed to connect wallet'
      };
    }
  }

  async disconnectWallet(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await getSupabaseClient()
        .from('users')
        .update({
          wallet_address: null,
          wallet_type: null,
          wallet_connected_at: null
        })
        .eq('id', userId);

      if (error) throw error;

      await badgeService.recalculateUserMultiplier(userId);

      await logEvent('wallet_disconnected', { userId });

      return { success: true };
    } catch (error) {
      Sentry.captureException(error);
      return { success: false, error: 'Failed to disconnect wallet' };
    }
  }

  async checkWhaleBadges(userId: string, walletAddress: string): Promise<void> {
    try {
      const balance = await this.getCachedBalance(walletAddress);

      if (balance >= 100) {
        await badgeService.awardBadge(userId, 'mega_whale');
      } else if (balance >= 10) {
        await badgeService.awardBadge(userId, 'whale');
      }
    } catch (error) {
      logEvent('whale_badge_check_error', { userId, error });
    }
  }

  async periodicWalletChecks(batchSize: number = 10000): Promise<{
    checked: number;
    whaleUpgrades: number;
    errors: number;
  }> {
    let offset = 0;
    let checked = 0;
    let whaleUpgrades = 0;
    let errors = 0;

    try {
      while (true) {
        const { data: users, error } = await getSupabaseClient()
          .from('users')
          .select('id, wallet_address')
          .not('wallet_address', 'is', null)
          .range(offset, offset + batchSize - 1);

        if (error) throw error;
        if (!users || users.length === 0) break;

        for (const user of users) {
          if (!user.wallet_address) continue;

          try {
            const balance = await this.getCachedBalance(user.wallet_address);
            const previousBalanceTier = await this.getPreviousBalanceTier(user.id);

            if (balance >= 100 && previousBalanceTier < 100) {
              await badgeService.awardBadge(user.id, 'mega_whale');
              whaleUpgrades++;
            } else if (balance >= 10 && previousBalanceTier < 10) {
              await badgeService.awardBadge(user.id, 'whale');
              whaleUpgrades++;
            }

            await this.updateBalanceTier(user.id, balance);
          } catch {
            errors++;
          }
        }

        checked += users.length;
        offset += batchSize;
      }

      logEvent('wallet_periodic_checks_complete', { checked, whaleUpgrades, errors });
      return { checked, whaleUpgrades, errors };
    } catch (error) {
      logEvent('wallet_periodic_checks_error', { error });
      throw error;
    }
  }

  private async getCachedBalance(walletAddress: string): Promise<number> {
    const cacheKey = `ton_balance:${walletAddress}`;
    const cached = await redisCache.get<number>(cacheKey);

    if (cached !== null) return cached;

    const balance = await getTONBalance(walletAddress);
    await redisCache.set(cacheKey, balance, 3600);

    return balance;
  }

  private async getPreviousBalanceTier(userId: string): Promise<number> {
    const cacheKey = `balance_tier:${userId}`;
    const cached = await redisCache.get<number>(cacheKey);
    return cached ?? 0;
  }

  private async updateBalanceTier(userId: string, balance: number): Promise<void> {
    const cacheKey = `balance_tier:${userId}`;
    await redisCache.set(cacheKey, balance, 86400);
  }

  async getUserWalletInfo(userId: string): Promise<{
    connected: boolean;
    walletAddress?: string;
    walletType?: string;
    connectedAt?: string;
    balance?: number;
    nftCount?: number;
  }> {
    const { data: user, error } = await getSupabaseClient()
      .from('users')
      .select('wallet_address, wallet_type, wallet_connected_at')
      .eq('id', userId)
      .single();

    if (error || !user) {
      return { connected: false };
    }

    if (!user.wallet_address) {
      return { connected: false };
    }

    const balance = await this.getCachedBalance(user.wallet_address);
    const nfts = await this.getCachedNFTs(user.wallet_address);

    return {
      connected: true,
      walletAddress: user.wallet_address,
      walletType: user.wallet_type || undefined,
      connectedAt: user.wallet_connected_at,
      balance,
      nftCount: nfts.length
    };
  }

  private async getCachedNFTs(walletAddress: string): Promise<any[]> {
    const cacheKey = `ton_nfts:${walletAddress}`;
    const cached = await redisCache.get<any[]>(cacheKey);

    if (cached !== null) return cached;

    const nfts = await getUserNFTs(walletAddress);
    await redisCache.set(cacheKey, nfts, 3600);

    return nfts;
  }

  async getWalletExclusiveTasks(userId: string): Promise<any[]> {
    const walletInfo = await this.getUserWalletInfo(userId);

    if (!walletInfo.connected) {
      return [];
    }

    const tasks = [];

    if (walletInfo.balance && walletInfo.balance >= 1) {
      tasks.push({
        id: 'ton_holder_1',
        title: 'Hold 1 TON',
        description: 'Maintain 1+ TON in wallet',
        points: 1000,
        completed: true
      });
    }

    if (walletInfo.balance && walletInfo.balance >= 10) {
      tasks.push({
        id: 'whale_task_1',
        title: 'Hold 10 TON',
        description: 'Maintain 10+ TON in connected wallet',
        points: 10000,
        completed: true
      });
    }

    if (walletInfo.balance && walletInfo.balance >= 100) {
      tasks.push({
        id: 'mega_whale_task',
        title: 'Hold 100 TON',
        description: 'Maintain 100+ TON in connected wallet',
        points: 50000,
        completed: true
      });
    }

    if (walletInfo.nftCount && walletInfo.nftCount > 0) {
      tasks.push({
        id: 'nft_holder_task',
        title: 'Hold any TON NFT',
        description: 'Own at least 1 NFT on TON blockchain',
        points: 5000,
        completed: true
      });
    }

    if (walletInfo.nftCount && walletInfo.nftCount >= 5) {
      tasks.push({
        id: 'nft_multi_holder_task',
        title: 'Hold 5+ TON NFTs',
        description: 'Own at least 5 NFTs on TON blockchain',
        points: 20000,
        completed: true
      });
    }

    return tasks;
  }

  async verifyWalletOwnership(
    userId: string,
    walletAddress: string,
    signature: string,
    message: string
  ): Promise<boolean> {
    try {
      const { data: user, error } = await getSupabaseClient()
        .from('users')
        .select('wallet_address')
        .eq('id', userId)
        .single();

      if (error || !user) return false;

      if (user.wallet_address !== walletAddress) return false;

      const isValid = await this.verifySignature(walletAddress, message, signature);

      if (!isValid) {
        await logEvent('wallet_verification_failed', { userId, walletAddress });
      }

      return isValid;
    } catch (error) {
      logEvent('wallet_verification_error', { error });
      return false;
    }
  }

  private async verifySignature(
    walletAddress: string,
    message: string,
    signature: string
  ): Promise<boolean> {
    try {
      const response = await fetch(`${this.tonNftIndexer}/accounts/verifySignature`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(this.tonApiKey && { 'Authorization': `Bearer ${this.tonApiKey}` })
        },
        body: JSON.stringify({
          address: walletAddress,
          signature,
          message
        })
      });

      if (!response.ok) return false;

      const data = await response.json();
      return data.verified === true;
    } catch {
      return false;
    }
  }
}

export const walletService = new WalletService();
export type { WalletConnectionResult };
