import { getSupabaseClient } from '../db/client';
import { logEvent } from '../utils/logger';
import { redisCache } from '../cache/redis';

interface LeaderboardEntry {
  userId: string;
  username?: string;
  firstName?: string;
  points: number;
  rank: number;
  streakDays: number;
  boxesOpened: number;
  badgesCount: number;
}

interface PeriodConfig {
  type: 'daily' | 'weekly' | 'monthly' | 'all_time';
  startDate: Date;
  endDate: Date;
}

class LeaderboardService {
  private readonly CACHE_TTL = 60;

  getPeriodConfig(type: 'daily' | 'weekly' | 'monthly' | 'all_time'): PeriodConfig {
    const now = new Date();
    let startDate: Date;
    let endDate: Date;

    switch (type) {
      case 'daily':
        startDate = new Date(now);
        startDate.setHours(0, 0, 0, 0);
        endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + 1);
        break;

      case 'weekly':
        startDate = new Date(now);
        startDate.setDate(startDate.getDate() - startDate.getDay());
        startDate.setHours(0, 0, 0, 0);
        endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + 7);
        break;

      case 'monthly':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 1);
        break;

      case 'all_time':
      default:
        startDate = new Date(0);
        endDate = new Date(now.getTime() + 86400000);
        break;
    }

    return { type, startDate, endDate };
  }

  async getLeaderboard(
    period: 'daily' | 'weekly' | 'monthly' | 'all_time',
    limit: number = 100,
    offset: number = 0
  ): Promise<LeaderboardEntry[]> {
    const cacheKey = `leaderboard:${period}:${limit}:${offset}`;
    const cached = await redisCache.get<LeaderboardEntry[]>(cacheKey);

    if (cached) return cached;

    const config = this.getPeriodConfig(period);

    let query = getSupabaseClient()
      .from('users')
      .select('id, username, first_name, raw_points, streak_current, total_boxes_opened, multiplier_permanent')
      .eq('is_banned', false)
      .eq('is_bot', false);

    if (period !== 'all_time') {
      query = query
        .gte('last_active_at', config.startDate.toISOString())
        .lt('last_active_at', config.endDate.toISOString());
    }

    const { data: users, error } = await query
      .order('raw_points', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    const entries: LeaderboardEntry[] = users?.map((user, index) => ({
      userId: user.id,
      username: user.username || undefined,
      firstName: user.first_name || undefined,
      points: user.raw_points,
      rank: offset + index + 1,
      streakDays: user.streak_current,
      boxesOpened: user.total_boxes_opened,
      badgesCount: 0
    })) || [];

    await redisCache.set(cacheKey, entries, this.CACHE_TTL);

    return entries;
  }

  async getUserLeaderboardRank(
    userId: string,
    period: 'daily' | 'weekly' | 'monthly' | 'all_time' = 'all_time'
  ): Promise<number | null> {
    const cacheKey = `user_rank:${userId}:${period}`;
    const cached = await redisCache.get<number>(cacheKey);

    if (cached !== null) return cached;

    const user = await getSupabaseClient()
      .from('users')
      .select('raw_points, last_active_at')
      .eq('id', userId)
      .single();

    if (user.error || !user.data) return null;

    const config = this.getPeriodConfig(period);

    let query = getSupabaseClient()
      .from('users')
      .select('id', { count: 'exact' })
      .eq('is_banned', false)
      .eq('is_bot', false)
      .gt('raw_points', user.data.raw_points);

    if (period !== 'all_time') {
      query = query
        .gte('last_active_at', config.startDate.toISOString())
        .lt('last_active_at', config.endDate.toISOString());
    }

    const { count, error } = await query;

    if (error) throw error;

    const rank = (count || 0) + 1;
    await redisCache.set(cacheKey, rank, this.CACHE_TTL);

    return rank;
  }

  async getLeaderboardAroundUser(
    userId: string,
    period: 'daily' | 'weekly' | 'monthly' | 'all_time' = 'all_time',
    range: number = 5
  ): Promise<{
    userEntry: LeaderboardEntry;
    nearbyEntries: LeaderboardEntry[];
  }> {
    const userRank = await this.getUserLeaderboardRank(userId, period);

    if (userRank === null) {
      throw new Error('User not found');
    }

    const startRank = Math.max(1, userRank - range);
    const endRank = userRank + range;

    const entries = await this.getLeaderboard(period, endRank - startRank + 1, startRank - 1);

    const userEntry = entries.find(e => e.userId === userId);

    if (!userEntry) {
      const user = await getSupabaseClient()
        .from('users')
        .select('id, username, first_name, raw_points, streak_current, total_boxes_opened')
        .eq('id', userId)
        .single();

      return {
        userEntry: {
          userId,
          username: user.data?.username || undefined,
          firstName: user.data?.first_name || undefined,
          points: user.data?.raw_points || 0,
          rank: userRank,
          streakDays: user.data?.streak_current || 0,
          boxesOpened: user.data?.total_boxes_opened || 0,
          badgesCount: 0
        },
        nearbyEntries: entries.filter(e => e.userId !== userId)
      };
    }

    return {
      userEntry,
      nearbyEntries: entries.filter(e => e.userId !== userId)
    };
  }

  async getLeaderboardStats(period: 'daily' | 'weekly' | 'monthly' | 'all_time'): Promise<{
    totalParticipants: number;
    topPointGain: number;
    averagePoints: number;
    topStreak: number;
    topBoxesOpened: number;
  }> {
    const entries = await this.getLeaderboard(period, 10000, 0);

    if (entries.length === 0) {
      return {
        totalParticipants: 0,
        topPointGain: 0,
        averagePoints: 0,
        topStreak: 0,
        topBoxesOpened: 0
      };
    }

    const totalPoints = entries.reduce((sum, e) => sum + e.points, 0);
    const averagePoints = Math.floor(totalPoints / entries.length);

    return {
      totalParticipants: entries.length,
      topPointGain: entries[0]?.points || 0,
      averagePoints,
      topStreak: Math.max(...entries.map(e => e.streakDays)),
      topBoxesOpened: Math.max(...entries.map(e => e.boxesOpened))
    };
  }

  async updateLeaderboardCache(period: 'daily' | 'weekly' | 'monthly' | 'all_time'): Promise<void> {
    try {
      await redisCache.del(`leaderboard:${period}:*`);

      const entries = await this.getLeaderboard(period, 100, 0);

      await redisCache.set(`leaderboard:${period}:100:0`, entries, this.CACHE_TTL);

      logEvent('leaderboard_cache_updated', { period, count: entries.length });
    } catch (error) {
      logEvent('leaderboard_cache_update_error', { period, error });
    }
  }

  async getContestLeaderboard(contestId: string): Promise<LeaderboardEntry[]> {
    const cacheKey = `contest_leaderboard:${contestId}`;
    const cached = await redisCache.get<LeaderboardEntry[]>(cacheKey);

    if (cached) return cached;

    const { data: contestParticipants, error } = await getSupabaseClient()
      .from('contest_participants')
      .select('user_id, points')
      .eq('contest_id', contestId)
      .order('points', { ascending: false })
      .limit(100);

    if (error) throw error;

    const userIds = contestParticipants?.map(p => p.user_id) || [];

    if (userIds.length === 0) {
      return [];
    }

    const { data: users, error: userError } = await getSupabaseClient()
      .from('users')
      .select('id, username, first_name, raw_points, streak_current, total_boxes_opened')
      .in('id', userIds);

    if (userError) throw userError;

    const userMap = new Map(users?.map(u => [u.id, u]) || []);
    const pointsMap = new Map(contestParticipants?.map(p => [p.user_id, p.points]) || []);

    const entries: LeaderboardEntry[] = contestParticipants!.map((participant, index) => {
      const user = userMap.get(participant.user_id);
      return {
        userId: participant.user_id,
        username: user?.username || undefined,
        firstName: user?.first_name || undefined,
        points: participant.points,
        rank: index + 1,
        streakDays: user?.streak_current || 0,
        boxesOpened: user?.total_boxes_opened || 0,
        badgesCount: 0
      };
    });

    await redisCache.set(cacheKey, entries, this.CACHE_TTL * 10);

    return entries;
  }

  async getUserContestRank(
    userId: string,
    contestId: string
  ): Promise<number | null> {
    const { data: contestParticipants, error } = await getSupabaseClient()
      .from('contest_participants')
      .select('points')
      .eq('contest_id', contestId)
      .eq('user_id', userId)
      .single();

    if (error || !contestParticipants) return null;

    const { count, countError } = await getSupabaseClient()
      .from('contest_participants')
      .select('user_id', { count: 'exact' })
      .eq('contest_id', contestId)
      .gt('points', contestParticipants.points);

    if (countError) throw countError;

    return (count || 0) + 1;
  }
}

export const leaderboardService = new LeaderboardService();
export type { LeaderboardEntry, PeriodConfig };
