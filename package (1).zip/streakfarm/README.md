# STREAKFARM - Production-Ready Telegram Mini App

<div align="center">

![StreakFarm Logo](https://streakfarm.app/icon.png)

**A viral Telegram Mini App with gamification, TON blockchain integration, and enterprise-grade architecture**

[![Node.js](https://img.shields.io/badge/Node.js-20+-green?style=for-the-badge&logo=node.js)](https://nodejs.org)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue?style=for-the-badge&logo=typescript)](https://typescriptlang.org)
[![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)](https://react.dev)
[![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker)](https://docker.com)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-336791?style=for-the-badge&logo=postgresql)](https://postgresql.org)

</div>

## 🎯 Features

### Core Gameplay
- **Hourly Boxes**: 24 boxes/day with 3 rarities (Common, Rare, Legendary)
- **Digital Badges**: 25+ badges with permanent multipliers
- **Streak System**: Daily streaks with increasing rewards
- **Referral System**: 2-sided rewards (1000 + 500 pts)

### Web3 Integration
- **TON Wallet**: Connect via TON Connect protocol
- **Balance Verification**: Automatic whale badge detection
- **NFT Detection**: Check for TON NFT holdings
- **Airdrop Ready**: NFT conversion prepared for Month 2+

### Enterprise Features
- **Anti-Fraud**: Device fingerprinting, rate limiting, bot detection
- **Real-time Analytics**: Live metrics via Prometheus/Grafana
- **Auto-Scaling**: Docker + Kubernetes ready
- **99.9% SLA**: Designed for 500M+ users

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ | pnpm 9+
- Docker & Docker Compose
- PostgreSQL 14+ (Supabase recommended)
- Redis 7+

### Installation

```bash
# Clone repository
git clone https://github.com/your-org/streakfarm.git
cd streakfarm

# Install dependencies
pnpm install

# Setup environment variables
cp .env.example .env
# Edit .env with your credentials

# Start with Docker (recommended)
pnpm docker:up

# Or run locally
pnpm install
pnpm db:migrate
pnpm dev
```

### Environment Variables

```env
# Application
NODE_ENV=development
PORT=3000

# Supabase (PostgreSQL)
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SUPABASE_ANON_KEY=your-anon-key

# Redis Cache
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# TON Blockchain
TON_API_ENDPOINT=https://toncenter.com/api/v2/jsonRPC
TON_API_KEY=your-ton-api-key
TON_NFT_INDEXER=https://tonapi.io/v2

# Telegram
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_API_ID=your-api-id
TELEGRAM_API_HASH=your-api-hash

# Security
JWT_SECRET=your-jwt-secret
ADMIN_API_KEY=your-admin-key
FINGERPRINT_SALT=your-secret-salt

# Monitoring
SENTRY_DSN=https://your-sentry-dsn
PROMETHEUS_ENABLED=true

# Launch Date (for Early Adopter badge)
LAUNCH_DATE=2025-01-15T00:00:00Z
```

## 📁 Project Structure

```
streakfarm/
├── .github/
│   └── workflows/              # CI/CD pipelines
│
├── apps/
│   ├── backend/               # Node.js API server
│   │   ├── src/
│   │   │   ├── config/        # Configuration & environment
│   │   │   ├── modules/       # Domain modules (DDD)
│   │   │   ├── middleware/    # Express middleware
│   │   │   ├── utils/         # Utility functions
│   │   │   ├── cron/          # Scheduled jobs
│   │   │   ├── api/           # Route definitions
│   │   │   └── server.ts      # Entry point
│   │   ├── package.json
│   │   └── Dockerfile
│   │
│   └── frontend/              # React + Vite client
│       ├── src/
│       │   ├── components/    # React components
│       │   ├── hooks/         # Custom hooks
│       │   ├── pages/         # Page components
│       │   ├── services/      # API services
│       │   ├── store/         # State management
│       │   └── App.tsx
│       ├── package.json
│       └── Dockerfile
│
├── packages/
│   └── shared/                # Shared types & utilities
│       ├── types/             # TypeScript definitions
│       ├── constants/         # Game constants
│       └── utils/             # Shared utilities
│
├── infra/                     # Infrastructure as code
│   ├── docker/
│   ├── nginx/
│   └── monitoring/
│
├── docs/                      # Documentation
│   ├── architecture.md
│   ├── database-schema.md
│   └── api-spec.md
│
├── scripts/                   # Utility scripts
│   ├── dev/
│   └── prod/
│
├── docker-compose.yml
├── turbo.json
└── README.md
```

## 🏗️ Architecture

### Backend Stack
- **Framework**: Express.js with TypeScript
- **Database**: Supabase (PostgreSQL) with Prisma-like patterns
- **Cache**: Redis with ioredis
- **Auth**: Telegram WebApp Data validation
- **Monitoring**: Sentry + Prometheus

### Frontend Stack
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **State**: Zustand + TanStack Query
- **Styling**: Tailwind CSS
- **TMA SDK**: @twa-dev/sdk

### Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    Telegram Client                           │
└─────────────────────┬───────────────────────────────────────┘
                      │ HTTPS
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                    Nginx Reverse Proxy                       │
│        (SSL Termination + Load Balancing)                   │
└─────────────────────┬───────────────────────────────────────┘
                      │
          ┌───────────┴───────────┐
          ▼                       ▼
┌─────────────────┐     ┌─────────────────┐
│  Backend API    │     │  Frontend SPA   │
│  (Node.js)      │     │  (React/Vite)   │
└────────┬────────┘     └─────────────────┘
         │
    ┌────┴────┐
    ▼         ▼
┌───────┐  ┌───────┐
│Redis │  │PostgreSQL│
└───────┘  └─────────┘
```

## 📡 API Endpoints

### Version 1 API (`/api/v1/`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/upsert` | Create/update user |
| GET | `/api/v1/users/:id` | Get user profile |
| POST | `/api/v1/users/:id/checkin` | Daily check-in |
| GET | `/api/v1/boxes/:userId` | Get available boxes |
| POST | `/api/v1/boxes/:userId/open/:boxId` | Open a box |
| GET | `/api/v1/badges` | List all badges |
| GET | `/api/v1/badges/owned/:userId` | Get user badges |
| POST | `/api/v1/wallet/connect` | Connect TON wallet |
| GET | `/api/v1/leaderboard` | Get leaderboard |
| GET | `/api/v1/tasks` | Get available tasks |
| POST | `/api/v1/tasks/:id/complete` | Complete task |
| GET | `/api/v1/referrals/:userId` | Get referrals |

### Admin API (`/api/admin/`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/config` | Get system config |
| PATCH | `/api/admin/config` | Update config |
| POST | `/api/admin/users/:id/ban` | Ban user |
| POST | `/api/admin/users/:id/unban` | Unban user |
| POST | `/api/admin/badges/award` | Award badge |
| POST | `/api/admin/notifications/bulk` | Send bulk notification |
| GET | `/api/admin/stats` | Get platform stats |

## 🎮 Badge System

### Streak Badges
| Badge | Days | Multiplier |
|-------|------|------------|
| 🔥 7-Day Streak | 7 | 1.1× |
| 🔥 14-Day Streak | 14 | 1.2× |
| 🔥 30-Day Streak | 30 | 1.5× |
| 🔥 90-Day Streak | 90 | 2.5× |
| 🔥 365-Day Streak | 365 | 5.0× |
| 🔥 730-Day Streak | 730 | 10.0× |

### Achievement Badges
| Badge | Requirement | Multiplier |
|-------|-------------|------------|
| 👑 Founding Member | First 10K users | 2.0× |
| 🎁 Early Adopter | Month 1 signup | 2.5× |
| 💰 Millionaire | 1M points | 1.5× |
| 🏆 Top 100 | Leaderboard | 2.0× |
| 🌟 Influencer | 100 referrals | 1.75× |

### Wallet Badges
| Badge | Requirement | Multiplier |
|-------|-------------|------------|
| 👛 Wallet Connected | Connect wallet | 1.1× |
| 🐋 Whale | 10+ TON | 2.0× |
| 🐳 Mega Whale | 100+ TON | 3.0× |
| 💎 NFT Holder | Any TON NFT | 1.5× |

## 🔒 Security

- **Authentication**: Telegram `initData` validation on every request
- **Rate Limiting**: Redis-backed sliding window (100 req/min)
- **Anti-Fraud**: Device fingerprinting + behavior analysis
- **Data Protection**: Row-level security on Supabase
- **Audit Logging**: All admin actions logged

## 📊 Monitoring

### Metrics Endpoint
```
GET /metrics
```

Available metrics:
- `http_requests_total` - Total HTTP requests
- `http_request_duration_seconds` - Response time
- `active_users` - Currently online users
- `points_earned_total` - Total points generated
- `boxes_opened_total` - Total boxes opened

### Dashboards
- **Grafana**: Pre-built dashboards for system health
- **Sentry**: Error tracking and performance monitoring
- **Custom Alerts**: Discord/Slack notifications

## 🧪 Testing

```bash
# Run all tests
pnpm test

# Run unit tests
pnpm test:unit

# Run integration tests
pnpm test:integration

# Run e2e tests
pnpm test:e2e

# Generate coverage report
pnpm test:coverage
```

## 🚢 Deployment

### Production with Docker

```bash
# Build images
docker-compose -f docker-compose.prod.yml build

# Deploy
docker-compose -f docker-compose.prod.yml up -d

# View logs
docker-compose -f docker-compose.prod.yml logs -f
```

### Kubernetes (Optional)

```bash
# Deploy to K8s
kubectl apply -f infra/k8s/
```

### Environment Checklist
- [ ] Set `NODE_ENV=production`
- [ ] Configure SSL certificates
- [ ] Set up Redis cluster
- [ ] Configure database replicas
- [ ] Enable rate limiting
- [ ] Set up monitoring alerts
- [ ] Configure backup strategy

## 📈 Scaling

For 500M users:

### Horizontal Scaling
- Multiple backend instances behind load balancer
- Read replicas for database
- Redis cluster for distributed cache

### Optimization
- CDN for static assets
- Connection pooling for database
- Batch processing for cron jobs
- Edge caching for API responses

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing`)
5. Open Pull Request

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

---

<div align="center">

**Built with ❤️ for the Telegram Community**

</div>
