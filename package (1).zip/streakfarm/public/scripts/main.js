import { TelegramWebApp } from './telegram';
import { TonConnectUI } from './ton-connect';
import { API_ENDPOINTS, formatNumber, showToast, formatTimeLeft } from './utils';

interface User {
  id: string;
  telegramId: number;
  username?: string;
  firstName?: string;
  rawPoints: number;
  streakCurrent: number;
  streakBest: number;
  totalBoxesOpened: number;
  totalReferrals: number;
  multiplier: number;
  refCode: string;
  walletConnected: boolean;
}

interface Box {
  id: string;
  rarity: 'common' | 'rare' | 'legendary';
  basePoints: number;
}

interface Badge {
  id: string;
  name: string;
  icon_emoji: string;
  multiplier: number;
  rarity: string;
  progress?: {
    current: number;
    required: number;
    percentage: number;
  };
}

class StreakFarmApp {
  private user: User | null = null;
  private boxes: Box[] = [];
  private badges: { owned: Badge[]; available: Badge[] } = { owned: [], available: [] };
  private tonConnectUI: TonConnectUI | null = null;

  constructor() {
    this.init();
  }

  private async init(): Promise<void> {
    try {
      TelegramWebApp.ready();
      TelegramWebApp.expand();

      this.initTonConnect();
      this.bindEvents();
      await this.loadInitialData();

      document.getElementById('loading')!.classList.add('hidden');
      document.getElementById('main-content')!.classList.remove('hidden');
    } catch (error) {
      console.error('Init error:', error);
      showToast('Failed to initialize app', 'error');
    }
  }

  private initTonConnect(): void {
    if (typeof window !== 'undefined' && (window as any).tonConnectUI) {
      this.tonConnectUI = new TonConnectUI({
        manifestUrl: `${window.location.origin}/tonconnect-manifest.json`,
        buttonRootId: 'connect-wallet-btn'
      });

      this.tonConnectUI.connectionRestored.then(() => {
        if (this.tonConnectUI?.connected) {
          this.onWalletConnected(this.tonConnectUI.account?.address || '');
        }
      });
    }
  }

  private bindEvents(): void {
    document.querySelectorAll('.nav-tab').forEach(tab => {
      tab.addEventListener('click', (e) => this.switchTab((e.target as HTMLElement).closest('.nav-tab')!.dataset.tab!));
    });

    document.querySelectorAll('.period-btn').forEach(btn => {
      btn.addEventListener('click', (e) => this.loadLeaderboard((e.target as HTMLElement).dataset.period!));
    });

    document.getElementById('checkin-btn')?.addEventListener('click', () => this.performCheckin());
    document.getElementById('watch-ad-btn')?.addEventListener('click', () => this.watchAd());
    document.getElementById('copy-link-btn')?.addEventListener('click', () => this.copyReferralLink());
    document.getElementById('connect-wallet-btn')?.addEventListener('click', () => this.connectWallet());
    document.getElementById('close-box-modal')?.addEventListener('click', () => this.closeBoxModal());
  }

  private async loadInitialData(): Promise<void> {
    await Promise.all([
      this.loadUser(),
      this.loadBoxes(),
      this.loadBadges(),
      this.loadLeaderboard('all_time'),
      this.loadTasks(),
      this.loadReferralData()
    ]);

    this.updateUI();
  }

  private async loadUser(): Promise<void> {
    try {
      const initData = TelegramWebApp.initData;
      const response = await fetch(API_ENDPOINTS.users.upsert, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telegramId: TelegramWebApp.initDataUnsafe.user?.id,
          username: TelegramWebApp.initDataUnsafe.user?.username,
          firstName: TelegramWebApp.initDataUnsafe.user?.first_name,
          languageCode: TelegramWebApp.initDataUnsafe.user?.language_code,
          startParam: TelegramWebApp.initDataUnsafe.start_param
        })
      });

      if (response.ok) {
        const data = await response.json();
        this.user = data.user;
      }
    } catch (error) {
      console.error('Load user error:', error);
    }
  }

  private async loadBoxes(): Promise<void> {
    if (!this.user) return;

    try {
      const response = await fetch(API_ENDPOINTS.boxes.list(this.user.id));
      if (response.ok) {
        const data = await response.json();
        this.boxes = data.boxes;
        this.updateBoxSlots(data.stats);
      }
    } catch (error) {
      console.error('Load boxes error:', error);
    }
  }

  private async loadBadges(): Promise<void> {
    if (!this.user) return;

    try {
      const [ownedRes, availableRes] = await Promise.all([
        fetch(API_ENDPOINTS.badges.owned(this.user.id)),
        fetch(API_ENDPOINTS.badges.available(this.user.id))
      ]);

      if (ownedRes.ok) {
        const data = await ownedRes.json();
        this.badges.owned = data.badges.map((b: any) => b.badges);
      }

      if (availableRes.ok) {
        const data = await availableRes.json();
        this.badges.available = data.badges;
      }
    } catch (error) {
      console.error('Load badges error:', error);
    }
  }

  private async loadLeaderboard(period: string): Promise<void> {
    try {
      const response = await fetch(API_ENDPOINTS.leaderboard.list(period));
      if (response.ok) {
        const data = await response.json();
        this.renderLeaderboard(data.entries);
      }
    } catch (error) {
      console.error('Load leaderboard error:', error);
    }
  }

  private async loadTasks(): Promise<void> {
    if (!this.user) return;

    try {
      const response = await fetch(API_ENDPOINTS.tasks.list, {
        headers: { 'X-User-ID': this.user.id }
      });

      if (response.ok) {
        const data = await response.json();
        this.renderTasks(data.tasks);
      }
    } catch (error) {
      console.error('Load tasks error:', error);
    }
  }

  private async loadReferralData(): Promise<void> {
    if (!this.user) return;

    try {
      const response = await fetch(API_ENDPOINTS.referrals.link(this.user.id));
      if (response.ok) {
        const data = await response.json();
        document.getElementById('referral-link')!.value = data.link;
      }

      const statsRes = await fetch(API_ENDPOINTS.referrals.stats(this.user.id));
      if (statsRes.ok) {
        const stats = await statsRes.json();
        this.renderReferralStats(stats);
      }
    } catch (error) {
      console.error('Load referral data error:', error);
    }
  }

  private updateUI(): void {
    if (!this.user) return;

    document.getElementById('points-display')!.textContent = formatNumber(this.user.rawPoints);
    document.getElementById('streak-count')!.textContent = this.user.streakCurrent.toString();
    document.getElementById('multiplier-display')!.textContent = `${this.user.multiplier.toFixed(1)}×`;

    const walletStatus = document.getElementById('wallet-status');
    if (this.user.walletConnected) {
      walletStatus!.classList.add('connected');
      document.getElementById('wallet-short')!.textContent = 'Connected';
    }

    document.getElementById('badge-count')!.textContent = `${this.badges.owned.length} owned`;
    this.renderBadges();
  }

  private updateBoxSlots(stats: any): void {
    document.getElementById('boxes-available')!.textContent = stats.available.toString();
    document.getElementById('boxes-missed')!.textContent = stats.missed.toString();

    const slots = document.querySelectorAll('.box-slot');
    slots.forEach((slot, index) => {
      slot.classList.remove('available', 'empty');

      if (index < this.boxes.length) {
        slot.classList.add('available');
        slot.onclick = () => this.openBox(this.boxes[index]);
      } else {
        slot.classList.add('empty');
        slot.onclick = null;
      }
    });

    this.startBoxTimer();
  }

  private startBoxTimer(): void {
    const updateTimer = () => {
      const nextBox = new Date();
      nextBox.setHours(nextBox.getHours() + 1, 0, 0, 0);
      const diff = nextBox.getTime() - Date.now();
      document.getElementById('next-box-timer')!.textContent = formatTimeLeft(diff);
    };

    updateTimer();
    setInterval(updateTimer, 1000);
  }

  private async openBox(box: Box): Promise<void> {
    if (!this.user) return;

    const modal = document.getElementById('box-modal')!;
    const boxContainer = document.querySelector('.box-container')!;
    const reward = document.getElementById('box-reward')!;
    const newBadge = document.getElementById('new-badge')!;

    modal.classList.remove('hidden');
    boxContainer.classList.add('shaking');
    reward.classList.add('hidden');
    newBadge.classList.add('hidden');

    try {
      const response = await fetch(API_ENDPOINTS.boxes.open(this.user.id, box.id), {
        method: 'POST'
      });

      if (response.ok) {
        const data = await response.json();

        setTimeout(() => {
          boxContainer.classList.remove('shaking');
          boxContainer.classList.add('open');

          setTimeout(() => {
            reward.classList.remove('hidden');
            document.getElementById('reward-rarity')!.textContent = data.rarity.toUpperCase();
            document.getElementById('reward-rarity')!.className = `reward-rarity ${data.rarity}`;
            document.getElementById('reward-points')!.textContent = formatNumber(data.finalPoints);
            document.getElementById('reward-multiplier')!.textContent = data.multiplier.toFixed(1);

            if (data.newBadges?.length > 0) {
              newBadge.classList.remove('hidden');
              document.getElementById('new-badge-icon')!.textContent = data.newBadges[0].icon;
            }

            this.user!.rawPoints += data.finalPoints;
            document.getElementById('points-display')!.textContent = formatNumber(this.user!.rawPoints);
          }, 500);
        }, 1000);
      }
    } catch (error) {
      console.error('Open box error:', error);
      showToast('Failed to open box', 'error');
      this.closeBoxModal();
    }
  }

  private closeBoxModal(): void {
    document.getElementById('box-modal')!.classList.add('hidden');
    document.querySelector('.box-container')!.classList.remove('open');
    this.loadBoxes();
  }

  private switchTab(tab: string): void {
    document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`[data-tab="${tab}"]`)!.classList.add('active');

    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.getElementById(`${tab}-panel`)!.classList.add('active');
  }

  private renderLeaderboard(entries: any[]): void {
    const list = document.getElementById('leaderboard-list')!;
    list.innerHTML = entries.map((entry, index) => `
      <div class="leaderboard-item ${entry.userId === this.user?.id ? 'current-user' : ''}">
        <div class="rank-badge ${index < 3 ? `rank-${index + 1}` : 'rank-other'}">
          ${index + 1}
        </div>
        <div class="user-info">
          <div class="user-name">${entry.firstName || entry.username || 'User'}</div>
          <div class="user-stats">🔥 ${entry.streakDays} streak</div>
        </div>
        <div class="user-points">${formatNumber(entry.points)}</div>
      </div>
    `).join('');
  }

  private renderTasks(tasks: any[]): void {
    const list = document.getElementById('tasks-list')!;
    list.innerHTML = tasks.map(task => `
      <div class="task-item">
        <div class="task-icon">${this.getTaskIcon(task.task_type)}</div>
        <div class="task-info">
          <div class="task-title">${task.title}</div>
          <div class="task-points">+${formatNumber(task.points)} pts</div>
        </div>
        <button class="task-btn ${task.completed ? 'completed' : ''}"
                ${!task.canComplete ? 'disabled' : ''}
                onclick="app.${task.completed ? '' : 'completeTask'}('${task.id}')">
          ${task.completed ? '✓ Done' : 'Do Task'}
        </button>
      </div>
    `).join('');
  }

  private renderBadges(): void {
    const grid = document.getElementById('badges-grid')!;

    let html = '';

    this.badges.owned.forEach(badge => {
      html += `
        <div class="badge-card owned ${badge.rarity}">
          <span class="badge-icon">${badge.icon_emoji}</span>
          <span class="badge-name">${badge.name}</span>
          <span class="badge-multiplier">${badge.multiplier}×</span>
        </div>
      `;
    });

    this.badges.available.slice(0, 6).forEach(badge => {
      const progress = badge.progress || { percentage: 0 };
      html += `
        <div class="badge-card locked ${badge.rarity}">
          <span class="badge-icon">${badge.icon_emoji}</span>
          <span class="badge-name">${badge.name}</span>
          <span class="badge-multiplier">${badge.multiplier}×</span>
          ${progress.percentage > 0 ? `
            <div class="badge-progress">
              <div class="badge-progress-bar" style="width: ${progress.percentage}%"></div>
            </div>
          ` : ''}
        </div>
      `;
    });

    grid.innerHTML = html || '<p style="text-align: center; color: var(--text-secondary);">No badges yet. Keep playing!</p>';
  }

  private renderReferralStats(stats: any): void {
    const statsContainer = document.getElementById('referral-stats')!;
    statsContainer.innerHTML = `
      <div class="referral-stat">
        <div class="referral-stat-value">${stats.totalReferrals}</div>
        <div class="referral-stat-label">Total Referrals</div>
      </div>
      <div class="referral-stat">
        <div class="referral-stat-value">${formatNumber(stats.totalBonusEarned)}</div>
        <div class="referral-stat-label">Bonus Points</div>
      </div>
    `;
  }

  private async performCheckin(): Promise<void> {
    if (!this.user) return;

    try {
      const response = await fetch(API_ENDPOINTS.users.checkin(this.user.id), {
        method: 'POST'
      });

      if (response.ok) {
        const data = await response.json();
        this.user.rawPoints += data.bonusPoints;
        this.user.streakCurrent = data.newStreak;

        document.getElementById('points-display')!.textContent = formatNumber(this.user.rawPoints);
        document.getElementById('streak-count')!.textContent = data.newStreak.toString();

        showToast(`Check-in! +${data.bonusPoints} pts${data.streakReset ? ' (Streak reset!)' : ''}`, 'success');
      }
    } catch (error) {
      console.error('Checkin error:', error);
      showToast('Check-in failed', 'error');
    }
  }

  private async watchAd(): Promise<void> {
    showToast('Loading ad...', 'warning');

    if (TelegramWebApp.HapticFeedback) {
      TelegramWebApp.HapticFeedback.notificationOccurred('success');
    }

    setTimeout(async () => {
      if (!this.user) return;

      const bonusPoints = 500;
      this.user.rawPoints += bonusPoints;
      document.getElementById('points-display')!.textContent = formatNumber(this.user.rawPoints);

      showToast(`Ad watched! +${bonusPoints} pts`, 'success');
    }, 3000);
  }

  private async completeTask(taskId: string): Promise<void> {
    if (!this.user) return;

    try {
      const response = await fetch(API_ENDPOINTS.tasks.complete(taskId), {
        method: 'POST',
        headers: { 'X-User-ID': this.user.id }
      });

      if (response.ok) {
        const data = await response.json();
        this.user.rawPoints += data.pointsAwarded;
        document.getElementById('points-display')!.textContent = formatNumber(this.user.rawPoints);

        showToast(`Task completed! +${data.pointsAwarded} pts`, 'success');
        this.loadTasks();
      } else {
        showToast('Task completion failed', 'error');
      }
    } catch (error) {
      console.error('Complete task error:', error);
      showToast('Task completion failed', 'error');
    }
  }

  private async connectWallet(): Promise<void> {
    if (!this.tonConnectUI) {
      showToast('Wallet connection not available', 'error');
      return;
    }

    try {
      await this.tonConnectUI.connectWallet();
    } catch (error) {
      console.error('Connect wallet error:', error);
      showToast('Failed to connect wallet', 'error');
    }
  }

  private async onWalletConnected(address: string): Promise<void> {
    if (!this.user) return;

    try {
      const response = await fetch(API_ENDPOINTS.wallet.connect, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-ID': this.user.id
        },
        body: JSON.stringify({ walletAddress: address, walletType: 'ton-connect' })
      });

      if (response.ok) {
        const data = await response.json();
        this.user.walletConnected = true;

        document.getElementById('wallet-status')!.classList.add('connected');
        document.getElementById('wallet-short')!.textContent = 'Connected';

        const btn = document.getElementById('connect-wallet-btn') as HTMLButtonElement;
        btn.innerHTML = '<span>👛</span> Wallet Connected';
        btn.classList.add('connected');

        showToast(`Wallet connected! +${data.bonus} pts`, 'success');
      }
    } catch (error) {
      console.error('Wallet connection error:', error);
    }
  }

  private copyReferralLink(): Promise<void> {
    const input = document.getElementById('referral-link') as HTMLInputElement;
    input.select();
    document.execCommand('copy');

    if (navigator.clipboard) {
      navigator.clipboard.writeText(input.value);
    }

    showToast('Link copied!', 'success');
  }

  private getTaskIcon(type: string): string {
    const icons: Record<string, string> = {
      telegram_join: '📢',
      twitter_follow: '🐦',
      youtube_subscribe: '📺',
      discord_join: '💬',
      daily_login: '📅',
      invite: '👥',
      wallet_task: '👛'
    };
    return icons[type] || '✅';
  }
}

const app = new StreakFarmApp();
(window as any).app = app;
