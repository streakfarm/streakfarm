export interface TonConnectUIOptions {
  manifestUrl: string;
  buttonRootId: string;
  actionsConfiguration?: {
    returnUrl?: string;
    twaReturnUrl?: string;
  };
}

export interface TonAccount {
  address: string;
  chain: number;
  publicKey?: string;
}

export interface TonConnection {
  account: TonAccount;
  device: {
    appName: string;
    platform: string;
  };
}

export interface TonConnectUI {
  connectionRestored: Promise<boolean>;
  connected: boolean;
  account: TonAccount | null;

  connectWallet(): Promise<TonConnection>;
  disconnect(): Promise<void>;
  sendTransaction(params: {
    to: string;
    value: string;
    data?: string;
  }): Promise<{ boc: string }>;
  on<R = any>(event: string, listener: (data: R) => void): void;
  off(event: string, listener: (data: any) => void): void;
}

class TonConnectUIImplementation implements TonConnectUI {
  private static instances: Map<string, TonConnectUIImplementation> = new Map();

  public connectionRestored: Promise<boolean>;
  public connected: boolean = false;
  public account: TonAccount | null = null;

  private manifestUrl: string;
  private buttonRootId: string;
  private listeners: Map<string, Set<Function>> = new Map();
  private restorePromise: Promise<boolean>;
  private restoreResolve: (value: boolean) => void = () => {};

  constructor(options: TonConnectUIOptions) {
    this.manifestUrl = options.manifestUrl;
    this.buttonRootId = options.buttonRootId;

    this.connectionRestored = new Promise((resolve) => {
      this.restoreResolve = resolve;
    });

    this.init();
  }

  private async init(): Promise<void> {
    if (typeof window === 'undefined') return;

    try {
      const script = document.createElement('script');
      script.src = 'https://tonconnect.github.io/tonconnect/tonconnect-ui.js';
      script.async = true;

      script.onload = () => {
        if ((window as any).TONConnectUI) {
          const instance = (window as any).TONConnectUI.createInstance({
            manifestUrl: this.manifestUrl,
            buttonRootId: this.buttonRootId
          });

          TonConnectUIImplementation.instances.set(this.manifestUrl, instance);

          instance.on('connected', (connection: TonConnection) => {
            this.connected = true;
            this.account = connection.account;
            this.emit('connected', connection);
          });

          instance.on('disconnected', () => {
            this.connected = false;
            this.account = null;
            this.emit('disconnected');
          });

          instance.connectionRestored.then((restored: boolean) => {
            this.restoreResolve(restored);
          });
        }
      };

      document.head.appendChild(script);
    } catch (error) {
      console.error('Failed to load TON Connect UI:', error);
      this.restoreResolve(false);
    }
  }

  async connectWallet(): Promise<TonConnection> {
    const instance = TonConnectUIImplementation.instances.get(this.manifestUrl);
    if (!instance) {
      throw new Error('TON Connect UI not initialized');
    }

    const connection = await instance.connectWallet();
    this.connected = true;
    this.account = connection.account;

    return connection;
  }

  async disconnect(): Promise<void> {
    const instance = TonConnectUIImplementation.instances.get(this.manifestUrl);
    if (!instance) return;

    await instance.disconnect();
    this.connected = false;
    this.account = null;
  }

  async sendTransaction(params: { to: string; value: string; data?: string }): Promise<{ boc: string }> {
    const instance = TonConnectUIImplementation.instances.get(this.manifestUrl);
    if (!instance) {
      throw new Error('TON Connect UI not initialized');
    }

    return instance.sendTransaction(params);
  }

  on<R = any>(event: string, listener: (data: R) => void): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(listener);

    const instance = TonConnectUIImplementation.instances.get(this.manifestUrl);
    if (instance) {
      instance.on(event, listener);
    }
  }

  off(event: string, listener: (data: any) => void): void {
    this.listeners.get(event)?.delete(listener);

    const instance = TonConnectUIImplementation.instances.get(this.manifestUrl);
    if (instance) {
      instance.off(event, listener);
    }
  }

  private emit<R>(event: string, data?: R): void {
    this.listeners.get(event)?.forEach(listener => {
      try {
        listener(data);
      } catch (error) {
        console.error(`Error in listener for event ${event}:`, error);
      }
    });
  }
}

export function createTonConnectUI(options: TonConnectUIOptions): TonConnectUI {
  return new TonConnectUIImplementation(options);
}

export function isTonConnectSupported(): boolean {
  return typeof window !== 'undefined' &&
    typeof (window as any).TONConnectUI !== 'undefined';
}

export async function sendTonTransaction(
  toAddress: string,
  amount: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const instance = Object.values(TonConnectUIImplementation.instances.values())[0] as TonConnectUI | undefined;

    if (!instance || !instance.connected) {
      return { success: false, error: 'Wallet not connected' };
    }

    await instance.sendTransaction({
      to: toAddress,
      value: amount
    });

    return { success: true };
  } catch (error) {
    return { success: false, error: String(error) };
  }
}
