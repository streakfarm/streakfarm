export const API_ENDPOINTS = {
  users: {
    upsert: '/api/users/upsert',
    get: (id: string) => `/api/users/${id}`,
    checkin: (id: string) => `/api/users/${id}/checkin`,
    stats: (id: string) => `/api/users/${id}/stats`
  },
  boxes: {
    list: (userId: string) => `/api/boxes/${userId}`,
    open: (userId: string, boxId: string) => `/api/boxes/${userId}/open/${boxId}`,
    history: (userId: string) => `/api/boxes/${userId}/history`
  },
  badges: {
    list: '/api/badges',
    owned: (userId: string) => `/api/badges/owned/${userId}`,
    available: (userId: string) => `/api/badges/available/${userId}`,
    check: (userId: string) => `/api/badges/check/${userId}`
  },
  wallet: {
    connect: '/api/wallet/connect',
    disconnect: '/api/wallet/disconnect',
    info: (userId: string) => `/api/wallet/info/${userId}`
  },
  leaderboard: {
    list: (period: string) => `/api/leaderboard?period=${period}`,
    user: (userId: string, period: string) => `/api/leaderboard/user/${userId}?period=${period}`,
    around: (userId: string, period: string) => `/api/leaderboard/around/${userId}?period=${period}`
  },
  tasks: {
    list: '/api/tasks',
    complete: (taskId: string) => `/api/tasks/${taskId}/complete`,
    verify: (taskId: string) => `/api/tasks/${taskId}/verify`
  },
  referrals: {
    link: (userId: string) => `/api/referrals/link/${userId}`,
    stats: (userId: string) => `/api/referrals/stats/${userId}`,
    validate: '/api/referrals/validate',
    claim: '/api/referrals/claim'
  },
  points: {
    balance: (userId: string) => `/api/points/balance/${userId}`,
    history: (userId: string) => `/api/points/history/${userId}`
  }
};

export function formatNumber(num: number): string {
  if (num >= 1_000_000_000) {
    return (num / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'B';
  }
  if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
  }
  if (num >= 1_000) {
    return (num / 1_000).toFixed(1).replace(/\.0$/, '') + 'K';
  }
  return num.toString();
}

export function formatTimeLeft(ms: number): string {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

export function showToast(message: string, type: 'success' | 'error' | 'warning' = 'success'): void {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'slideIn 0.3s ease reverse';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout>;

  return function (...args: Parameters<T>) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;

  return function (...args: Parameters<T>) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

export function getRarityColor(rarity: string): string {
  const colors: Record<string, string> = {
    common: '#6b7280',
    rare: '#3b82f6',
    epic: '#a855f7',
    legendary: '#fbbf24',
    mythic: '#ff6b9d'
  };
  return colors[rarity] || colors.common;
}

export function getRarityEmoji(rarity: string): string {
  const emojis: Record<string, string> = {
    common: '⚪',
    rare: '🔵',
    epic: '🟣',
    legendary: '🟡',
    mythic: '🌟'
  };
  return emojis[rarity] || emojis.common;
}

export function generateBoxPoints(rarity: 'common' | 'rare' | 'legendary'): number {
  const ranges: Record<string, [number, number]> = {
    common: [50, 1000],
    rare: [5000, 10000],
    legendary: [10000, 50000]
  };

  const [min, max] = ranges[rarity];
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function calculateMultiplier(badges: any[]): number {
  return badges.reduce((total, badge) => total + (badge.multiplier - 1), 1);
}

export function isToday(dateString: string): boolean {
  const date = new Date(dateString);
  const today = new Date();
  return (
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
  );
}

export function getRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diff = now.getTime() - date.getTime();

  const minutes = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  return formatDate(dateString);
}

export function copyToClipboard(text: string): Promise<void> {
  if (navigator.clipboard) {
    return navigator.clipboard.writeText(text);
  }

  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.style.position = 'fixed';
  textarea.style.opacity = '0';
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
  return Promise.resolve();
}
