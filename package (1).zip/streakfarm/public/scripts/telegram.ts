interface TelegramWebAppType {
  ready: () => void;
  expand: () => void;
  close: () => void;
  initData: string;
  initDataUnsafe: {
    query_id?: string;
    user?: {
      id: number;
      is_bot?: boolean;
      first_name: string;
      last_name?: string;
      username?: string;
      language_code?: string;
      is_premium?: boolean;
      added_to_attachment_menu?: boolean;
    };
    auth_date: number;
    hash: string;
    start_param?: string;
  };
  version: string;
  platform: string;
  colorScheme: string;
  themeParams: {
    bg_color?: string;
    button_color?: string;
    button_text_color?: string;
    secondary_bg_color?: string;
    text_color?: string;
    hint_color?: string;
    link_color?: string;
    header_bg_color?: string;
    accent_text_color?: string;
  };
  MainButton: {
    text: string;
    color: string;
    textColor: string;
    visible: boolean;
    setText: (text: string) => void;
    show: () => void;
    hide: () => void;
    enable: () => void;
    disable: () => void;
    onClick: (callback: () => void) => void;
    offClick: (callback: () => void) => void;
  };
  BackButton: {
    visible: boolean;
    show: () => void;
    hide: () => void;
    onClick: (callback: () => void) => void;
    offClick: (callback: () => void) => void;
  };
  HapticFeedback: {
    impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
    notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
    selectionChanged: () => void;
  };
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  bindEvents: (events: Record<string, Function>) => void;
  sendData: (data: any) => void;
  openLink: (url: string) => void;
  openTelegramLink: (url: string) => void;
  openInvoice: (url: string, callback?: (status: string) => void) => void;
  showPopup: (params: { title: string; message: string; buttons?: Array<{ id: string; type?: string; text?: string }> }, callback?: (id: string) => void) => void;
  showAlert: (message: string, callback?: () => void) => void;
  showConfirm: (message: string, callback?: (ok: boolean) => void) => void;
  prompt: (params: { message: string; default_value?: string }, callback?: (value: string) => void) => void;
}

declare global {
  interface Window {
    TelegramWebApp?: TelegramWebAppType;
  }
}

export const TelegramWebApp: TelegramWebAppType = (() => {
  if (typeof window !== 'undefined' && window.TelegramWebApp) {
    return window.TelegramWebApp;
  }

  const mockWebApp: Partial<TelegramWebAppType> = {
    ready: () => console.log('Telegram WebApp ready'),
    expand: () => console.log('Telegram WebApp expanded'),
    close: () => console.log('Telegram WebApp close'),
    initData: '',
    initDataUnsafe: {},
    version: '6.0',
    platform: 'unknown',
    colorScheme: 'dark',
    themeParams: {},
    MainButton: {
      text: '',
      color: '',
      textColor: '',
      visible: false,
      setText: () => {},
      show: () => {},
      hide: () => {},
      enable: () => {},
      disable: () => {},
      onClick: () => {},
      offClick: () => {}
    },
    BackButton: {
      visible: false,
      show: () => {},
      hide: () => {},
      onClick: () => {},
      offClick: () => {}
    },
    HapticFeedback: {
      impactOccurred: () => {},
      notificationOccurred: () => {},
      selectionChanged: () => {}
    },
    isExpanded: true,
    viewportHeight: window.innerHeight,
    viewportStableHeight: window.innerHeight,
    bindEvents: () => {},
    sendData: () => {},
    openLink: () => {},
    openTelegramLink: () => {},
    openInvoice: () => {},
    showPopup: () => {},
    showAlert: () => {},
    showConfirm: () => {},
    prompt: () => {}
  };

  return mockWebApp as TelegramWebAppType;
})();

export function isTelegramWebApp(): boolean {
  return typeof window !== 'undefined' && !!window.TelegramWebApp;
}

export function getTelegramUserId(): number | null {
  return TelegramWebApp.initDataUnsafe.user?.id || null;
}

export function getStartParam(): string | null {
  return TelegramWebApp.initDataUnsafe.start_param || null;
}

export function hapticImpact(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft' = 'light'): void {
  TelegramWebApp.HapticFeedback?.impactOccurred?.(style);
}

export function hapticNotification(type: 'error' | 'success' | 'warning' = 'success'): void {
  TelegramWebApp.HapticFeedback?.notificationOccurred?.(type);
}
