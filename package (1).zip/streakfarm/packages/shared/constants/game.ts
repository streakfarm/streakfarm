// =============================================================================
// GAME CONSTANTS
# =============================================================================

// Box Configuration
export const BOX_CONFIG = {
  MAX_PER_DAY: 24,
  EXPIRY_HOURS: 3,
  GENERATION_ENABLED: true,
  RARITY: {
    COMMON: {
      chance: 0.949,
      min: 50,
      max: 1000,
    },
    RARE: {
      chance: 0.05,
      min: 5000,
      max: 10000,
    },
    LEGENDARY: {
      chance: 0.001,
      min: 10000,
      max: 50000,
    },
  },
} as const;

// Streak Configuration
export const STREAK_CONFIG = {
  DECAY_HOURS: 25,
  BONUS_CHECKIN: 100,
  BONUS_WEEKLY: 500,
  BONUS_MONTHLY: 2000,
  BONUS_100DAY: 5000,
  MULTIPLIERS: [
    { days: 1, multiplier: 1.0 },
    { days: 3, multiplier: 1.2 },
    { days: 7, multiplier: 1.5 },
    { days: 14, multiplier: 2.0 },
    { days: 30, multiplier: 2.5 },
    { days: 60, multiplier: 3.0 },
    { days: 90, multiplier: 4.0 },
    { days: 180, multiplier: 5.0 },
    { days: 365, multiplier: 10.0 },
    { days: 730, multiplier: 15.0 },
  ],
} as const;

// Referral Configuration
export const REFERRAL_CONFIG = {
  BONUS_REFERER: 1000,
  BONUS_REFERRED: 500,
  MAX_TREE_DEPTH: 5,
} as const;

// Wallet Configuration
export const WALLET_CONFIG = {
  BONUS_CONNECT: 5000,
  WHALE_THRESHOLD: 10,
  MEGA_WHALE_THRESHOLD: 100,
} as const;

// Badge IDs
export const BADGE_IDS = {
  STREAK_7: 'streak_7',
  STREAK_14: 'streak_14',
  STREAK_30: 'streak_30',
  STREAK_60: 'streak_60',
  STREAK_90: 'streak_90',
  STREAK_180: 'streak_180',
  STREAK_365: 'streak_365',
  STREAK_730: 'streak_730',
  FOUNDING_MEMBER: 'founding_member',
  EARLY_ADOPTER: 'early_adopter',
  LAUNCH_WEEK: 'launch_week',
  MILLIONAIRE: 'millionaire',
  MULTI_MILLIONAIRE: 'multi_millionaire',
  TOP_100: 'top_100',
  TOP_10: 'top_10',
  INFLUENCER: 'influencer',
  MEGA_INFLUENCER: 'mega_influencer',
  BOX_MASTER: 'box_master',
  LIGHTNING: 'lightning',
  ANTI_BOT_GUARDIAN: 'anti_bot_guardian',
  WALLET_CONNECTED: 'wallet_connected',
  WHALE: 'whale',
  MEGA_WHALE: 'mega_whale',
  NFT_HOLDER: 'nft_holder',
  HOLIDAY_SPECIAL: 'holiday_special',
} as const;

// Error Codes
export const ERROR_CODES = {
  // Auth errors (AUTH_*)
  AUTH_INVALID_TOKEN: 'AUTH_INVALID_TOKEN',
  AUTH_TOKEN_EXPIRED: 'AUTH_TOKEN_EXPIRED',
  AUTH_UNAUTHORIZED: 'AUTH_UNAUTHORIZED',
  AUTH_FORBIDDEN: 'AUTH_FORBIDDEN',

  // User errors (USER_*)
  USER_NOT_FOUND: 'USER_NOT_FOUND',
  USER_ALREADY_EXISTS: 'USER_ALREADY_EXISTS',
  USER_BANNED: 'USER_BANNED',
  USER_FLAGGED: 'USER_FLAGGED',

  // Box errors (BOX_*)
  BOX_NOT_FOUND: 'BOX_NOT_FOUND',
  BOX_ALREADY_OPENED: 'BOX_ALREADY_OPENED',
  BOX_EXPIRED: 'BOX_EXPIRED',
  BOX_NOT_AVAILABLE: 'BOX_NOT_AVAILABLE',

  // Badge errors (BADGE_*)
  BADGE_NOT_FOUND: 'BADGE_NOT_FOUND',
  BADGE_ALREADY_OWNED: 'BADGE_ALREADY_OWNED',
  BADGE_NOT_ELIGIBLE: 'BADGE_NOT_ELIGIBLE',
  BADGE_MAX_SUPPLY: 'BADGE_MAX_SUPPLY',

  // Wallet errors (WALLET_*)
  WALLET_NOT_CONNECTED: 'WALLET_NOT_CONNECTED',
  WALLET_ALREADY_CONNECTED: 'WALLET_ALREADY_CONNECTED',
  WALLET_INVALID_ADDRESS: 'WALLET_INVALID_ADDRESS',
  WALLET_CONNECTION_FAILED: 'WALLET_CONNECTION_FAILED',

  // Task errors (TASK_*)
  TASK_NOT_FOUND: 'TASK_NOT_FOUND',
  TASK_ALREADY_COMPLETED: 'TASK_ALREADY_COMPLETED',
  TASK_ON_COOLDOWN: 'TASK_ON_COOLDOWN',
  TASK_REQUIREMENTS_NOT_MET: 'TASK_REQUIREMENTS_NOT_MET',

  // Referral errors (REFERRAL_*)
  REFERRAL_NOT_FOUND: 'REFERRAL_NOT_FOUND',
  REFERRAL_SELF: 'REFERRAL_SELF',
  REFERRAL_ALREADY_EXISTS: 'REFERRAL_ALREADY_EXISTS',
  REFERRAL_INVALID_CODE: 'REFERRAL_INVALID_CODE',

  // Points errors (POINTS_*)
  POINTS_INSUFFICIENT: 'POINTS_INSUFFICIENT',
  POINTS_INVALID_AMOUNT: 'POINTS_INVALID_AMOUNT',

  // Rate limit errors (RATE_*)
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',

  // System errors (SYS_*)
  SYS_INTERNAL_ERROR: 'SYS_INTERNAL_ERROR',
  SYS_DATABASE_ERROR: 'SYS_DATABASE_ERROR',
  SYS_CACHE_ERROR: 'SYS_CACHE_ERROR',
  SYS_EXTERNAL_SERVICE_ERROR: 'SYS_EXTERNAL_SERVICE_ERROR',
} as const;

// Supported Languages
export const SUPPORTED_LANGUAGES = [
  'en',
  'ru',
  'zh',
  'es',
  'de',
  'fr',
  'pt',
  'ar',
  'hi',
  'ja',
  'ko',
] as const;

export type SupportedLanguage = typeof SUPPORTED_LANGUAGES[number];

// Task Categories
export const TASK_CATEGORIES = {
  SOCIAL: 'social',
  BLOCKCHAIN: 'blockchain',
  DAILY: 'daily',
  SPECIAL: 'special',
} as const;

// Leaderboard Periods
export const LEADERBOARD_PERIODS = ['daily', 'weekly', 'monthly', 'all_time'] as const;

// Cache Keys
export const CACHE_KEYS = {
  USER: (userId: string) => `user:${userId}`,
  USER_BADGES: (userId: string) => `user_badges:${userId}`,
  USER_MULTIPLIER: (userId: string) => `user_multiplier:${userId}`,
  USER_RANK: (userId: string) => `user_rank:${userId}`,
  USER_BOXES: (userId: string) => `user_boxes:${userId}`,
  LEADERBOARD: (period: string) => `leaderboard:${period}`,
  LEADERBOARD_USER: (userId: string, period: string) => `leaderboard_user:${userId}:${period}`,
  BOX_STATS: (userId: string) => `box_stats:${userId}`,
  WALLET_BALANCE: (address: string) => `wallet_balance:${address}`,
  WALLET_NFTS: (address: string) => `wallet_nfts:${address}`,
  TASK_LIST: 'tasks:available',
  CONFIG: (key: string) => `config:${key}`,
} as const;

// TTL Constants (seconds)
export const TTL = {
  USER: 300, // 5 minutes
  LEADERBOARD: 60, // 1 minute
  BADGE: 3600, // 1 hour
  WALLET: 3600, // 1 hour
  TASK: 1800, // 30 minutes
  BOX_STATS: 60, // 1 minute
  CONFIG: 600, // 10 minutes
} as const;

// Event Types
export const EVENT_TYPES = {
  // User events
  USER_CREATED: 'user.created',
  USER_UPDATED: 'user.updated',
  USER_BANNED: 'user.banned',
  USER_FLAGGED: 'user.flagged',

  // Box events
  BOX_GENERATED: 'box.generated',
  BOX_OPENED: 'box.opened',
  BOX_EXPIRED: 'box.expired',

  // Badge events
  BADGE_EARNED: 'badge.earned',
  BADGE_REVOKED: 'badge.revoked',

  // Points events
  POINTS_AWARDED: 'points.awarded',
  POINTS_DEDUCTED: 'points.deducted',

  // Wallet events
  WALLET_CONNECTED: 'wallet.connected',
  WALLET_DISCONNECTED: 'wallet.disconnected',

  // Referral events
  REFERRAL_CREATED: 'referral.created',
  REFERRAL_BONUS_AWARDED: 'referral.bonus_awarded',

  // Task events
  TASK_COMPLETED: 'task.completed',

  // System events
  MIGRATION_STARTED: 'migration.started',
  MIGRATION_COMPLETED: 'migration.completed',
  SERVER_STARTED: 'server.started',
  SERVER_STOPPED: 'server.stopped',
} as const;
