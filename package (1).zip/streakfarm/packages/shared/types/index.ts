// =============================================================================
// USER TYPES
// =============================================================================

export interface User {
  id: string;
  telegram_id: number;
  username?: string;
  first_name: string;
  last_name?: string;
  language_code: string;
  is_premium: boolean;
  raw_points: number;
  streak_current: number;
  streak_best: number;
  last_checkin?: string;
  total_boxes_opened: number;
  total_tasks_completed: number;
  total_referrals: number;
  bots_reported: number;
  wallet_address?: string;
  wallet_type?: string;
  wallet_connected_at?: string;
  multiplier_permanent: number;
  joined_at: string;
  ref_code: string;
  referred_by?: string;
  fingerprint?: string;
  ip_address?: string;
  user_agent?: string;
  is_flagged: boolean;
  flag_reason?: string;
  is_banned: boolean;
  ban_reason?: string;
  is_bot: boolean;
  report_count: number;
  created_at: string;
  updated_at: string;
  last_active_at: string;
}

export interface UserCreateDTO {
  telegramId: number;
  username?: string;
  firstName: string;
  lastName?: string;
  languageCode?: string;
  isPremium?: boolean;
  startParam?: string;
  fingerprint?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface UserResponseDTO {
  id: string;
  telegramId: number;
  username?: string;
  firstName: string;
  rawPoints: number;
  streakCurrent: number;
  streakBest: number;
  totalBoxesOpened: number;
  totalTasksCompleted: number;
  totalReferrals: number;
  multiplier: number;
  refCode: string;
  walletConnected: boolean;
  badgesCount: number;
  rank?: number;
  createdAt: string;
}

export interface UserStatsDTO {
  totalPoints: number;
  streak: number;
  streakBest: number;
  boxesOpened: number;
  tasksCompleted: number;
  referrals: number;
  badgesCount: number;
  rank: number;
  multiplier: number;
  pointsToNextRank: number;
}

// =============================================================================
// BOX TYPES
// =============================================================================

export type BoxRarity = 'common' | 'rare' | 'legendary';

export interface Box {
  id: string;
  user_id: string;
  generated_at: string;
  expires_at: string;
  opened_at?: string;
  base_points: number;
  multiplier_applied: number;
  final_points?: number;
  rarity: BoxRarity;
  is_expired: boolean;
  created_at: string;
}

export interface BoxGenerationResult {
  userId: string;
  boxId: string;
  rarity: BoxRarity;
  basePoints: number;
}

export interface BoxOpenResult {
  success: boolean;
  box?: Box;
  finalPoints: number;
  rarity: BoxRarity;
  multiplier: number;
  basePoints: number;
  newBadges: BadgeResponseDTO[];
  error?: string;
}

export interface BoxStatsDTO {
  available: number;
  openedToday: number;
  missed: number;
  totalOpened: number;
  nextBoxIn: number; // seconds
}

// =============================================================================
// BADGE TYPES
// =============================================================================

export type BadgeRarity = 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';
export type BadgeCategory = 'streak' | 'achievement' | 'wallet' | 'special';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon_emoji: string;
  image_url?: string;
  badge_category: BadgeCategory;
  multiplier: number;
  rarity: BadgeRarity;
  requirements: BadgeRequirements;
  max_supply?: number;
  current_supply: number;
  is_active: boolean;
  available_from?: string;
  available_until?: string;
  can_convert_to_nft: boolean;
  created_at: string;
}

export interface BadgeRequirements {
  streak_days?: number;
  total_points?: number;
  user_number_max?: number;
  joined_within_days?: number;
  leaderboard_rank?: number;
  referrals?: number;
  boxes_opened?: number;
  boxes_per_hour?: number;
  bots_reported?: number;
  wallet_connected?: boolean;
  ton_balance?: number;
  has_nfts?: boolean;
  seasonal?: boolean;
}

export interface UserBadge {
  id: string;
  user_id: string;
  badge_id: string;
  earned_at: string;
  expires_at?: string;
  is_active: boolean;
  converted_to_nft: boolean;
  nft_address?: string;
  converted_at?: string;
  badge: Badge;
}

export interface BadgeResponseDTO {
  id: string;
  name: string;
  icon: string;
  multiplier: number;
  rarity: BadgeRarity;
  category: BadgeCategory;
  earnedAt?: string;
  progress?: BadgeProgressDTO;
}

export interface BadgeProgressDTO {
  current: number;
  required: number;
  percentage: number;
}

export interface BadgeStatsDTO {
  totalBadges: number;
  totalUsersWithBadges: number;
  mostPopularBadge: Badge | null;
  averageBadgesPerUser: number;
}

// =============================================================================
// POINTS TYPES
# =============================================================================

export interface PointsTransaction {
  id: string;
  user_id: string;
  points: number;
  source: string;
  source_id?: string;
  balance_after: number;
  created_at: string;
}

export interface PointsHistoryDTO {
  transactions: PointsTransaction[];
  total: number;
  page: number;
  limit: number;
}

export interface PointsStatsDTO {
  totalEarned: number;
  totalSpent: number;
  avgPerDay: number;
  bestDay: {
    date: string;
    points: number;
  };
  sourcesBreakdown: Record<string, number>;
}

// =============================================================================
// WALLET TYPES
# =============================================================================

export interface WalletInfo {
  connected: boolean;
  walletAddress?: string;
  walletType?: string;
  connectedAt?: string;
  balance?: number;
  nftCount?: number;
}

export interface WalletConnectionResult {
  success: boolean;
  walletAddress?: string;
  walletType?: string;
  bonus?: number;
  newBadges?: BadgeResponseDTO[];
  error?: string;
}

export interface WalletTaskDTO {
  id: string;
  title: string;
  description: string;
  points: number;
  completed: boolean;
  requirement: {
    type: 'balance' | 'nft';
    amount?: number;
    count?: number;
  };
}

// =============================================================================
// TASK TYPES
# =============================================================================

export type TaskType =
  | 'telegram_join'
  | 'twitter_follow'
  | 'youtube_subscribe'
  | 'discord_join'
  | 'external_link'
  | 'wallet_task'
  | 'daily_login'
  | 'invite';

export interface Task {
  id: string;
  title: string;
  description: string;
  points: number;
  task_type: TaskType;
  external_url?: string;
  telegram_channel_id?: string;
  twitter_username?: string;
  youtube_channel_id?: string;
  discord_invite_code?: string;
  requires_wallet: boolean;
  is_repeatable: boolean;
  repeat_cooldown_hours?: number;
  is_active: boolean;
  max_completions?: number;
  current_completions: number;
  created_at: string;
}

export interface TaskCompletion {
  id: string;
  user_id: string;
  task_id: string;
  completed_at: string;
  verification_data?: Record<string, any>;
  is_verified: boolean;
  points_awarded: number;
}

export interface TaskWithProgress extends Task {
  completed: boolean;
  completedAt?: string;
  canComplete: boolean;
}

export interface TaskCompletionResult {
  success: boolean;
  pointsAwarded: number;
  newBadges: BadgeResponseDTO[];
  error?: string;
}

// =============================================================================
// REFERRAL TYPES
# =============================================================================

export interface Referral {
  id: string;
  referrer_id: string;
  referred_id: string;
  bonus_awarded: boolean;
  bonus_points: number;
  created_at: string;
}

export interface ReferralLinkDTO {
  link: string;
  code: string;
}

export interface ReferralStatsDTO {
  totalReferrals: number;
  activeReferrals: number;
  pendingReferrals: number;
  totalBonusEarned: number;
  topReferrers: Array<{
    userId: string;
    username?: string;
    firstName?: string;
    referrals: number;
  }>;
}

export interface ReferralValidationResult {
  valid: boolean;
  referrerId?: string;
  error?: string;
}

export interface ReferralClaimResult {
  success: boolean;
  bonusAwarded: boolean;
  referrerBonus: number;
  referredBonus: number;
  error?: string;
}

// =============================================================================
// LEADERBOARD TYPES
# =============================================================================

export type LeaderboardPeriod = 'daily' | 'weekly' | 'monthly' | 'all_time';

export interface LeaderboardEntry {
  userId: string;
  username?: string;
  firstName?: string;
  points: number;
  rank: number;
  streakDays: number;
  boxesOpened: number;
  badgesCount: number;
}

export interface LeaderboardDTO {
  period: LeaderboardPeriod;
  entries: LeaderboardEntry[];
  totalParticipants: number;
  userRank?: number;
}

export interface LeaderboardAroundUserDTO {
  userEntry: LeaderboardEntry;
  nearbyEntries: LeaderboardEntry[];
}

export interface LeaderboardStatsDTO {
  totalParticipants: number;
  topPointGain: number;
  averagePoints: number;
  topStreak: number;
  topBoxesOpened: number;
}

// =============================================================================
// MULTIPLIER TYPES
# =============================================================================

export interface MultiplierBreakdown {
  baseMultiplier: number;
  badgeMultiplier: number;
  streakMultiplier: number;
  totalMultiplier: number;
  badgeDetails: Array<{
    name: string;
    multiplier: number;
    icon: string;
  }>;
  streakTier: {
    days: number;
    multiplier: number;
    nextTierDays: number;
    nextTierMultiplier: number;
  };
}

export interface StreakMultiplierTier {
  days: number;
  multiplier: number;
}

// =============================================================================
// ANTI-FRAUD TYPES
# =============================================================================

export type FlagType =
  | 'suspicious_activity'
  | 'bot_detected'
  | 'multiple_accounts'
  | 'cheating'
  | 'report_received';

export type Severity = 'low' | 'medium' | 'high' | 'critical';

export interface UserFlag {
  id: string;
  user_id: string;
  flag_type: FlagType;
  severity: Severity;
  description: string;
  metadata?: Record<string, any>;
  resolved: boolean;
  resolved_by?: string;
  resolved_at?: string;
  created_at: string;
}

export interface BehaviorAnalysisResult {
  isSuspicious: boolean;
  riskScore: number;
  reasons: string[];
  recommendedAction: 'allow' | 'flag' | 'block';
}

export interface FraudStatsDTO {
  totalFlagged: number;
  totalBanned: number;
  autoBanned: number;
  topReasons: Array<{
    reason: string;
    count: number;
  }>;
  recentFlags: Array<{
    userId: string;
    type: string;
    severity: string;
    createdAt: string;
  }>;
}

// =============================================================================
// API RESPONSE TYPES
# =============================================================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: {
    timestamp: string;
    requestId: string;
  };
}

export interface PaginatedResponse<T> {
  items: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface HealthCheckDTO {
  status: 'healthy' | 'degraded' | 'unhealthy';
  version: string;
  timestamp: string;
  checks: {
    database: boolean;
    cache: boolean;
    external: boolean;
  };
}
