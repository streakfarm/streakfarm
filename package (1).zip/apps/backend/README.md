# Streakfarm Backend

A production-ready Express.js backend for the Streakfarm Telegram Mini App.

## Architecture

This backend uses a **Modular Domain-Driven Design (DDD)** structure:

```
src/
├── app.ts                    # Express app configuration
├── server.ts                 # Entry point
├── config/                   # Environment configuration
├── lib/                      # External service clients (Prisma, Redis)
├── middleware/               # Express middleware (auth, error handling)
├── modules/                  # DDD modules
│   ├── auth/                 # Authentication module
│   │   ├── auth.controller.ts
│   │   ├── auth.service.ts
│   │   ├── auth.routes.ts
│   │   └── auth.types.ts
│   ├── users/                # User management module
│   │   ├── users.controller.ts
│   │   ├── users.service.ts
│   │   ├── users.routes.ts
│   │   └── users.types.ts
│   └── boxes/                # Game mechanics module
│       ├── boxes.controller.ts
│       ├── boxes.service.ts
│       ├── boxes.routes.ts
│       └── boxes.types.ts
├── shared/                   # Shared utilities
└── routes/                   # Route aggregation
```

## Features

- **Telegram Authentication**: Secure login using Telegram's initData
- **JWT Token Management**: Access and refresh token rotation
- **Rate Limiting**: Protection against abuse
- **Redis Caching**: Session and cache management
- **PostgreSQL Database**: Prisma ORM with type-safe queries
- **DDD Architecture**: Clean separation of concerns

## Getting Started

### Prerequisites

- Node.js 20+
- PostgreSQL 14+
- Redis 7+
- pnpm

### Installation

```bash
# Install dependencies
pnpm install

# Generate Prisma client
pnpm db:generate

# Run database migrations
pnpm db:migrate

# Start development server
pnpm dev
```

### Environment Variables

Copy `.env.example` to `.env` and configure:

```env
DATABASE_URL="postgresql://..."
REDIS_HOST="localhost"
JWT_SECRET="your-secret"
TELEGRAM_BOT_TOKEN="your-bot-token"
```

## API Endpoints

### Authentication

- `POST /api/v1/auth/telegram` - Login with Telegram
- `POST /api/v1/auth/refresh` - Refresh tokens
- `POST /api/v1/auth/logout` - Logout

### Users

- `GET /api/v1/users/me` - Get current user profile
- `PATCH /api/v1/users/me` - Update profile
- `GET /api/v1/users/me/stats` - Get user statistics
- `GET /api/v1/users/leaderboard` - Get leaderboard
- `GET /api/v1/users/:userId` - Get user by ID

### Boxes

- `GET /api/v1/boxes/info` - Get box information
- `POST /api/v1/boxes/daily` - Claim daily box
- `POST /api/v1/boxes/open` - Open a box
- `GET /api/v1/boxes/my` - Get user's boxes
- `GET /api/v1/boxes/pending` - Get unopened boxes

## License

MIT
