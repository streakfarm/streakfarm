import { Request, Response, NextFunction } from 'express';
import { logger } from '../shared/logger.js';

export interface ApiError extends Error {
  statusCode?: number;
  isOperational?: boolean;
  code?: string;
}

export const errorHandler = (
  err: ApiError,
  _req: Request,
  res: Response,
  _next: NextFunction
): void => {
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  logger.error(`${err.name}: ${message}`, {
    stack: err.stack,
    statusCode,
    path: _req.path,
    method: _req.method,
  });

  res.status(statusCode).json({
    success: false,
    error: {
      message: statusCode === 500 ? 'Internal Server Error' : message,
      ...(process.env.NODE_ENV === 'development' && {
        name: err.name,
        stack: err.stack,
        code: err.code,
      }),
    },
  });
};
