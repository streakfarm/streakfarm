import { Request, Response, NextFunction } from 'express';
import { logger } from '../shared/logger.js';

export const notFoundHandler = (
  _req: Request,
  res: Response,
  _next: NextFunction
): void => {
  logger.warn(`Route not found: ${_req.method} ${_req.path}`);
  res.status(404).json({
    success: false,
    error: {
      message: `Route ${_req.method} ${_req.path} not found`,
    },
  });
};
