import { Router } from 'express';
import { authRoutes } from '../modules/auth/auth.routes.js';
import { usersRoutes } from '../modules/users/users.routes.js';
import { boxesRoutes } from '../modules/boxes/boxes.routes.js';

const router = Router();

router.use(authRoutes);
router.use(usersRoutes);
router.use(boxesRoutes);

export { router as routes };
