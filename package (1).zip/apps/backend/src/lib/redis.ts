import Redis from 'ioredis';
import { config } from '../config/index.js';
import { logger } from '../shared/logger.js';

const redisOptions: Redis.RedisOptions = {
  host: config.redisHost,
  port: config.redisPort,
  db: config.redisDb,
  keyPrefix: config.redisKeyPrefix,
  retryDelayOnFailover: 100,
  maxRetriesPerRequest: 3,
};

if (config.redisPassword) {
  redisOptions.password = config.redisPassword;
}

class RedisClient {
  private client: Redis | null = null;

  get instance(): Redis {
    if (!this.client) {
      this.client = new Redis(redisOptions);
      this.client.on('error', (err) => {
        logger.error('Redis connection error:', err);
      });
      this.client.on('connect', () => {
        logger.info('Redis connected');
      });
    }
    return this.client;
  }

  async close(): Promise<void> {
    if (this.client) {
      await this.client.quit();
      this.client = null;
    }
  }
}

export const redis = new RedisClient().instance;
