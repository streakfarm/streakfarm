import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { config } from '../../config/index.js';
import { prisma } from '../../lib/prisma.js';
import { redis } from '../../lib/redis.js';
import { logger } from '../../shared/logger.js';
import { ApiError } from '../../middleware/errorHandler.js';
import { TelegramLoginData, TokenPayload } from './auth.types.js';
import { User, UserRole } from '@streakfarm/shared';

interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

interface AuthResult {
  accessToken: string;
  refreshToken: string;
  user: User;
}

class AuthService {
  private generateAccessToken(payload: TokenPayload): string {
    return jwt.sign(payload, config.jwtSecret, {
      expiresIn: config.jwtExpiresIn,
    });
  }

  private generateRefreshToken(payload: TokenPayload): string {
    return jwt.sign(payload, config.jwtRefreshSecret, {
      expiresIn: config.jwtRefreshExpiresIn,
    });
  }

  private verifyRefreshToken(token: string): TokenPayload {
    try {
      return jwt.verify(token, config.jwtRefreshSecret) as TokenPayload;
    } catch {
      throw new ApiError(401, 'Invalid refresh token');
    }
  }

  private async validateTelegramData(data: TelegramLoginData): Promise<boolean> {
    // In production, verify the hash with Telegram's secret key
    // For now, we'll skip this in development
    if (config.nodeEnv === 'development') {
      return true;
    }

    const secretKey = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(config.telegramBotToken)
    );

    // Implementation would go here
    return true;
  }

  async loginWithTelegram(data: TelegramLoginData): Promise<AuthResult> {
    const isValid = await this.validateTelegramData(data);
    if (!isValid) {
      throw new ApiError(401, 'Invalid Telegram data');
    }

    let user = await prisma.user.findUnique({
      where: { telegramId: data.id },
    });

    if (!user) {
      user = await prisma.user.create({
        data: {
          telegramId: data.id,
          firstName: data.first_name,
          lastName: data.last_name || null,
          username: data.username || null,
          languageCode: data.language_code || 'en',
          photoUrl: data.photo_url || null,
        },
      });

      logger.info(`New user registered: ${user.telegramId}`);
    }

    const payload: TokenPayload = {
      userId: user.id,
      telegramId: user.telegramId,
      role: user.role as UserRole,
    };

    const accessToken = this.generateAccessToken(payload);
    const refreshToken = this.generateRefreshToken(payload);

    // Store refresh token in Redis with prefix
    await redis.set(
      `refresh:${user.id}`,
      refreshToken,
      'EX',
      30 * 24 * 60 * 60 // 30 days
    );

    return {
      accessToken,
      refreshToken,
      user: user as User,
    };
  }

  async refreshTokens(refreshToken: string): Promise<TokenPair> {
    const payload = this.verifyRefreshToken(refreshToken);

    const storedToken = await redis.get(`refresh:${payload.userId}`);
    if (!storedToken || storedToken !== refreshToken) {
      throw new ApiError(401, 'Invalid refresh token');
    }

    const newPayload: TokenPayload = {
      userId: payload.userId,
      telegramId: payload.telegramId,
      role: payload.role,
    };

    const newAccessToken = this.generateAccessToken(newPayload);
    const newRefreshToken = this.generateRefreshToken(newPayload);

    // Rotate refresh token
    await redis.set(
      `refresh:${payload.userId}`,
      newRefreshToken,
      'EX',
      30 * 24 * 60 * 60
    );

    return {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
    };
  }

  async logout(userId: string): Promise<void> {
    await redis.del(`refresh:${userId}`);
    logger.info(`User logged out: ${userId}`);
  }

  async getUserByToken(token: string): Promise<User | null> {
    try {
      const payload = jwt.verify(token, config.jwtSecret) as TokenPayload;
      const user = await prisma.user.findUnique({
        where: { id: payload.userId },
      });
      return user as User | null;
    } catch {
      return null;
    }
  }
}

export const authService = new AuthService();
