import { Request, Response } from 'express';
import { authService } from './auth.service.js';
import { ApiError } from '../../middleware/errorHandler.js';
import { logger } from '../../shared/logger.js';
import { TELEGRAM_LOGIN_SCHEMA } from './auth.types.js';

export const authController = {
  async telegramLogin(req: Request, res: Response) {
    try {
      const validationResult = TELEGRAM_LOGIN_SCHEMA.safeParse(req.body);

      if (!validationResult.success) {
        throw new ApiError(400, validationResult.error.errors[0].message);
      }

      const { accessToken, refreshToken, user } = await authService.loginWithTelegram(
        validationResult.data
      );

      res.status(200).json({
        success: true,
        data: {
          accessToken,
          refreshToken,
          user,
        },
      });
    } catch (error) {
      logger.error('Telegram login error:', error);
      throw error;
    }
  },

  async refreshToken(req: Request, res: Response) {
    try {
      const { refreshToken } = req.body;

      if (!refreshToken) {
        throw new ApiError(400, 'Refresh token is required');
      }

      const tokens = await authService.refreshTokens(refreshToken);

      res.status(200).json({
        success: true,
        data: tokens,
      });
    } catch (error) {
      logger.error('Token refresh error:', error);
      throw error;
    }
  },

  async logout(req: Request, res: Response) {
    try {
      const userId = req.user?.userId;

      if (userId) {
        await authService.logout(userId);
      }

      res.status(200).json({
        success: true,
        message: 'Logged out successfully',
      });
    } catch (error) {
      logger.error('Logout error:', error);
      throw error;
    }
  },
};
