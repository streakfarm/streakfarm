import { Router } from 'express';
import { authController } from './auth.controller.js';
import { authenticate } from '../../middleware/authenticate.js';

const router = Router();

router.post('/auth/telegram', authController.telegramLogin.bind(authController));
router.post('/auth/refresh', authController.refreshToken.bind(authController));
router.post('/auth/logout', authenticate, authController.logout.bind(authController));

export { router as authRoutes };
