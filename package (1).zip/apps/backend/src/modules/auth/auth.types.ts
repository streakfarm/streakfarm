import { z } from 'zod';
import { TG_USER_SCHEMA } from '@streakfarm/shared';

export const TELEGRAM_LOGIN_SCHEMA = TG_USER_SCHEMA.extend({
  hash: z.string(),
});

export type TelegramLoginData = z.infer<typeof TELEGRAM_LOGIN_SCHEMA>;

export const LOGIN_SCHEMA = TELEGRAM_LOGIN_SCHEMA;

export type LoginRequest = TelegramLoginData;

export const REFRESH_TOKEN_SCHEMA = z.object({
  refreshToken: z.string().min(1),
});

export type RefreshTokenRequest = z.infer<typeof REFRESH_TOKEN_SCHEMA>;

export const TOKEN_PAYLOAD_SCHEMA = z.object({
  userId: z.string(),
  telegramId: z.number(),
  role: z.enum(['user', 'admin']),
});

export type TokenPayload = z.infer<typeof TOKEN_PAYLOAD_SCHEMA>;
