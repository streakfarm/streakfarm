import { Request, Response } from 'express';
import { usersService } from './users.service.js';
import { ApiError } from '../../middleware/errorHandler.js';
import { logger } from '../../shared/logger.js';
import { AuthenticatedRequest } from '../../middleware/authenticate.js';

export const usersController = {
  async getProfile(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const user = await usersService.getUserById(userId);
      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      res.status(200).json({
        success: true,
        data: { user },
      });
    } catch (error) {
      logger.error('Get profile error:', error);
      throw error;
    }
  },

  async updateProfile(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const { firstName, lastName, username } = req.body;
      const updatedUser = await usersService.updateProfile(userId, {
        firstName,
        lastName,
        username,
      });

      res.status(200).json({
        success: true,
        data: { user: updatedUser },
      });
    } catch (error) {
      logger.error('Update profile error:', error);
      throw error;
    }
  },

  async getUserStats(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const stats = await usersService.getUserStats(userId);

      res.status(200).json({
        success: true,
        data: stats,
      });
    } catch (error) {
      logger.error('Get user stats error:', error);
      throw error;
    }
  },

  async getLeaderboard(req: AuthenticatedRequest, res: Response) {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;

      const leaderboard = await usersService.getLeaderboard(limit, offset);

      res.status(200).json({
        success: true,
        data: leaderboard,
      });
    } catch (error) {
      logger.error('Get leaderboard error:', error);
      throw error;
    }
  },

  async getUserById(req: Request, res: Response) {
    try {
      const { userId } = req.params;

      const user = await usersService.getUserById(userId);
      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      res.status(200).json({
        success: true,
        data: { user },
      });
    } catch (error) {
      logger.error('Get user by ID error:', error);
      throw error;
    }
  },
};
