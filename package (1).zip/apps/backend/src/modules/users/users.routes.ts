import { Router } from 'express';
import { usersController } from './users.controller.js';
import { authenticate, AuthenticatedRequest } from '../../middleware/authenticate.js';

const router = Router();

router.get(
  '/users/me',
  authenticate,
  usersController.getProfile.bind(usersController)
);

router.patch(
  '/users/me',
  authenticate,
  usersController.updateProfile.bind(usersController)
);

router.get(
  '/users/me/stats',
  authenticate,
  usersController.getUserStats.bind(usersController)
);

router.get(
  '/users/leaderboard',
  usersController.getLeaderboard.bind(usersController)
);

router.get(
  '/users/:userId',
  usersController.getUserById.bind(usersController)
);

export { router as usersRoutes };
