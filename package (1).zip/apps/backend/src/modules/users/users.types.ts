import { z } from 'zod';

export const UPDATE_PROFILE_SCHEMA = z.object({
  firstName: z.string().min(1).max(64).optional(),
  lastName: z.string().max(64).optional().nullable(),
  username: z.string().min(1).max(32).optional().nullable(),
});

export type UpdateProfileRequest = z.infer<typeof UPDATE_PROFILE_SCHEMA>;

export const USER_STATS_SCHEMA = z.object({
  userId: z.string(),
});

export type UserStatsRequest = z.infer<typeof USER_STATS_SCHEMA>;
