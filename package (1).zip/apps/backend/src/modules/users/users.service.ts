import { prisma } from '../../lib/prisma.js';
import { logger } from '../../shared/logger.js';
import { ApiError } from '../../middleware/errorHandler.js';
import { User } from '@streakfarm/shared';
import { UpdateProfileRequest } from './users.types.js';

interface UserStats {
  totalBoxesOpened: number;
  currentStreak: number;
  longestStreak: number;
  totalPoints: number;
  rank: number;
  badges: number;
}

class UsersService {
  async getUserById(userId: string): Promise<User | null> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        badges: true,
        boxes: {
          take: 10,
          orderBy: { openedAt: 'desc' },
        },
      },
    });

    return user as User | null;
  }

  async updateProfile(
    userId: string,
    data: UpdateProfileRequest
  ): Promise<User> {
    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        firstName: data.firstName,
        lastName: data.lastName,
        username: data.username,
      },
    });

    logger.info(`User profile updated: ${userId}`);
    return user as User;
  }

  async getUserStats(userId: string): Promise<UserStats> {
    const [user, boxesCount, badgesCount, rank] = await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
      }),
      prisma.box.count({
        where: { userId },
      }),
      prisma.userBadge.count({
        where: { userId },
      }),
      prisma.user.count({
        where: {
          points: {
            gt: 0,
          },
        },
      }).then(async (count) => {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user || user.points === 0) return count + 1;
        const higherRanked = await prisma.user.count({
          where: {
            points: {
              gt: user.points,
            },
          },
        });
        return higherRanked + 1;
      }),
    ]);

    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    return {
      totalBoxesOpened: boxesCount,
      currentStreak: user.currentStreak,
      longestStreak: user.longestStreak,
      totalPoints: user.points,
      rank,
      badges: badgesCount,
    };
  }

  async getLeaderboard(limit: number, offset: number) {
    const users = await prisma.user.findMany({
      take: limit,
      skip: offset,
      orderBy: {
        points: 'desc',
      },
      select: {
        id: true,
        telegramId: true,
        username: true,
        firstName: true,
        lastName: true,
        photoUrl: true,
        points: true,
        currentStreak: true,
        longestStreak: true,
        createdAt: true,
      },
    });

    const total = await prisma.user.count();

    return {
      users,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + users.length < total,
      },
    };
  }

  async incrementPoints(userId: string, points: number): Promise<void> {
    await prisma.user.update({
      where: { id: userId },
      data: {
        points: { increment: points },
      },
    });
  }

  async updateStreak(userId: string, streak: number): Promise<void> {
    await prisma.user.update({
      where: { id: userId },
      data: {
        currentStreak: streak,
        longestStreak: { max: streak },
      },
    });
  }
}

export const usersService = new UsersService();
