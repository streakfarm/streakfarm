import { Router } from 'express';
import { boxesController } from './boxes.controller.js';
import { authenticate, optionalAuth } from '../../middleware/authenticate.js';

const router = Router();

router.get('/boxes/info', optionalAuth, boxesController.getBoxInfo.bind(boxesController));
router.post(
  '/boxes/daily',
  authenticate,
  boxesController.claimDailyBox.bind(boxesController)
);
router.post(
  '/boxes/open',
  authenticate,
  boxesController.openBox.bind(boxesController)
);
router.get(
  '/boxes/my',
  authenticate,
  boxesController.getMyBoxes.bind(boxesController)
);
router.get(
  '/boxes/pending',
  authenticate,
  boxesController.getPendingBoxes.bind(boxesController)
);

export { router as boxesRoutes };
