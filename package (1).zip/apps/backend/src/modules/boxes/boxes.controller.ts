import { Request, Response } from 'express';
import { boxesService } from './boxes.service.js';
import { ApiError } from '../../middleware/errorHandler.js';
import { logger } from '../../shared/logger.js';
import { AuthenticatedRequest } from '../../middleware/authenticate.js';

export const boxesController = {
  async claimDailyBox(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const result = await boxesService.claimDailyBox(userId);

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      logger.error('Claim daily box error:', error);
      throw error;
    }
  },

  async openBox(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const { boxId } = req.body;

      if (!boxId) {
        throw new ApiError(400, 'Box ID is required');
      }

      const result = await boxesService.openBox(userId, boxId);

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      logger.error('Open box error:', error);
      throw error;
    }
  },

  async getMyBoxes(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;

      const boxes = await boxesService.getUserBoxes(userId, limit, offset);

      res.status(200).json({
        success: true,
        data: boxes,
      });
    } catch (error) {
      logger.error('Get my boxes error:', error);
      throw error;
    }
  },

  async getBoxInfo(_req: Request, res: Response) {
    try {
      const boxInfo = boxesService.getBoxInfo();

      res.status(200).json({
        success: true,
        data: boxInfo,
      });
    } catch (error) {
      logger.error('Get box info error:', error);
      throw error;
    }
  },

  async getPendingBoxes(req: AuthenticatedRequest, res: Response) {
    try {
      const userId = req.user?.id;
      if (!userId) {
        throw new ApiError(401, 'Unauthorized');
      }

      const boxes = await boxesService.getPendingBoxes(userId);

      res.status(200).json({
        success: true,
        data: boxes,
      });
    } catch (error) {
      logger.error('Get pending boxes error:', error);
      throw error;
    }
  },
};
