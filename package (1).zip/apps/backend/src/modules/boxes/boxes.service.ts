import { prisma } from '../../lib/prisma.js';
import { redis } from '../../lib/redis.js';
import { logger } from '../../shared/logger.js';
import { ApiError } from '../../middleware/errorHandler.js';
import { usersService } from '../users/users.service.js';
import { BADGE_DEFINITIONS, RARITY_RATES, BOX_CONFIG } from '@streakfarm/shared';
import {
  OpenBoxRequest,
  ClaimDailyBoxRequest,
  BoxReward,
} from './boxes.types.js';

interface BoxInfo {
  types: Array<{
    id: string;
    name: string;
    emoji: string;
    description: string;
    basePoints: number;
    rarity: string;
  }>;
  rarities: typeof RARITY_RATES;
  openCooldown: number;
}

interface ClaimDailyResult {
  box: {
    id: string;
    type: string;
    emoji: string;
    name: string;
    openedAt: Date;
  };
  streak: {
    current: number;
    longest: number;
    bonus: number;
  };
}

interface OpenBoxResult {
  reward: BoxReward;
  pointsEarned: number;
  streak: {
    current: number;
    longest: number;
  };
  isNewBadge: boolean;
  badgeEarned?: {
    id: string;
    name: string;
    description: string;
    emoji: string;
    rarity: string;
  };
}

class BoxesService {
  private readonly BOX_CACHE_KEY = 'daily:box:';

  async claimDailyBox(userId: string, _data?: ClaimDailyBoxRequest): Promise<ClaimDailyResult> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    // Check if user can claim daily box
    const lastClaim = await redis.get(`${this.BOX_CACHE_KEY}${userId}`);
    if (lastClaim) {
      const nextClaimTime = await redis.ttl(`${this.BOX_CACHE_KEY}${userId}`);
      throw new ApiError(
        400,
        `You can claim your next box in ${Math.floor(nextClaimTime / 60)} minutes`
      );
    }

    // Generate random box based on rarity rates
    const rarity = this.getRandomRarity();
    const boxType = this.getRandomBoxType(rarity);

    // Create the box
    const box = await prisma.box.create({
      data: {
        userId,
        type: boxType.id,
        rarity,
        isOpened: false,
        expiresAt: new Date(Date.now() + BOX_CONFIG.OPEN_EXPIRY_HOURS * 60 * 60 * 1000),
      },
    });

    // Update streak
    const isConsecutive = await this.checkConsecutiveDay(userId);
    const newStreak = isConsecutive ? user.currentStreak + 1 : 1;
    const longestStreak = Math.max(newStreak, user.longestStreak);
    const streakBonus = this.calculateStreakBonus(newStreak);

    await prisma.user.update({
      where: { id: userId },
      data: {
        currentStreak: newStreak,
        longestStreak,
      },
    });

    // Set daily box cooldown
    await redis.set(
      `${this.BOX_CACHE_KEY}${userId}`,
      '1',
      'EX',
      BOX_CONFIG.DAILY_CLAIM_COOLDOWN_HOURS * 60 * 60
    );

    logger.info(`Daily box claimed by user ${userId}: ${boxType.name} (${rarity})`);

    return {
      box: {
        id: box.id,
        type: box.type,
        emoji: boxType.emoji,
        name: boxType.name,
        openedAt: box.openedAt,
      },
      streak: {
        current: newStreak,
        longest: longestStreak,
        bonus: streakBonus,
      },
    };
  }

  async openBox(userId: string, boxId: string): Promise<OpenBoxResult> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    const box = await prisma.box.findFirst({
      where: {
        id: boxId,
        userId,
        isOpened: false,
        expiresAt: { gt: new Date() },
      },
    });

    if (!box) {
      throw new ApiError(404, 'Box not found or already opened');
    }

    // Generate reward based on box rarity
    const reward = this.generateReward(box.rarity, box.type);
    const pointsEarned = reward.points;

    // Mark box as opened
    await prisma.box.update({
      where: { id: boxId },
      data: {
        isOpened: true,
        openedAt: new Date(),
        rewardType: reward.id,
        rewardName: reward.name,
        rewardRarity: reward.rarity,
        points: pointsEarned,
      },
    });

    // Update user points and streak
    await usersService.incrementPoints(userId, pointsEarned);

    // Update streak
    const isConsecutive = await this.checkConsecutiveDay(userId);
    const newStreak = isConsecutive ? user.currentStreak + 1 : 1;
    const longestStreak = Math.max(newStreak, user.longestStreak);
    await usersService.updateStreak(userId, newStreak);

    // Check for new badges
    const newBadge = await this.checkAndAwardBadges(userId, pointsEarned, newStreak);

    logger.info(`Box ${boxId} opened by user ${userId}: ${reward.name} (${reward.rarity}) - ${pointsEarned} points`);

    return {
      reward: { ...reward, isNew: newBadge !== null },
      pointsEarned,
      streak: {
        current: newStreak,
        longest: longestStreak,
      },
      isNewBadge: newBadge !== null,
      badgeEarned: newBadge,
    };
  }

  async getUserBoxes(userId: string, limit: number, offset: number) {
    const boxes = await prisma.box.findMany({
      where: { userId },
      take: limit,
      skip: offset,
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.box.count({ where: { userId } });

    return {
      boxes,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + boxes.length < total,
      },
    };
  }

  async getPendingBoxes(userId: string) {
    const boxes = await prisma.box.findMany({
      where: {
        userId,
        isOpened: false,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });

    return boxes;
  }

  getBoxInfo(): BoxInfo {
    return {
      types: BOX_CONFIG.TYPES,
      rarities: RARITY_RATES,
      openCooldown: BOX_CONFIG.OPEN_EXPIRY_HOURS * 60 * 60 * 1000,
    };
  }

  private getRandomRarity(): string {
    const rand = Math.random() * 100;
    let cumulative = 0;

    for (const [rarity, rate] of Object.entries(RARITY_RATES)) {
      cumulative += rate;
      if (rand <= cumulative) {
        return rarity;
      }
    }

    return 'common';
  }

  private getRandomBoxType(rarity: string) {
    const types = BOX_CONFIG.TYPES.filter((t) => t.rarity === rarity);
    if (types.length === 0) {
      return BOX_CONFIG.TYPES[0];
    }
    return types[Math.floor(Math.random() * types.length)];
  }

  private generateReward(rarity: string, _type: string): BoxReward {
    // Simplified reward generation - in production, this would be more sophisticated
    const rewards = BOX_CONFIG.REWARDS[rarity as keyof typeof BOX_CONFIG.REWARDS] || [];
    const rewardTemplate = rewards[Math.floor(Math.random() * rewards.length)] || {
      id: 'coins',
      name: 'Coins',
      emoji: '🪙',
      pointsMultiplier: 1,
    };

    const basePoints = BOX_CONFIG.TYPES.find((t) => t.rarity === rarity)?.basePoints || 10;
    const points = Math.floor(basePoints * (rewardTemplate.pointsMultiplier || 1) * (0.8 + Math.random() * 0.4));

    return {
      id: rewardTemplate.id,
      name: rewardTemplate.name,
      rarity: rarity as 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary',
      emoji: rewardTemplate.emoji,
      points,
      isNew: false,
    };
  }

  private async checkConsecutiveDay(userId: string): Promise<boolean> {
    const lastBox = await prisma.box.findFirst({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    if (!lastBox) return true;

    const lastClaimTime = lastBox.createdAt.getTime();
    const now = Date.now();
    const hoursSinceLastClaim = (now - lastClaimTime) / (1000 * 60 * 60);

    return hoursSinceLastClaim < 48; // Within 48 hours to maintain streak
  }

  private calculateStreakBonus(streak: number): number {
    const streakMultipliers = [1, 1.1, 1.2, 1.3, 1.5, 2];
    const index = Math.min(streak - 1, streakMultipliers.length - 1);
    return streakMultipliers[index];
  }

  private async checkAndAwardBadges(
    userId: string,
    pointsEarned: number,
    streak: number
  ) {
    // Check each badge definition
    for (const badge of BADGE_DEFINITIONS) {
      const conditionMet = await this.evaluateBadgeCondition(
        userId,
        badge.condition,
        pointsEarned,
        streak
      );

      if (conditionMet) {
        // Check if user already has this badge
        const existingBadge = await prisma.userBadge.findUnique({
          where: {
            userId_badgeId: {
              userId,
              badgeId: badge.id,
            },
          },
        });

        if (!existingBadge) {
          await prisma.userBadge.create({
            data: {
              userId,
              badgeId: badge.id,
              earnedAt: new Date(),
            },
          });

          logger.info(`Badge "${badge.name}" awarded to user ${userId}`);
          return {
            id: badge.id,
            name: badge.name,
            description: badge.description,
            emoji: badge.emoji,
            rarity: badge.rarity,
          };
        }
      }
    }

    return null;
  }

  private async evaluateBadgeCondition(
    userId: string,
    condition: string,
    pointsEarned: number,
    streak: number
  ): Promise<boolean> {
    switch (condition) {
      case 'first_box':
        const boxesOpened = await prisma.box.count({ where: { userId } });
        return boxesOpened === 1;
      case 'streak_3':
        return streak >= 3;
      case 'streak_7':
        return streak >= 7;
      case 'streak_30':
        return streak >= 30;
      case 'points_100':
        const user = await prisma.user.findUnique({ where: { id: userId } });
        return (user?.points || 0) + pointsEarned >= 100;
      case 'points_1000':
        const user2 = await prisma.user.findUnique({ where: { id: userId } });
        return (user2?.points || 0) + pointsEarned >= 1000;
      case 'points_10000':
        const user3 = await prisma.user.findUnique({ where: { id: userId } });
        return (user3?.points || 0) + pointsEarned >= 10000;
      case 'boxes_10':
        const boxesCount = await prisma.box.count({ where: { userId } });
        return boxesCount >= 10;
      case 'boxes_100':
        const boxesCount2 = await prisma.box.count({ where: { userId } });
        return boxesCount2 >= 100;
      case 'rare_box':
        return false; // Would need to track in box record
      case 'legendary_box':
        return false;
      default:
        return false;
    }
  }
}

export const boxesService = new BoxesService();
