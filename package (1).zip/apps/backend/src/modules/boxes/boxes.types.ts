import { z } from 'zod';

export const OPEN_BOX_SCHEMA = z.object({
  boxId: z.string().optional(), // If provided, open a specific box
});

export type OpenBoxRequest = z.infer<typeof OPEN_BOX_SCHEMA>;

export const CLAIM_DAILY_BOX_SCHEMA = z.object({
  skipTutorial: z.boolean().default(false),
});

export type ClaimDailyBoxRequest = z.infer<typeof CLAIM_DAILY_BOX_SCHEMA>;

export const BOX_REWARD_SCHEMA = z.object({
  id: z.string(),
  name: z.string(),
  rarity: z.enum(['common', 'uncommon', 'rare', 'epic', 'legendary']),
  emoji: z.string(),
  points: z.number(),
  isNew: z.boolean(),
});

export type BoxReward = z.infer<typeof BOX_REWARD_SCHEMA>;
