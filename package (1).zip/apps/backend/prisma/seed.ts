import { PrismaClient, BoxRarity } from '@prisma/client';

const prisma = new PrismaClient();

const BADGE_DEFINITIONS = [
  {
    id: 'first_box',
    name: 'First Steps',
    description: 'Open your first box',
    emoji: '🎁',
    rarity: BoxRarity.COMMON,
    condition: 'first_box',
  },
  {
    id: 'streak_3',
    name: 'Getting Started',
    description: 'Maintain a 3-day streak',
    emoji: '🔥',
    rarity: BoxRarity.COMMON,
    condition: 'streak_3',
  },
  {
    id: 'streak_7',
    name: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    emoji: '⚡',
    rarity: BoxRarity.UNCOMMON,
    condition: 'streak_7',
  },
  {
    id: 'streak_30',
    name: 'Monthly Master',
    description: 'Maintain a 30-day streak',
    emoji: '🏆',
    rarity: BoxRarity.RARE,
    condition: 'streak_30',
  },
  {
    id: 'points_100',
    name: 'Century',
    description: 'Earn 100 points',
    emoji: '💯',
    rarity: BoxRarity.COMMON,
    condition: 'points_100',
  },
  {
    id: 'points_1000',
    name: 'Point Collector',
    description: 'Earn 1,000 points',
    emoji: '💰',
    rarity: BoxRarity.UNCOMMON,
    condition: 'points_1000',
  },
  {
    id: 'points_10000',
    name: 'Point Millionaire',
    description: 'Earn 10,000 points',
    emoji: '🤑',
    rarity: BoxRarity.EPIC,
    condition: 'points_10000',
  },
  {
    id: 'boxes_10',
    name: 'Box Opener',
    description: 'Open 10 boxes',
    emoji: '📦',
    rarity: BoxRarity.COMMON,
    condition: 'boxes_10',
  },
  {
    id: 'boxes_100',
    name: 'Hoarder',
    description: 'Open 100 boxes',
    emoji: '🏺',
    rarity: BoxRarity.RARE,
    condition: 'boxes_100',
  },
  {
    id: 'rare_box',
    name: 'Lucky Find',
    description: 'Open a rare box',
    emoji: '✨',
    rarity: BoxRarity.RARE,
    condition: 'rare_box',
  },
  {
    id: 'legendary_box',
    name: 'Legendary Discovery',
    description: 'Open a legendary box',
    emoji: '🌟',
    rarity: BoxRarity.LEGENDARY,
    condition: 'legendary_box',
  },
];

async function main() {
  console.log('🌱 Starting database seed...');

  // Seed badges
  for (const badge of BADGE_DEFINITIONS) {
    const existingBadge = await prisma.badge.findUnique({
      where: { id: badge.id },
    });

    if (!existingBadge) {
      await prisma.badge.create({
        data: badge,
      });
      console.log(`✅ Created badge: ${badge.name}`);
    } else {
      console.log(`ℹ️ Badge already exists: ${badge.name}`);
    }
  }

  console.log('✨ Database seeding completed!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
